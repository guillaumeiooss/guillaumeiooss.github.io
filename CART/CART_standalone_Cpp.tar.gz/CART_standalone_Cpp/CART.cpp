// Standalone C++ version of CART
// Copyright Guillaume Iooss, 2014, All right reserved.

#include "CART.h"

int _kMinMaxOption = 0;

// Option to select which mode of computation we take for kmin/kmax
// 	* 0 = compute a kMin/kMax for every possible values of "b".
// 	* 1 = compute a tighter kMin/kMax by assuming that "b" is "big enough".
void changekMinMaxOption(int newOption) {
	_kMinMaxOption = newOption;
	return;
};



list<list<vector<vector<long> > > > getTiledDomain(vector<vector<long> > const& polyScalar, const int nParam, const int nInd, vector<int> const& scale) {
	assert(polyScalar[0].size()==nParam+nInd+2);
	assert(scale.size()==nInd);
	
	list<list<vector<vector<long> > > > resDom;	// Result
	
	vector<vector<long> > linPart = submatrixColumn(polyScalar, nParam+1, polyScalar[0].size()-2);
	vector<vector<long> > paramPart = submatrixColumn(polyScalar, 1, nParam);
	vector<long> constPart(linPart.size());
	for (int i=0; i<polyScalar.size(); i++)
		constPart[i] = polyScalar[i][polyScalar[0].size()-1];
	
	vector<long> kmax(linPart.size());
	vector<long> kmin(linPart.size());
	
	for (int i=0; i<linPart.size(); i++) {
		long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
		long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
		
		for (int j=0; j<linPart[i].size(); j++) {
			if (linPart[i][j]>0)
				tempkmax += scale[j] * linPart[i][j];
			else if (linPart[i][j]<0)
				tempkmin += scale[j] * linPart[i][j];
		}
		for (int j=0; j<paramPart[i].size(); j++) {
			if (paramPart[i][j]>0)
				tempkmax += paramPart[i][j];
			else if (paramPart[i][j]<0)
				tempkmin += paramPart[i][j];
		}
		
		// kmax
		if (constPart[i]-tempkmax>=0) {
			if (_kMinMaxOption==0)
				kmax[i] = constPart[i];
			else
				kmax[i] = tempkmax;
		} else
			kmax[i] = tempkmax-1;
		
		// kmin
		if (constPart[i]-tempkmin>=0)
			kmin[i] = tempkmin;
		else {
			if (_kMinMaxOption==0)
				kmin[i] = constPart[i];
			else
				kmin[i] = tempkmin-1;
		}
	}
	
	//* DEBUG - kmin / kmax
	cout << "DEBUG: kmin - kmax" << endl;
	for (int i=0; i<linPart.size(); i++)
		cout << "kmin[" << i << "] = " << kmin[i] << "  |  kmax[" << i << "] = " << kmax[i] << endl;
	cout << endl;
	//*/
	
	for (int i=0; i<linPart.size(); i++) {				// We consider the ith constraint (outer intersection)
		list< vector< vector<long> > > domIthList;
		
		for (long k=kmin[i]+1; k<=kmax[i]; k++) {		// We consider all the different cases arising with the constraint (inner union)
			// * Case k > kmin
			
			// In Polylib format, the matrix of constraint is:
			//
			// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
			//
			// [ 1    Qp_i,*    0      0    Q_i,*.D   0     k   ]
			// [ 0      0     Qp_i,*  -k        0     Q     q   ]
			// [ 0      0       0      0        0     Id    0   ]
			// [ 0      0       0     D.1       0    -Id   -1   ]
			//
			// First column: 0=inequality / 1 = equality
			// \rho = blocked parameters / pp = local parameters / b = block size parameter
			// \alpha = blocked index parameter / ii = local index parameter
			
			vector<vector<long> > blockedConstr(2+2*nInd);
			for (int l=0; l<2+2*nInd; l++) {
			 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
			 	blockedConstr[l] = tempVect;
			}
			
			// (First line)
			blockedConstr[0][0] = 1;
			for (int j=0; j<nParam; j++) {
				blockedConstr[0][j+1] = paramPart[i][j];
			}
			for (int j=0; j<nInd; j++)
				blockedConstr[0][j+2+2*nParam] = linPart[i][j] * ((long) scale[j]);
			blockedConstr[0][blockedConstr[0].size()-1] = k;
			
			// (Second line)
			for (int j=0; j<nParam; j++)
				blockedConstr[1][j+1+nParam] = paramPart[i][j];
			blockedConstr[1][1+2*nParam] = -k;
			for (int j=0; j<nInd; j++)
				blockedConstr[1][2+2*nParam+nInd+j] = linPart[i][j];
			blockedConstr[1][blockedConstr[0].size()-1] = constPart[i];
			
			// (Third lines)
			for (int j=0; j<nInd; j++)
				blockedConstr[2+j][2+2*nParam+nInd+j] = 1;
			
			// (Fourth lines)
			for (int j=0; j<nInd; j++) {
				blockedConstr[2+nInd+j][1+2*nParam] = ((long) scale[j]);
				blockedConstr[2+nInd+j][2+2*nParam+nInd+j] = -1;
				blockedConstr[2+nInd+j][blockedConstr[0].size()-1] = -1;
			}
			
			domIthList.push_back(blockedConstr);
		}
		
		// * Case k = kmin
		
		// In Polylib format, the matrix of constraint is:
		//
		// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
		//
		// [ 0    Qp_i,*     0     0    Q_i,*.D   0    kmin ]
		// [ 0      0        0     0        0     Id    0   ]
		// [ 0      0        0    D.1       0    -Id   -1   ]
		//
		// First column: 0=inequality / 1 = equality
		// \rho = blocked parameters / pp = local parameters / b = block size parameter
		// \alpha = blocked index parameter / ii = local index parameter
		
		vector<vector<long> > blockedConstr(1+2*nInd);
		for (int l=0; l<1+2*nInd; l++) {
		 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
		 	blockedConstr[l] = tempVect;
		}
		
		// (First line)
		for (int j=0; j<nParam; j++)
			blockedConstr[0][1+j] = paramPart[i][j];
		for (int j=0; j<nInd; j++)
			blockedConstr[0][2+2*nParam+j]= linPart[i][j] * ((long) scale[j]);
		blockedConstr[0][blockedConstr[0].size()-1] = kmin[i];
		
		// (Second lines)
		for (int j=0; j<nInd; j++)
			blockedConstr[1+j][2+2*nParam+nInd+j] = 1;
		
		// (Fourth lines)
		for (int j=0; j<nInd; j++) {
			blockedConstr[1+nInd+j][1+2*nParam] = ((long) scale[j]);
			blockedConstr[1+nInd+j][2+2*nParam+nInd+j] = -1;
			blockedConstr[1+nInd+j][blockedConstr[0].size()-1] = -1;
		}
		domIthList.push_back(blockedConstr);
		
		resDom.push_back(domIthList);
	}	// [end of the loop across all the different case of k]
	
	return resDom;
}


map<vector<vector<long> >,vector<vector<long> > > getTiledFunction(vector<vector<long> > const& affScalar, int const nInd, int const nParam, vector<int> const& scale, vector<int> const& scaleIm) {
	assert(affScalar[0].size()==nInd+nParam+1);
	assert(scale.size()==nInd);
	assert(scaleIm.size()==affScalar.size());
	
	vector<vector<long> > paramPart = submatrixColumn(affScalar, 0, nParam-1);
	vector<vector<long> > linPart = submatrixColumn(affScalar, nParam, nParam+nInd-1);
	vector<long> constPart(affScalar.size());
	for (int i=0; i<affScalar.size(); i++)
		constPart[i] = affScalar[i][affScalar[0].size()-1];
	
	// We compute kmin and kmax (in the same manner (and with the same limitation) than for the domains -cf comments in "getTiledDomain")
	vector<long> kmax(linPart.size());
	vector<long> kmin(linPart.size());
	
	for (int i=0; i<linPart.size(); i++) {
		long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
		long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
		
		for (int j=0; j<linPart[i].size(); j++) {
			if (linPart[i][j]>0)
				tempkmax += scale[j] * linPart[i][j];
			else if (linPart[i][j]<0)
				tempkmin += scale[j] * linPart[i][j];
		}
		for (int j=0; j<paramPart[i].size(); j++) {
			if (paramPart[i][j]>0)
				tempkmax += paramPart[i][j];
			else if (paramPart[i][j]<0)
				tempkmin += paramPart[i][j];
		}
		
		// kmax
		if (constPart[i]-tempkmax>=0) {
			if (_kMinMaxOption==0)
				kmax[i] = constPart[i];
			else
				kmax[i] = tempkmax;
		} else
			kmax[i] = tempkmax-1;
		
		// kmin
		if (constPart[i]-tempkmin>=0)
			kmin[i] = tempkmin;
		else {
			if (_kMinMaxOption==0)
				kmin[i] = constPart[i];
			else
				kmin[i] = tempkmin-1;
		}
	}
	/* DEBUG - kmin / kmax
	for (int i=0; i<linPart.size(); i++)
		cout << "kmin[" << i << "] = " << kmin[i] << "  |  kmax[" << i << "] = " << kmax[i] << endl;
	cout << endl;
	//*/
	
	
	// Now, we build our new blocked affine functions: we have a part of piece-wise affine function per \vec{k},
	//		which is: \phi(\alpha,ii) = (Q.D.\alpha + Q_p.\rho + k  ,  Q.ii + q - b.k) when  b.k <= Q.ii+q < b.(k+1)
	// Thus, we iterate on the multi-dimensional vector k
	vector<long> kCurr(linPart.size());		// Multi-dimensional iterator
	for (int i=0; i<linPart.size(); i++)
		kCurr[i] = kmin[i];
	
	map<vector<vector<long> >,vector<vector<long> > > result;
	
	while (kCurr[linPart.size()-1]<=kmax[linPart.size()-1]) {
		
		// We build the piece-wise part corresponding to the vector "kCurr"
		// In Polylib format, the matrix of input constraints is:
		// 
		// ( eq | \rho  | pp |    b   | \alpha | ii |  const )    <= Row to know which column corresponds to what...
		// 
		// [ 0      0     Qp    -D'.k     0       Q      q     ]
		// [ 0      0    -Qp   D'.(k+1)   0      -Q   -D'.1-q  ]
		// [ 0      0      0      0       0      Id      0     ]
		// [ 0      0      0     D.1      0     -Id     -1     ]
		// 
		// First column: 0=inequality / 1 = equality
		// \rho = blocked parameters / pp = local parameters / b = block size parameter
		// \alpha = blocked index parameter / ii = local index parameter
		
		// And the matrix of relations is:
		// 
		// (     \rho    |   pp   |     b    |    \alpha    | ii | const)    <= Row to know which column corresponds to what...
		//
		// [  D'^{-1}.Qp     0          0       D'^{-1}Q.D    0      k  ]
		// [      0          Qp    -D'^{-1}k        0         Q      q  ]
		//
		
		vector<vector<long> > inputConstrLongMat(2*linPart.size()+2*nInd);
		for (int l=0; l<2*linPart.size()+2*nInd; l++) {
			vector<long> tempVect(3+2*nParam+2*nInd);
			inputConstrLongMat[l] = tempVect;
		}
		
		for (int i=0; i<linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size();j++)
				inputConstrLongMat[i][1+nParam+j] = paramPart[i][j];
			inputConstrLongMat[i][1+2*nParam] = -kCurr[i] * scaleIm[i];
			for (int j=0; j<nInd; j++)
				inputConstrLongMat[i][2+2*nParam+nInd+j] = linPart[i][j];
			inputConstrLongMat[i][inputConstrLongMat[0].size()-1] = constPart[i];
		}
		for (int i=linPart.size(); i<2*linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size(); j++)
				inputConstrLongMat[i][1+nParam+j] = -paramPart[i-linPart.size()][j];
			inputConstrLongMat[i][1+2*nParam] = scaleIm[i-linPart.size()]* ( kCurr[i-linPart.size()]+1 );
			for (int j=0; j<nInd; j++)
				inputConstrLongMat[i][2+2*nParam+nInd+j] = -linPart[i-linPart.size()][j];
			inputConstrLongMat[i][inputConstrLongMat[0].size()-1] = -scaleIm[i-linPart.size()]-constPart[i-linPart.size()];
		}
		for (int i=0; i<nInd; i++)
			inputConstrLongMat[i+2*linPart.size()][2+2*nParam+nInd+i] = 1;
		for (int i=0; i<nInd; i++) {
			inputConstrLongMat[i+2*linPart.size()+nInd][1+2*nParam] = (long) scale[i];
			inputConstrLongMat[i+2*linPart.size()+nInd][2+2*nParam+nInd+i] = -1;
			inputConstrLongMat[i+2*linPart.size()+nInd][inputConstrLongMat[0].size()-1] = -1;
		}
		
		/* DEBUG
		cout << " * inputConstrLongMat:" << endl;
		for (int i=0; i<inputConstrLongMat.size(); i++) {
			for (int j=0; j<inputConstrLongMat[0].size(); j++)
				cout << inputConstrLongMat[i][j] << " ";
			cout << endl;
		}
		cout << endl;
		//*/
		
		vector<vector<long> > relationConstrLongMat(2*linPart.size());
		for (int l=0; l<2*linPart.size(); l++) {
			vector<long> tempVect(2+2*nParam+2*nInd);
			relationConstrLongMat[l] = tempVect;
		}
		
		for (int i=0; i<linPart.size(); i++) {
			for (int j=0; j<nParam; j++) {
				long temp = (long) (paramPart[i][j]/scaleIm[i]);
				if (temp*scaleIm[i] != paramPart[i][j]) {
					cerr << "The resulting affine function has Z-polyhedral constraints (param | i = " << i << " | j = " << j << " )" << endl;
					exit(-1);
				}
				relationConstrLongMat[i][j] = temp;
			}
			for (int j=0; j<nInd; j++) {
				long temp = (long) (linPart[i][j] * scale[j] / scaleIm[i]);
				if (temp*scaleIm[i] != linPart[i][j] * scale[j]) {
					cerr << "The resulting affine function has Z-polyhedral constraints (linear | i = " << i << " | j = " << j << " )" << endl;
					exit(-1);
				}
				relationConstrLongMat[i][1+2*nParam+j] = temp;
			}
			relationConstrLongMat[i][relationConstrLongMat[0].size()-1] = kCurr[i];
		}
		for (int i=linPart.size(); i<2*linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size();j++)
				relationConstrLongMat[i][nParam+j] = paramPart[i-linPart.size()][j];
			relationConstrLongMat[i][2*nParam] = -scaleIm[i-linPart.size()]*kCurr[i-linPart.size()];
			for (int j=0; j<nInd; j++)
				relationConstrLongMat[i][1+2*nParam+nInd+j] = linPart[i-linPart.size()][j];
			relationConstrLongMat[i][relationConstrLongMat[0].size()-1] = constPart[i-linPart.size()];
		}
		
		/* DEBUG
		cout << " * relationConstrLongMat:" << endl;
		for (int i=0; i<relationConstrLongMat.size(); i++) {
			for (int j=0; j<relationConstrLongMat[0].size(); j++)
				cout << (relationConstrLongMat[i][j] << " ";
			cout << endl;
		}
		cout << endl;
		//*/
		
		result.insert ( pair<vector<vector<long> >, vector<vector<long> > >(inputConstrLongMat, relationConstrLongMat) );
		
		// We increase the multi-dimensional iterator, starting from the first dimension and propagating the overflows
		kCurr[0]++;
		for (int i=0; i<linPart.size()-1; i++)
			if (kCurr[i]>kmax[i]) {
				kCurr[i] = kmin[i];
				kCurr[i+1]++;
			}
	} // End of multi-dimensional loop
	
	return result;
}



vector<vector<long> > submatrixColumn(vector<vector<long> > const& A, int j1, int j2) {
	if (j1>j2) { // We give back an empty vector
		vector<vector<long> > B(A.size(), vector<long>(A[0].size()) ); 
		return B;
	}
	
	if (j1>=A[0].size() || j2>=A[0].size()) {
		cerr << "submatrixColumn: j1 or j2 out of bound" << endl;
		exit(-1);
	}
	
	vector<vector<long> > B(A.size(), vector<long>(j2-j1+1) );
	for (int i=0; i<A.size(); i++)
		for (int j=j1; j<=j2; j++)
			B[i][j-j1] = A[i][j];
	return B;
}

