// Test of the CART functions
// Copyright Guillaume Iooss, 2014, All right reserved.

#include "CART.h"

void printoutDomain(list<list<vector<vector<long> > > > llDom) {
	cout << "Intersection between the " << llDom.size() << " following union(s) of polyhedra:" << endl;
	for (list<list<vector<vector<long> > > >::iterator lDom=llDom.begin(); lDom!=llDom.end(); lDom++) {
		cout << "	[[[" << endl;
		for (list<vector<vector<long> > >::iterator poly=lDom->begin(); poly!=lDom->end(); poly++) {
			for (vector<vector<long> >::iterator it1=poly->begin(); it1!=poly->end(); it1++) {
				cout << "		(";
				for (vector<long>::iterator it2=it1->begin(); it2!=it1->end(); it2++)
					cout << " " << (*it2);
				cout << " )" << endl;
			}
			cout << endl;
		}
		cout << "]]]" << endl;
	}
	return;
}

void test_CARTDomain() {
	changekMinMaxOption(0);
	
	/* Example 1: { i,j | N-i-j-1>=0 } with tiles of size b*b
	long constr1Array[] = {0, 1, -1, -1, -1};
	vector<long> constr1(constr1Array, constr1Array + sizeof(constr1Array)/sizeof(long) );
	vector<vector<long> > polyScalar(1, constr1);
	
	vector<int> scale(2); scale[0] = 1; scale[1] = 1;
	
	printoutDomain( getTiledDomain(polyScalar, 1, 2, scale) );
	// RESULT: union of 3 polyhedra:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 1 0 | 0 | -1 -1 |  0  0 |  0 )
	//( 0 | 0 1 | 0 |  0  0 | -1 -1 | -1 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	// and
	//( 1 | 1 0 | 0 | -1 -1 |  0  0 | -1 )
	//( 0 | 0 1 | 1 |  0  0 | -1 -1 | -1 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	// and
	//( 0 | 1 0 | 0 | -1 -1 |  0  0 | -2 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	//	=> { i,j,alpha,beta | Nbl = alpha+beta && Nloc-1-ii-jj>=0 && 0<=ii,jj<b } U { i,j,alpha,beta | Nbl = alpha+beta+1 && Nloc+b-1-ii-jj>=0 && 0<=ii,jj<b }
	//			U { i,j,alpha,beta | Nbl >= alpha+beta+2 && 0<=ii,jj<b }
	//*/
	
	//* Example 2: {i,j | i-j>=0 && 2j-i>=0 && N-1-j>=0 } with tiles of size b*b
	long constr2_1Array[] = {0, 0,  1, -1,  0};
	long constr2_2Array[] = {0, 0, -1,  2,  0};
	long constr2_3Array[] = {0, 1,  0, -1, -1};
	
	vector<long> constr2_1(constr2_1Array, constr2_1Array +  sizeof(constr2_1Array)/sizeof(long) );
	vector<long> constr2_2(constr2_2Array, constr2_2Array +  sizeof(constr2_2Array)/sizeof(long) );
	vector<long> constr2_3(constr2_3Array, constr2_3Array +  sizeof(constr2_3Array)/sizeof(long) );
	
	vector<vector<long> > polyScalar2(3);
	polyScalar2[0] = constr2_1;
	polyScalar2[1] = constr2_2;
	polyScalar2[2] = constr2_3;
	
	vector<int> scale2(2); scale2[0] = 1; scale2[1] = 1;
	
	printoutDomain( getTiledDomain(polyScalar2, 1, 2, scale2) );
	// RESULT: intersection between 3 unions of polyhedra (each union corresponding to a given constraint)
	// (we omit systematically the last 4 lines of constaints, which are 0<=i,j<b
	// * First union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 0 0 | 0 | 1 -1 | 0  0 | 0 )
	//( 0 | 0 0 | 0 | 0  0 | 1 -1 | 0 )
	// and
	//( 0 | 0 0 | 0 | 1 -1 |  0  0 |  0 )
	//  => {i,j,alpha,beta | alpha=beta && ii>=jj && 0<=ii,jj<b } U {i,j,alpha,beta | alpha>=beta+1 && 0<=ii,jj<b }
	//
	// * Second union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 0 0 |  0 | -1 2 |  0  0 |  0 )
	//( 0 | 0 0 | -1 |  0 0 | -1  2 |  0 )
	// and
	//( 1 | 0 0 |  0 | -1 2 |  0 0 | 1 )
	//( 0 | 0 0 | -1 |  0 0 | -1 2 | 0 )
	// and
	//( 0 | 0 0 | 0 | -1 2 | 0 0 | -1 )
	//  => {i,j,alpha,beta | 2.beta-alpha=0 && 2.jj-ii>=0 && 0<=ii,jj<b } U {i,j,alpha,beta | 2.beta-alpha=-1 && 2.jj-ii>=b && 0<=ii,jj<b }
	//				U {i,j,alpha,beta | 2.beta-alpha>=1 && 0<=ii,jj<b }
	//
	// * Third union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 1 0 | 0 | 0 -1 |  0  0 |  0 )
	//( 0 | 0 1 | 0 | 0  0 |  0 -1 | -1 )
	// and
	//( 0 | 1 0 | 0 | 0 -1 |  0  0 | -1 )
	//  => {i,j,alpha,beta | Nbl=beta && Nloc>=jj+1 && 0<=ii,jj<b } U {i,j,alpha,beta | Nbl>=beta-1 && 0<=ii,jj<b }
	//*/
	
	return;
}


/* ------------------------------------------ */

void printoutFunction(map<vector< vector<long> >, vector< vector<long> > > mFunc) {
	cout << mFunc.size() << " branches:" << endl;
	for (map<vector< vector<long> >, vector< vector<long> > >::const_iterator itMap=mFunc.begin(); itMap!=mFunc.end(); itMap++) {
		cout << "IF" << endl;
		
		for (vector<vector<long> >::const_iterator itCond = (itMap->first).begin(); itCond!=(itMap->first).end(); itCond++) {
			cout << "	(";
			for (vector<long>::const_iterator it2 = itCond->begin(); it2!=itCond->end(); it2++)
				cout << " " << (*it2);
			cout << " )" << endl;
		}
		cout << "	THEN" << endl;
		
		for (vector<vector<long> >::const_iterator itFunc = (itMap->second).begin(); itFunc!=(itMap->second).end(); itFunc++) {
			cout << "		(";
			for (vector<long>::const_iterator it2 = itFunc->begin(); it2!=itFunc->end(); it2++)
				cout << " " << (*it2);
			cout << " )" << endl;
		}
		cout << endl;
	}
}


void test_CARTFunction() {
	changekMinMaxOption(0);
	
	//* Example 1: (i,j -> i-1, j-1)  (Jacobi1D dependence)
	long dim1Array[] = {1, 0, -1};
	long dim2Array[] = {0, 1, -1};
	
	vector<long> dim1(dim1Array, dim1Array +  sizeof(dim1Array)/sizeof(long) );
	vector<long> dim2(dim2Array, dim2Array +  sizeof(dim2Array)/sizeof(long) );
	
	vector<vector<long> > funcScalar(2);
	funcScalar[0] = dim1;
	funcScalar[1] = dim2;
	
	vector<int> scale(2); scale[0] = 1; scale[1] = 1;
	vector<int> scaleIm(2); scaleIm[0] = 1; scaleIm[1] = 1;
	
	printoutFunction( getTiledFunction(funcScalar, 2, 0, scale, scaleIm) );
	// RESULT: 4 branches:
	// Conds: (0/1 b alpha beta ii jj cst)
	// Funcs: (b alpha beta ii jj cst)
	//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta-1, ii-1, b+jj-1)		// Note: jj=0 
	//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta, ii-1, jj-1)
	//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta-1, b+ii-1, b+jj-1)	// Note: ii=jj=0
	//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta, b+ii-1, jj-1)		// Note: ii=0
	//*/
}


/* ------------------------------------------ */

int main() {
	//test_CARTDomain();
	test_CARTFunction();
	
	return 0;
}

