// Standalone C++ version of CART
// Copyright Guillaume Iooss, 2014, All right reserved.

#ifndef __CART_H
#define __CART_H

#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <stdlib.h>
#include <assert.h>

using namespace std;

/* Option to select which mode of computation we take for kmin/kmax
 * 	* 0 = compute a kMin/kMax for every possible values of "b".
 * 	* 1 = compute a tighter kMin/kMax by assuming that "b" is "big enough".
 */
void changekMinMaxOption(int newOption);


/* CART transformation for polyhedron:
 *    - The input domain is specified as a matrix ("vector<vector<long> >") in Polylib format
 *    - The number of parameters/indexes are specified by "nParam"/"nInd" (the dimensions corresponding to the parameters are the first columns of "polyScalar")
 *    - The aspect ratios of the tiling for each ones of the index dimensions are specified by "scale" (diagonal matrix "D")
 * 
 * This transformation takes a "scalar" polyhedron "D = { \vec{i} | ... }" and transforms it into a union of "blocked" polyhedra "\Delta = {\vec{\alpha}, \vec{ii} | ...}" such that:
 * 			- \vec{i} = b.D.\vec{\alpha} + \vec{ii}, where "b" is the tile size parameter...
 * 
 * The output of the transformation is an intersection (first "list") of union (second "list") of polyhedra ("vector<vector<long> >", in Polylib format).
 * Indeed, the simplification into a union of polyhedra is possible, but would introduce a lot of empty polyhedra.
 */
list<list<vector<vector<long> > > > getTiledDomain(vector<vector<long> > const& polyScalar, int const nParam, int const nInd, vector<int> const& scale);

/* CART transformation for affine function:
 *    - The input function is specified as a matrix ("vector<vector<long> >") where the first columns corresponds to the parameters
 *    - The number of parameters/indexes are specified by "nParam"/"nInd"
 *    - The aspect ratios of tiling of the input space is specified by "scale" (diagonal matrix "D")
 *    - The aspect ratios of tiling of the output space is specified by "scaleIm" (diagonal matrix "D'")
 * 
 * This transformation takes a "scalar" affine function "f:(\vec{i} |-> ... )" into a "blocked" piecewise affine function "\phi:(\vec{\alpha}, \vec{ii} |-> ...)" such that:
 *			- \phi(\vec{alpha},\vec{ii}) = f(b.D.\vec{\alpha} + \vec{ii})
 * 
 * The output of the transformation is a piecewise affine function: the branches are stored in a "map", the first element of the pair is the condition of the branch ("vector<vector<long> >") in Polylib format, and the second element of the pair is the value of the function on the branch ("vector<vector<long> >")
 */
map<vector<vector<long> >,vector<vector<long> > > getTiledFunction(vector<vector<long> > const& affScalar, int nInd, int nParam, vector<int> const& scale, vector<int> const& scaleIm);


// Auxillary function: gives back the submatrix of A, containing the columns i to j (both indexes included) (0<=i<=j<A[0].size()).
vector<vector<long> > submatrixColumn(vector<vector<long> > const& A, int j1, int j2);

#endif

