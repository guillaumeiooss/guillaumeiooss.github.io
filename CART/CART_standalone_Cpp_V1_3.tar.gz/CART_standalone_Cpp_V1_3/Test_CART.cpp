// Test of the CART functions
// Copyright Guillaume Iooss, 2014, All right reserved.

#include "CART.h"

void printoutDomain(list<list<vector<vector<long> > > > llDom) {
	cout << "Intersection between the " << llDom.size() << " following union(s) of polyhedra:" << endl;
	for (list<list<vector<vector<long> > > >::iterator lDom=llDom.begin(); lDom!=llDom.end(); lDom++) {
		cout << "	[[[" << endl;
		for (list<vector<vector<long> > >::iterator poly=lDom->begin(); poly!=lDom->end(); poly++) {
			for (vector<vector<long> >::iterator it1=poly->begin(); it1!=poly->end(); it1++) {
				cout << "		(";
				for (vector<long>::iterator it2=it1->begin(); it2!=it1->end(); it2++)
					cout << " " << (*it2);
				cout << " )" << endl;
			}
			cout << endl;
		}
		cout << "]]]" << endl;
	}
	return;
}

void printoutMatrix(vector<vector<long> > mat) {
	for (int i=0; i<mat.size(); i++) {
		cout << "[ ";
		for (int j=0; j<mat[0].size(); j++) {
			cout << mat[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	
	return;
}


void test_CARTDomain() {
	changekMinMaxOption(0);
	
	//* Example 1: { i,j | N-i-j-1>=0 } with tiles of size b*b
	long constr1Array[] = {0, 1, -1, -1, -1};
	vector<long> constr1(constr1Array, constr1Array + sizeof(constr1Array)/sizeof(long) );
	vector<vector<long> > polyScalar(1, constr1);
	
	vector<int> scale(2); scale[0] = 1; scale[1] = 1;
	
	printoutDomain( getTiledDomain(polyScalar, 1, 2, scale, false, 3) );
	// RESULT: union of 3 polyhedra:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)    // 1 = equality / 0 = inequality
	//( 1 | 1 0 | 0 | -1 -1 |  0  0 |  0 )
	//( 0 | 0 1 | 0 |  0  0 | -1 -1 | -1 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	// and
	//( 1 | 1 0 | 0 | -1 -1 |  0  0 | -1 )
	//( 0 | 0 1 | 1 |  0  0 | -1 -1 | -1 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	// and
	//( 0 | 1 0 | 0 | -1 -1 |  0  0 | -2 )
	//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
	//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
	//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
	//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
	//	=> { i,j,alpha,beta | Nbl = alpha+beta && Nloc-1-ii-jj>=0 && 0<=ii,jj<b } U { i,j,alpha,beta | Nbl = alpha+beta+1 && Nloc+b-1-ii-jj>=0 && 0<=ii,jj<b }
	//			U { i,j,alpha,beta | Nbl >= alpha+beta+2 && 0<=ii,jj<b }
	//*/
	
	/* Example 2: {i,j | i-j>=0 && 2j-i>=0 && N-1-j>=0 } with tiles of size b*b
	long constr2_1Array[] = {0, 0,  1, -1,  0};
	long constr2_2Array[] = {0, 0, -1,  2,  0};
	long constr2_3Array[] = {0, 1,  0, -1, -1};
	
	vector<long> constr2_1(constr2_1Array, constr2_1Array +  sizeof(constr2_1Array)/sizeof(long) );
	vector<long> constr2_2(constr2_2Array, constr2_2Array +  sizeof(constr2_2Array)/sizeof(long) );
	vector<long> constr2_3(constr2_3Array, constr2_3Array +  sizeof(constr2_3Array)/sizeof(long) );
	
	vector<vector<long> > polyScalar2(3);
	polyScalar2[0] = constr2_1;
	polyScalar2[1] = constr2_2;
	polyScalar2[2] = constr2_3;
	
	vector<int> scale2(2); scale2[0] = 1; scale2[1] = 1;
	
	printoutDomain( getTiledDomain(polyScalar2, 1, 2, scale2) );
	// RESULT: intersection between 3 unions of polyhedra (each union corresponding to a given constraint)
	// (we omit systematically the last 4 lines of constaints, which are 0<=i,j<b
	// * First union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 0 0 | 0 | 1 -1 | 0  0 | 0 )
	//( 0 | 0 0 | 0 | 0  0 | 1 -1 | 0 )
	// and
	//( 0 | 0 0 | 0 | 1 -1 |  0  0 |  0 )
	//  => {i,j,alpha,beta | alpha=beta && ii>=jj && 0<=ii,jj<b } U {i,j,alpha,beta | alpha>=beta+1 && 0<=ii,jj<b }
	//
	// * Second union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 0 0 |  0 | -1 2 |  0  0 |  0 )
	//( 0 | 0 0 | -1 |  0 0 | -1  2 |  0 )
	// and
	//( 1 | 0 0 |  0 | -1 2 |  0 0 | 1 )
	//( 0 | 0 0 | -1 |  0 0 | -1 2 | 0 )
	// and
	//( 0 | 0 0 | 0 | -1 2 | 0 0 | -1 )
	//  => {i,j,alpha,beta | 2.beta-alpha=0 && 2.jj-ii>=0 && 0<=ii,jj<b } U {i,j,alpha,beta | 2.beta-alpha=-1 && 2.jj-ii>=b && 0<=ii,jj<b }
	//				U {i,j,alpha,beta | 2.beta-alpha>=1 && 0<=ii,jj<b }
	//
	// * Third union:
	//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
	//( 1 | 1 0 | 0 | 0 -1 |  0  0 |  0 )
	//( 0 | 0 1 | 0 | 0  0 |  0 -1 | -1 )
	// and
	//( 0 | 1 0 | 0 | 0 -1 |  0  0 | -1 )
	//  => {i,j,alpha,beta | Nbl=beta && Nloc>=jj+1 && 0<=ii,jj<b } U {i,j,alpha,beta | Nbl>=beta-1 && 0<=ii,jj<b }
	//*/
	
	return;
}


/* ------------------------------------------ */

void printoutFunction(map<vector< vector<long> >, vector< vector<long> > > mFunc) {
	cout << mFunc.size() << " branches:" << endl;
	for (map<vector< vector<long> >, vector< vector<long> > >::const_iterator itMap=mFunc.begin(); itMap!=mFunc.end(); itMap++) {
		cout << "IF" << endl;
		
		for (vector<vector<long> >::const_iterator itCond = (itMap->first).begin(); itCond!=(itMap->first).end(); itCond++) {
			cout << "	(";
			for (vector<long>::const_iterator it2 = itCond->begin(); it2!=itCond->end(); it2++)
				cout << " " << (*it2);
			cout << " )" << endl;
		}
		cout << "	THEN" << endl;
		
		for (vector<vector<long> >::const_iterator itFunc = (itMap->second).begin(); itFunc!=(itMap->second).end(); itFunc++) {
			cout << "		(";
			for (vector<long>::const_iterator it2 = itFunc->begin(); it2!=itFunc->end(); it2++)
				cout << " " << (*it2);
			cout << " )" << endl;
		}
		cout << endl;
	}
}


void test_CARTFunction() {
	changekMinMaxOption(0);
	
	//* Example 1: (i,j -> i-1, j-1)  (Jacobi1D dependence)
	long dim1Array[] = {1, 0, -1};
	long dim2Array[] = {0, 1, -1};
	
	vector<long> dim1(dim1Array, dim1Array +  sizeof(dim1Array)/sizeof(long) );
	vector<long> dim2(dim2Array, dim2Array +  sizeof(dim2Array)/sizeof(long) );
	
	vector<vector<long> > funcScalar(2);
	funcScalar[0] = dim1;
	funcScalar[1] = dim2;
	
	vector<int> scale(2); scale[0] = 1; scale[1] = 1;
	vector<int> scaleIm(2); scaleIm[0] = 1; scaleIm[1] = 1;
	
	printoutFunction( getTiledFunction(funcScalar, 2, 0, scale, scaleIm, true, 3) );
	// RESULT: 4 branches:
	// Conds: (0/1 b alpha beta ii jj cst)
	// Funcs: (b alpha beta ii jj cst)
	//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta-1, ii-1, b+jj-1)		// Note: jj=0 
	//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta, ii-1, jj-1)
	//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta-1, b+ii-1, b+jj-1)	// Note: ii=jj=0
	//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta, b+ii-1, jj-1)		// Note: ii=0
	//*/
}


/* ------------------------------------------ */

void test_CARTDomain_Skewed() {
	
	
	//* Example 1: {t,i | 0<=i<N && 0<=t<T} + Cob before: (t,i->t,i+t)
	int nInd = 2;
	int nParam = 2;
	
	long constr1Array[] = {1, 1, 0, 0, 0, 0};
	vector<long> constr1(constr1Array, constr1Array + sizeof(constr1Array)/sizeof(long) );
	long constr2Array[] = {1, -1, 0, 1, 0, -1};
	vector<long> constr2(constr2Array, constr2Array + sizeof(constr2Array)/sizeof(long) );
	long constr3Array[] = {1, 0, 1, 0, 0, 0};
	vector<long> constr3(constr3Array, constr3Array + sizeof(constr3Array)/sizeof(long) );
	long constr4Array[] = {1, 0, -1, 0, 1, -1};
	vector<long> constr4(constr4Array, constr4Array + sizeof(constr4Array)/sizeof(long) );
	
	vector<vector<long> > polyScalar(4);
	polyScalar[0] = constr1;
	polyScalar[1] = constr2;
	polyScalar[2] = constr3;
	polyScalar[3] = constr4;
	
	/* DEBUG
	printoutMatrix(polyScalar);
	cout << "*******************" << endl;
	//*/ //END DEBUG
	
	vector<int> scale(2); scale[0] = 1; scale[1] = 1;
	
	vector<long> unimodMat_Row0(5); unimodMat_Row0[0] = 1; unimodMat_Row0[1] = 1; unimodMat_Row0[2] = 0; unimodMat_Row0[3] = 0; unimodMat_Row0[4] = 0;
	vector<long> unimodMat_Row1(5); unimodMat_Row1[0] = 0; unimodMat_Row1[1] = 1; unimodMat_Row1[2] = 0; unimodMat_Row1[3] = 0; unimodMat_Row1[4] = 0;
	vector<vector<long> > unimodMat(2); unimodMat[0] = unimodMat_Row0; unimodMat[1] = unimodMat_Row1;
	
	printoutDomain( getTiledDomain_scheduled(polyScalar, nInd, nParam, scale, true, 2, unimodMat) );
}

void test_LinAlg() {
	/*
	vector<long> Arow0(3); Arow0[0] = 1; Arow0[1] = 0; Arow0[2] = 1;
	vector<long> Arow1(3); Arow1[0] = 0; Arow1[1] = 1; Arow1[2] = 1;
	vector<long> Arow2(3); Arow2[0] = 0; Arow2[1] = 0; Arow2[2] = 1;
	vector<vector<long> > A(3);
	A[0] = Arow0; A[1] = Arow1; A[2] = Arow2;
	
	vector<vector<long> > Ainv = inverseMatUnimod(A);
	
	printoutMatrix(Ainv);//*/
	
	vector<long> Arow0(2); Arow0[0] = 0; Arow0[1] = 1;
	vector<long> Arow1(2); Arow1[0] = 1; Arow1[1] = 1;
	vector<vector<long> > A(2);
	A[0] = Arow0; A[1] = Arow1;
	
	vector<vector<long> > Ainv = inverseMatUnimod(A);
	
	printoutMatrix(Ainv);
}

/* ------------------------------------------ */

int main() {
	//test_CARTDomain();
	//test_CARTFunction();
	//test_CARTDomain_Skewed();
	test_LinAlg();
	
	return 0;
}

