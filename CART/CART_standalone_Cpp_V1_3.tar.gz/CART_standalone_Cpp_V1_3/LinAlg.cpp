#include "LinAlg.h"

vector<vector<long> > submatrixColumn(vector<vector<long> > const& A, int j1, int j2) {
	if (j1>j2) { // We give back an empty vector
		vector<vector<long> > B(A.size(), vector<long>(A[0].size()) ); 
		return B;
	}
	
	if (j1>=A[0].size() || j2>=A[0].size()) {
		cerr << "submatrixColumn: j1 or j2 out of bound" << endl;
		exit(-1);
	}
	
	vector<vector<long> > B(A.size(), vector<long>(j2-j1+1) );
	for (int i=0; i<A.size(); i++)
		for (int j=j1; j<=j2; j++)
			B[i][j-j1] = A[i][j];
	return B;
}


/* Given a polyhedron and a matrix, compute the resulting polyhedron after a change of basis:
    => "Mat" specify an affine function (indexes first, then parameters, then constant) (i -> A.i+B.p+c) where A is unimodular
	and we compute the image of the polyhedron "poly" by this function.
 */
vector<vector<long> > changeOfBasis(vector<vector<long> > poly, int nParam, int nInd, vector<vector<long> > mat) {
	assert(mat[0].size()==nParam+nInd+1);
	
	// Extraction of constraints
	vector<long> ineqEqPart(poly.size());											// 1/0
	for (int i=0; i<poly.size(); i++)
		ineqEqPart[i] = poly[i][0];
	vector<vector<long> > linPart = submatrixColumn(poly, 1, nInd);					// inds
	vector<vector<long> > paramPart = submatrixColumn(poly, nInd+1, nParam+nInd);	// params
	vector<long> constPart(poly.size());											// const
	for (int i=0; i<poly.size(); i++)
		constPart[i] = poly[i][poly[0].size()-1];
	
	// Extraction of mat
	vector<vector<long> > linPartMat = submatrixColumn(mat, 0, nInd-1);
	vector<vector<long> > paramPartMat = submatrixColumn(mat, nInd, nInd+nParam-1);
	vector<long> constMat(mat.size());
	for (int i=0; i<mat.size(); i++)
		constMat[i] = mat[i][mat[0].size()-1];
	
	vector<vector<long> > linPartMatInv = inverseMatUnimod(linPartMat);
	
	
	// Computes nLinPartMat = linPart*linPartMatInv
	vector<vector<long> >nLinPartMat = matrixMultiplication(linPart, linPartMatInv);
	
	// Computes nParamPartMat = paramPart - linPart*linPartMatInv*paramPartMat
	vector<vector<long> >nParamPartMat = matrixMultiplication(linPart, matrixMultiplication(linPartMatInv,paramPartMat) );
	for (int i=0; i<nParamPartMat.size(); i++)
		for (int j=0; j<nParamPartMat[0].size(); j++)
			nParamPartMat[i][j] = paramPart[i][j] - nParamPartMat[i][j];
	
	// Computes nConstPartMat = constPart - linPart*linPartMatInv*constPartMat
	vector<long> nConstPartMat(constPart.size());
	vector<vector<long> > tempMat = matrixMultiplication(linPart, linPartMatInv);
	for (int i=0; i<constPart.size(); i++) {
		nConstPartMat[i] = constPart[i];
		for (int k=0; k<tempMat[0].size(); k++)
			nConstPartMat[i] -= tempMat[i][k]*constMat[k];
	}
	
	// Put back the matrix in place
	vector<vector<long> > linPartMat1(linPart.size(), vector<long>(nLinPartMat[0].size()+nParamPartMat[0].size()+2));
	for (int i=0; i<linPartMat1.size(); i++) {
		linPartMat1[i][0] = ineqEqPart[i];			// 0/1
		for (int j=0; j<nLinPartMat[0].size(); j++)
			linPartMat1[i][j+1] = nLinPartMat[i][j];
		for (int j=0; j<nParamPartMat[0].size(); j++)
			linPartMat1[i][1+nLinPartMat[0].size()+j] = nParamPartMat[i][j];
		linPartMat1[i][nLinPartMat[0].size()+nParamPartMat[0].size()+1] = nConstPartMat[i];
	}
	
	// TODO: free ???
	
	return linPartMat1;
}

/* Inversion of a unimodular matrix
 */
vector<vector<long> > inverseMatUnimod(vector<vector<long> > const& unimodMatinv) {
	// Copy the matrix into A
	vector<vector<long> > A = copyMatrix(unimodMatinv);
	
	if (A.size()==1)
		return A;
	
	// First, deal with the left upper corner
	int m = A.size();
	vector<vector<long> > left(m, vector<long>(m,0) );		// Left unimodular inverse of the matrix
	for (int i=0; i<m; i++) {
		long sc = 1;
		
		if (A[i][0] !=0) {
			sc = A[i][0] / abs(A[i][0]);
		}
		for (int j=0; j<m; j++) {
			A[i][j] *= sc;
			if (i==j)
				left[i][j] = sc;
		}
	}
	
	// Massage the column i
	for (int i=0; i<m; i++) {
		if (A[i][0] != 0) {
			swapRows(A, 0, i);
			swapRows(left, 0, i);
			break;
		}
	}
	
	
	
	for (int j=1; j<m; j++) {
		while (A[j][0] % A[0][0] !=0) {
			long scalar = -A[j][0] / A[0][0];
			
			rowAddition(A, j, 0, scalar);
			rowAddition(left, j, 0, scalar);
			swapRows(A, 0, j);
			swapRows(left, 0, j);
		}
		long scalar = -A[j][0]/A[0][0];
		rowAddition(A, j, 0, scalar);
		rowAddition(left, j, 0, scalar);
	}
	
	// Massage the row i
	vector<vector<long> > smaller(m-1, vector<long>(m-1,0));
	for (int i=0; i<m-1; i++)
		for (int j=0; j<m-1; j++)
			smaller[i][j] = A[i+1][j+1];
	
	vector<vector<long> > vect(1, vector<long>(m-1,0));
	for (int i=0; i<m-1; i++)
		vect[0][i] = A[0][i+1];
	smaller = inverseMatUnimod(smaller);
	vect = matrixMultiplication(vect,smaller);
	
	vector<vector<long> > left2(m, vector<long>(m,0));
	for (int i=0; i<m; i++) {
		for (int j=0; j<m; j++) {
			if (i==0 && i!=j)
				left2[i][j] = -vect[0][j-1];
			else if (i==j)
				left2[i][i] = 1;
		}
	}
	
	vector<vector<long> > left3(m, vector<long>(m,0));
	left3[0][0] = 1;
	for (int i=1; i<m; i++) {
		left3[0][i] = 0;
		left3[i][0] = 0;
	}
	for (int i=1; i<m; i++)
		for (int j=1; j<m; j++)
			left3[i][j] = smaller[i-1][j-1];
	
	vector<vector<long> > result = matrixMultiplication(left2, left);
	result = matrixMultiplication(left3, result);
	return result;
}

/* Copy matrix
 */
vector<vector<long> > copyMatrix(vector<vector<long> > const& mat) {
	vector<vector<long> > copyMat(mat.size(), vector<long>(mat[0].size()) );
	
	for (int i=0; i<mat.size(); i++)
		for (int j=0; j<mat[0].size(); j++)
			copyMat[i][j] = mat[i][j];
	
	return copyMat;
}

/* SwapRows
 */
void swapRows(vector<vector<long> > &mat, int i1, int i2) {
	vector<long> rowTemp(mat[0].size());
	
	// rowTemp <= Row i1
	for (int j=0; j<mat[0].size(); j++)
		rowTemp[j] = mat[i1][j];
	
	// Row i1 <= Row i2
	for (int j=0; j<mat[0].size(); j++)
		mat[i1][j] = mat[i2][j];
	
	// Row i2 <= rowTemp
	for (int j=0; j<mat[0].size(); j++)
		mat[i2][j] = rowTemp[j];
	
	return;
}

/* RowAddition L_i1 <- L_i1 + scalar*L_i2
 */
void rowAddition(vector<vector<long> > &mat, int i1, int i2, int scalar) {
	for (int j=0; j<mat[0].size(); j++)
		mat[i1][j] += scalar*mat[i2][j];
	return;
}

/* Matrix multiplication
 */
vector<vector<long> > matrixMultiplication(vector<vector<long> > const& mat1, vector<vector<long> > const& mat2) {
	assert(mat1[0].size()==mat2.size());
	
	vector<vector<long> > retMat(mat1.size(), vector<long>(mat2[0].size()) );
	
	for (int i=0; i<mat1.size(); i++)
		for (int j=0; j<mat2[0].size(); j++)
			for (int k=0; k<mat1[0].size(); k++)
				retMat[i][j] += mat1[i][k] * mat2[k][j];
	
	return retMat;
}

