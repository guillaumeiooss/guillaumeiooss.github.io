// Standalone C++ version of CART
// Copyright Guillaume Iooss, 2014, All right reserved.

#ifndef __LINALG_H
#define __LINALG_H

#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <cmath>
#include <math.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;

// Get the submatrix of a matrix composed of the columns going from j1 to j2 (both inclusif)
vector<vector<long> > submatrixColumn(vector<vector<long> > const& A, int j1, int j2);


// Given a polyhedron and a matrix, compute the resulting polyhedron after a change of basis
vector<vector<long> > changeOfBasis(vector<vector<long> > poly, int nParam, int nInd, vector<vector<long> > mat);

// Inversion of a unimodular matrix
vector<vector<long> > inverseMatUnimod(vector<vector<long> > const& unimodMatinv);

// Copy of a matrix
vector<vector<long> > copyMatrix(vector<vector<long> > const& mat);

// Swap rows i1 and i2 of a matrix
void swapRows(vector<vector<long> > &mat, int i1, int i2);

// Perform the row operation on mat: L_i1 <- L_i1 + scalar*L_i2
void rowAddition(vector<vector<long> > &mat, int i1, int i2, int scalar);

// Matrix multiplication mat1*mat2
vector<vector<long> > matrixMultiplication(vector<vector<long> > const& mat1, vector<vector<long> > const& mat2);

#endif

