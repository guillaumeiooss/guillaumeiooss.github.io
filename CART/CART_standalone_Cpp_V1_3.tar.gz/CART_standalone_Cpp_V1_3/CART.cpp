// Standalone C++ version of CART
// Copyright Guillaume Iooss, 2014, All right reserved.

#include "CART.h"


int _kMinMaxOption = 0;

// Option to select which mode of computation we take for kmin/kmax
// 	* 0 = compute a kMin/kMax for every possible values of "b".
// 	* 1 = compute a tighter kMin/kMax by assuming that "b" is "big enough".
void changekMinMaxOption(int newOption) {
	_kMinMaxOption = newOption;
	return;
};



list<list<vector<vector<long> > > > getTiledDomain(vector<vector<long> > const& polyScalar, const int nParam, const int nInd, vector<int> const& scale, bool areParamDiv, int minBlSizeParam) {
	
	// Assertions on the input of the program
	assert(polyScalar[0].size()==nParam+nInd+2);
	assert(scale.size()==nInd);
	assert(minBlSizeParam>=1);
	
	list<list<vector<vector<long> > > > resDom;		// Returned structure
	
	// Special case: the polyhedron do not have any indexes (nInd=0) => We return a similar polyhedron (with the right amout of parameters)
	if (nInd==0) {
		vector<vector<long> > nullPoly(1);
		vector<long> emptyConstr(2*nParam+2);
		nullPoly[0] = emptyConstr;
		
		list<vector<vector<long> > > templist;
		templist.push_back(nullPoly);
		resDom.push_back(templist);
		
		return resDom;
	}
	
	
	// Extraction of the informations
	vector<vector<long> > linPart = submatrixColumn(polyScalar, 1, nInd);
	vector<vector<long> > paramPart = submatrixColumn(polyScalar, nInd+1, polyScalar[0].size()-2);
	vector<long> constPart(linPart.size());
	for (int i=0; i<polyScalar.size(); i++)
		constPart[i] = polyScalar[i][polyScalar[0].size()-1];
		
	// TODO: deal with equalities ??? (transform them into inequalities)
	
	
	// Computation of kmin/kmax
	vector<long> kmax(linPart.size());
	vector<long> kmin(linPart.size());
	
	for (int i=0; i<linPart.size(); i++) {
		long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
		long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
		
		for (int j=0; j<linPart[i].size(); j++) {
			if (linPart[i][j]>0)
				tempkmax += scale[j] * linPart[i][j];
			else if (linPart[i][j]<0)
				tempkmin += scale[j] * linPart[i][j];
		}
		
		for (int j=0; j<paramPart[i].size(); j++) {
			if (paramPart[i][j]>0)
				tempkmax += paramPart[i][j];
			else if (paramPart[i][j]<0)
				tempkmin += paramPart[i][j];
		}
		
		// kmax
		if (constPart[i]-tempkmax>=0) {
			if (_kMinMaxOption==0)
				kmax[i] = tempkmax + (long) floor( ((double) (constPart[i] - tempkmax)) / ((double) minBlSizeParam) );
			else
				kmax[i] = tempkmax;
		} else
			kmax[i] = tempkmax-1;
		
		// kmin
		if (constPart[i]-tempkmin>=0)
			kmin[i] = tempkmin;
		else {
			if (_kMinMaxOption==0)
				kmin[i] = tempkmin + (long) floor( ((double) (constPart[i] - tempkmin)) / ((double) minBlSizeParam) );
			else
				kmin[i] = tempkmin-1;
		}
	}
	
	
	/* DEBUG - kmin / kmax
	cout << "DEBUG: kmin - kmax" << endl;
	for (int i=0; i<linPart.size(); i++)
		cout << "kmin[" << i << "] = " << kmin[i] << "  |  kmax[" << i << "] = " << kmax[i] << endl;
	cout << endl;
	//*/
	
	
	for (int i=0; i<linPart.size(); i++) {				// We consider the ith constraint (outer intersection)
		list< vector< vector<long> > > domIthList;
		
		if (areParamDiv) {
			// We consider all the different cases arising with the constraint (inner union)
			for (long k=kmin[i]+1; k<=kmax[i]; k++) {
				// * Case k > kmin
				
				// In Polylib format, the matrix of constraint is:
				//
				// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
				//
				// [ 1    Qp_i,*    0      0    Q_i,*.D   0     k   ]
				// [ 0      0     Qp_i,*  -k        0     Q     q   ]
				// [ 0      0       0      0        0     Id    0   ]
				// [ 0      0       0     D.1       0    -Id   -1   ]
				// [ 1      0      Id      0        0     0     0   ]
				// [ 0      0       0      1        0     0   -minb ]
				//
				// First column: 0=inequality / 1 = equality
				// \rho = blocked parameters / pp = local parameters / b = block size parameter
				// \alpha = blocked index parameter / ii = local index parameter
				
				vector<vector<long> > blockedConstr(3+2*nInd+nParam);
				for (int l=0; l<3+2*nInd+nParam; l++) {
				 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
				 	blockedConstr[l] = tempVect;
				}
				
				// (First line)
				blockedConstr[0][0] = 1;
				for (int j=0; j<nParam; j++) {
					blockedConstr[0][j+1] = paramPart[i][j];
				}
				for (int j=0; j<nInd; j++)
					blockedConstr[0][j+2+2*nParam] = linPart[i][j] * ((long) scale[j]);
				blockedConstr[0][blockedConstr[0].size()-1] = k;
				
				// (Second line)
				for (int j=0; j<nParam; j++)
					blockedConstr[1][j+1+nParam] = paramPart[i][j];
				blockedConstr[1][1+2*nParam] = -k;
				for (int j=0; j<nInd; j++)
					blockedConstr[1][2+2*nParam+nInd+j] = linPart[i][j];
				blockedConstr[1][blockedConstr[0].size()-1] = constPart[i];
				
				// (Third lines)
				for (int j=0; j<nInd; j++)
					blockedConstr[2+j][2+2*nParam+nInd+j] = 1;
				
				// (Fourth lines)
				for (int j=0; j<nInd; j++) {
					blockedConstr[2+nInd+j][1+2*nParam] = ((long) scale[j]);
					blockedConstr[2+nInd+j][2+2*nParam+nInd+j] = -1;
					blockedConstr[2+nInd+j][blockedConstr[0].size()-1] = -1;
				}
				
				// (Fifth lines)
				for (int j=0; j<nParam; j++) {
					blockedConstr[2+2*nInd+j][0] = 1;
					blockedConstr[2+2*nInd+j][1+nParam+j] = 1;
				}
				
				// (Sixth line)
				blockedConstr[2+2*nInd+nParam][1+2*nParam] = 1;
				blockedConstr[2+2*nInd+nParam][blockedConstr[0].size()-1] = -minBlSizeParam;
				
				vector<vector<long> > nblockedConstr = wrapperMatrixPolyhedron(blockedConstr, 2*nInd);
				domIthList.push_back(nblockedConstr);
			}
			
			// * Case k = kmin
			
			// In Polylib format, the matrix of constraint is:
			//
			// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
			//
			// [ 0    Qp_i,*     0     0    Q_i,*.D   0    kmin ]
			// [ 0      0        0     0        0     Id    0   ]
			// [ 0      0        0    D.1       0    -Id   -1   ]
			// [ 0      0       0      1        0     0   -minb ]
			// [ 1      0      Id      0        0     0     0   ]
			//
			// First column: 0=inequality / 1 = equality
			// \rho = blocked parameters / pp = local parameters / b = block size parameter
			// \alpha = blocked index parameter / ii = local index parameter
	
			vector<vector<long> > blockedConstr(2+2*nInd+nParam);
			for (int l=0; l<2+2*nInd+nParam; l++) {
			 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
			 	blockedConstr[l] = tempVect;
			}
	
			// (First line)
			for (int j=0; j<nParam; j++)
				blockedConstr[0][1+j] = paramPart[i][j];
			for (int j=0; j<nInd; j++)
				blockedConstr[0][2+2*nParam+j]= linPart[i][j] * ((long) scale[j]);
			blockedConstr[0][blockedConstr[0].size()-1] = kmin[i];
	
			// (Second lines)
			for (int j=0; j<nInd; j++)
				blockedConstr[1+j][2+2*nParam+nInd+j] = 1;
	
			// (Fourth lines)
			for (int j=0; j<nInd; j++) {
				blockedConstr[1+nInd+j][1+2*nParam] = ((long) scale[j]);
				blockedConstr[1+nInd+j][2+2*nParam+nInd+j] = -1;
				blockedConstr[1+nInd+j][blockedConstr[0].size()-1] = -1;
			}
			
			// (Fifth line)
			blockedConstr[1+2*nInd][1+2*nParam] = 1;
			blockedConstr[1+2*nInd][blockedConstr[0].size()-1] = -minBlSizeParam;
			
			// (Sixth lines)
			for (int j=0; j<nParam; j++) {
				blockedConstr[2+2*nInd+j][0] = 1;
				blockedConstr[2+2*nInd+j][1+nParam+j] = 1;
			}
			
			vector<vector<long> > nblockedConstr = wrapperMatrixPolyhedron(blockedConstr, 2*nInd);
			domIthList.push_back(nblockedConstr);
		} else {
			
			// We consider all the different cases arising with the constraint (inner union)
			for (long k=kmin[i]+1; k<=kmax[i]; k++) {
				// * Case k > kmin
				
				// In Polylib format, the matrix of constraint is:
				//
				// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
				//
				// [ 1    Qp_i,*    0      0    Q_i,*.D   0     k   ]
				// [ 0      0     Qp_i,*  -k        0     Q     q   ]
				// [ 0      0       0      0        0     Id    0   ]
				// [ 0      0       0     D.1       0    -Id   -1   ]
				// [ 0      0       0      1        0     0   -minb ]
				//
				// First column: 0=inequality / 1 = equality
				// \rho = blocked parameters / pp = local parameters / b = block size parameter
				// \alpha = blocked index parameter / ii = local index parameter
				vector<vector<long> > blockedConstr(3+2*nInd);
				for (int l=0; l<3+2*nInd; l++) {
				 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
				 	blockedConstr[l] = tempVect;
				}
				
				// (First line)
				blockedConstr[0][0] = 1;
				for (int j=0; j<nParam; j++) {
					blockedConstr[0][j+1] = paramPart[i][j];
				}
				for (int j=0; j<nInd; j++)
					blockedConstr[0][j+2+2*nParam] = linPart[i][j] * ((long) scale[j]);
				blockedConstr[0][blockedConstr[0].size()-1] = k;
				
				// (Second line)
				for (int j=0; j<nParam; j++)
					blockedConstr[1][j+1+nParam] = paramPart[i][j];
				blockedConstr[1][1+2*nParam] = -k;
				for (int j=0; j<nInd; j++)
					blockedConstr[1][2+2*nParam+nInd+j] = linPart[i][j];
				blockedConstr[1][blockedConstr[0].size()-1] = constPart[i];
				
				// (Third lines)
				for (int j=0; j<nInd; j++)
					blockedConstr[2+j][2+2*nParam+nInd+j] = 1;
				
				// (Fourth lines)
				for (int j=0; j<nInd; j++) {
					blockedConstr[2+nInd+j][1+2*nParam] = ((long) scale[j]);
					blockedConstr[2+nInd+j][2+2*nParam+nInd+j] = -1;
					blockedConstr[2+nInd+j][blockedConstr[0].size()-1] = -1;
				}
				
				// (Fifth line)
				blockedConstr[2+2*nInd][1+2*nParam] = 1;
				blockedConstr[2+2*nInd][blockedConstr[0].size()-1] = -minBlSizeParam;
				
				vector<vector<long> > nblockedConstr = wrapperMatrixPolyhedron(blockedConstr, 2*nInd);
				domIthList.push_back(nblockedConstr);
			}
			
			// * Case k = kmin
			
			// In Polylib format, the matrix of constraint is:
			//
			// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
			//
			// [ 0    Qp_i,*     0     0    Q_i,*.D   0    kmin ]
			// [ 0      0        0     0        0     Id    0   ]
			// [ 0      0        0    D.1       0    -Id   -1   ]
			// [ 0      0       0      1        0     0   -minb ]
			//
			// First column: 0=inequality / 1 = equality
			// \rho = blocked parameters / pp = local parameters / b = block size parameter
			// \alpha = blocked index parameter / ii = local index parameter
	
			vector<vector<long> > blockedConstr(2+2*nInd);
			for (int l=0; l<2+2*nInd; l++) {
			 	vector<long> tempVect = vector<long>(3+2*nParam+2*nInd);
			 	blockedConstr[l] = tempVect;
			}
	
			// (First line)
			for (int j=0; j<nParam; j++)
				blockedConstr[0][1+j] = paramPart[i][j];
			for (int j=0; j<nInd; j++)
				blockedConstr[0][2+2*nParam+j]= linPart[i][j] * ((long) scale[j]);
			blockedConstr[0][blockedConstr[0].size()-1] = kmin[i];
	
			// (Second lines)
			for (int j=0; j<nInd; j++)
				blockedConstr[1+j][2+2*nParam+nInd+j] = 1;
	
			// (Fourth lines)
			for (int j=0; j<nInd; j++) {
				blockedConstr[1+nInd+j][1+2*nParam] = ((long) scale[j]);
				blockedConstr[1+nInd+j][2+2*nParam+nInd+j] = -1;
				blockedConstr[1+nInd+j][blockedConstr[0].size()-1] = -1;
			}
			
			// (Fifth line)
			blockedConstr[1+2*nInd][1+2*nParam] = 1;
			blockedConstr[1+2*nInd][blockedConstr[0].size()-1] = -minBlSizeParam;
			
			vector<vector<long> > nblockedConstr = wrapperMatrixPolyhedron(blockedConstr, 2*nInd);
			domIthList.push_back(nblockedConstr);
		}
		
		resDom.push_back(domIthList);
	}
	
	return resDom;
}


list<list<vector<vector<long> > > > getTiledDomain_scheduled(vector<vector<long> > const& polyScalar, const int nParam, const int nInd, vector<int> const& scale, bool areParamDiv, int minBlSizeParam, vector<vector<long> > const& matSkewing) {
	
	// *** Initial skewing of the polyhedron
	vector<vector<long> > polyScalar1 = changeOfBasis(polyScalar, nParam, nInd, matSkewing);
	
	/* DEBUG
	for (int i=0; i<polyScalar1.size(); i++) {
		cout << "[ ";
		for (int j=0; j<polyScalar1[0].size(); j++) {
			cout << polyScalar1[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	cout << "*********************************************" << endl;
	//*/
	
	
	// *** CART in the skewed space
	list<list<vector<vector<long> > > > lDomCART = getTiledDomain(polyScalar1, nParam, nInd, scale, areParamDiv, minBlSizeParam);
	
	/* DEBUG
	for (list<list<vector<vector<long> > > >::iterator lDom=lDomCART.begin(); lDom!=lDomCART.end(); lDom++) {
		cout << "	[[[" << endl;
		for (list<vector<vector<long> > >::iterator poly=lDom->begin(); poly!=lDom->end(); poly++) {
			for (vector<vector<long> >::iterator it1=poly->begin(); it1!=poly->end(); it1++) {
				cout << "		(";
				for (vector<long>::iterator it2=it1->begin(); it2!=it1->end(); it2++)
					cout << " " << (*it2);
				cout << " )" << endl;
			}
			cout << endl;
		}
		cout << "]]]" << endl;
	}
	//*/
	
	
	// *** Deskewing of the obtained polyhedra
	// Extraction of the informations of matSkewing
	vector<vector<long> > linPartMat = submatrixColumn(matSkewing, 0, nInd-1);
	vector<vector<long> > paramPartMat = submatrixColumn(matSkewing, nInd, nInd+nParam-1);
	vector<long> constMat(matSkewing.size());
	for (int i=0; i<matSkewing.size(); i++)
		constMat[i] = matSkewing[i][matSkewing[0].size()-1];
	
	vector<vector<long> > linPartMatInv = inverseMatUnimod(linPartMat);
	
	// If matSkewing = [A | B | c] for the linear, parametric and constant part, then
	// (\alpha,ii) = (Ainv*D*\alpha' - Ainv*B*\rho,  Ainv*ii - Ainv*B*pp - Ainv*c)
	// We need to take the image of every CARTed domain through this affine function
	//	=> Trick, taking the image of a polyhedron through this function is the same than taking the preimage of this polyhedron through:
	// (\alpha',ii') = (D^-1*(A*\alpha+B*\rho), (A*ii+B*pp+c) )
	//
	//	=> Issue => D^-1 might introduce rationnal coefficients
	// 	=> Solution: multiply the whole inequality by the corresponding coefficient
	long d = 1;
	for (int k=0; k<scale.size(); k++)
		d = ppcm(d, scale[k]);
	
	list<list<vector<vector<long> > > > nlDomCART;
	for (list<list<vector<vector<long> > > >::iterator it1 = lDomCART.begin(); it1!=lDomCART.end(); it1++) {
	
		list<vector<vector<long> > > templCART;
		for (list<vector<vector<long> > >::iterator it2 = it1->begin(); it2!=it1->end(); it2++) {
			vector<vector<long> > matPoly = *it2;
			vector<vector<long> > nMatPoly(matPoly.size(), vector<long>(3+2*nParam+2*nInd,0));
			for (int rowNum=0; rowNum<matPoly.size(); rowNum++) {
				nMatPoly[rowNum][0] = matPoly[rowNum][0]; 
				
				// \alpha : Q^(\alpha)*(d*scaleInv)*A
				vector<long> Qalpha(nInd);
				for (int k=0; k<nInd; k++)
					Qalpha[k] = matPoly[rowNum][k+1] * (d / scale[k]);
				for (int k=0; k<nInd; k++)
					for (int l=0; l<linPartMat.size(); l++)
						nMatPoly[rowNum][k+1] += Qalpha[l] * linPartMat[l][k];
				
				// ii : Q^{ii} * A * d
				for (int k=0; k<nInd; k++)
					for (int l=0; l<linPartMat.size(); l++)
						nMatPoly[rowNum][1+nInd+k] += d * matPoly[rowNum][1+nInd+l] * linPartMat[l][k];
				
				// \rho : d*Q^{\rho} + Q^{\alpha}*(d*scaleInv)*B
				for (int k=0; k<nParam; k++) {
					nMatPoly[rowNum][1+2*nInd+k] = d*matPoly[rowNum][1+2*nInd+k];
					for (int l=0; l<paramPartMat.size();l++)
						nMatPoly[rowNum][1+2*nInd+k] += matPoly[rowNum][l+1] * (d / scale[l]) * paramPartMat[l][k];
				}
				
				// pp + b : d*Q^{pp} + d*Q^{ii}*B
				for (int k=0; k<nParam+1; k++) {
					nMatPoly[rowNum][1+2*nInd+nParam+k] = d * matPoly[rowNum][1+2*nInd+nParam+k];
					for (int l=0; l<paramPartMat.size();l++)
						nMatPoly[rowNum][1+2*nInd+nParam+k] += matPoly[rowNum][l+1] * d * paramPartMat[l][k];
				}
				
				// Const: d*Q^{ii}*c + d*q
				nMatPoly[rowNum][nMatPoly[0].size()-1] = d*matPoly[rowNum][matPoly[rowNum].size()-1];
				for (int k=0; k<constMat.size(); k++)
					nMatPoly[rowNum][nMatPoly[0].size()-1] += d * matPoly[rowNum][1+nInd+k] * constMat[k];
			}
			templCART.push_back(nMatPoly);
		}
		nlDomCART.push_back(templCART);
	}
	
	return nlDomCART;
}

long pgcd(long a, long b) {
	if (a<0)
		a = -a;
	if (b<0)
		b = -b;
	if (b==0)
		return a;
	return pgcd(b, a%b);
}

long ppcm(long a, long b) {
	long g = pgcd(a,b);
	long temp = a/g;
	return b*temp;
}




map<vector<vector<long> >,vector<vector<long> > > getTiledFunction(vector<vector<long> > const& affScalar, int const nInd, int const nParam, vector<int> const& scale, vector<int> const& scaleIm, bool const areParamDiv, int const minBlSizeParam) {

	// Assertions on the input of the program
	assert(affScalar[0].size()==nInd+nParam+1);
	assert(scale.size()==nInd);
	assert(scaleIm.size()==affScalar.size());
	assert(minBlSizeParam>=1);
	
	map<vector<vector<long> >,vector<vector<long> > > result;		// Result
	
	// Special case: image dimension is of dimension 0
	if (affScalar.size()==0) {
		vector<vector<long> > matConstr(1);
		vector<long> constrEmpty(2+2*nParam+2*nInd);
		matConstr.push_back(constrEmpty);
		
		vector<vector<long> > matValue(0);
		
		result.insert ( pair<vector<vector<long> >, vector<vector<long> > >(matConstr, matValue) );
		return result;
	}
	
	// Extraction of the informations
	vector<vector<long> > paramPart = submatrixColumn(affScalar, nInd, nParam+nInd-1);
	vector<vector<long> > linPart = submatrixColumn(affScalar, 0, nInd-1);
	vector<long> constPart(affScalar.size());
	for (int i=0; i<affScalar.size(); i++)
		constPart[i] = affScalar[i][affScalar[0].size()-1];
	
	
	// We compute kmin and kmax (in the same manner (and with the same limitation) than for the domains -cf comments in "getTiledDomain")
	vector<long> kmax(linPart.size());
	vector<long> kmin(linPart.size());
	
	for (int i=0; i<linPart.size(); i++) {
		long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
		long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
		
		for (int j=0; j<linPart[i].size(); j++) {
			if (linPart[i][j]>0)
				tempkmax += scale[j] * linPart[i][j];
			else if (linPart[i][j]<0)
				tempkmin += scale[j] * linPart[i][j];
		}
		
		for (int j=0; j<paramPart[i].size(); j++) {
			if (paramPart[i][j]>0)
				tempkmax += paramPart[i][j];
			else if (paramPart[i][j]<0)
				tempkmin += paramPart[i][j];
		}
		
		// kmax
		if (constPart[i]-tempkmax>=0) {
			if (_kMinMaxOption==0)
				kmax[i] = tempkmax + (long) floor( ((double) (constPart[i] - tempkmax)) / ((double) minBlSizeParam) );
			else
				kmax[i] = tempkmax;
		} else
			kmax[i] = tempkmax-1;
		
		// kmin
		if (constPart[i]-tempkmin>=0)
			kmin[i] = tempkmin;
		else {
			if (_kMinMaxOption==0)
				kmin[i] = tempkmin + (long) floor( ((double) (constPart[i] - tempkmin)) / ((double) minBlSizeParam) );
			else
				kmin[i] = tempkmin-1;
		}
	}
	/* DEBUG - kmin / kmax
	for (int i=0; i<linPart.size(); i++)
		cout << "kmin[" << i << "] = " << kmin[i] << "  |  kmax[" << i << "] = " << kmax[i] << endl;
	cout << endl;
	//*/
	
	
	// Now, we build our new blocked affine functions: we have a part of piece-wise affine function per \vec{k},
	//		which is: \phi(\alpha,ii) = (Q.D.\alpha + Q_p.\rho + k  ,  Q.ii + q - b.k) when  b.k <= Q.ii+q < b.(k+1)
	// Thus, we iterate on the multi-dimensional vector k
	vector<long> kCurr(linPart.size());		// Multi-dimensional iterator
	for (int i=0; i<linPart.size(); i++)
		kCurr[i] = kmin[i];
	
	
	while (kCurr[linPart.size()-1]<=kmax[linPart.size()-1]) {
		// We build the piece-wise part corresponding to the vector "kCurr"
		// In Polylib format, the matrix of input constraints is:
		// 
		// ( eq | \rho  | pp |    b   | \alpha | ii |  const )    <= Row to know which column corresponds to what...
		// 
		// [ 0      0     Qp    -D'.k     0       Q      q     ]
		// [ 0      0    -Qp   D'.(k+1)   0      -Q   -D'.1-q  ]
		// [ 0      0      0      0       0      Id      0     ]
		// [ 0      0      0     D.1      0     -Id     -1     ]
		// [ 0      0      0      1       0       0    -minb   ]
		
		// If divisible: 
		// [ 1      0     Id      0       0       0      0     ]
		
		// 
		// First column: 0=inequality / 1 = equality
		// \rho = blocked parameters / pp = local parameters / b = block size parameter
		// \alpha = blocked index parameter / ii = local index parameter
		
		// And the matrix of relations is:
		// 
		// (     \rho    |   pp   |     b    |    \alpha    | ii | const)    <= Row to know which column corresponds to what...
		//
		// [  D'^{-1}.Qp     0          0       D'^{-1}Q.D    0      k  ]
		// [      0          Qp    -D'^{-1}k        0         Q      q  ]
		//
		
		vector<vector<long> > inputConstrLongMat(1+2*linPart.size()+2*nInd+nParam);
		for (int l=0; l<1+2*linPart.size()+2*nInd+nParam; l++) {
			vector<long> tempVect(3+2*nParam+2*nInd);
			inputConstrLongMat[l] = tempVect;
		}
	
		for (int i=0; i<linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size();j++)
				inputConstrLongMat[i][1+nParam+j] = paramPart[i][j];
			inputConstrLongMat[i][1+2*nParam] = -kCurr[i] * scaleIm[i];
			for (int j=0; j<nInd; j++)
				inputConstrLongMat[i][2+2*nParam+nInd+j] = linPart[i][j];
			inputConstrLongMat[i][inputConstrLongMat[0].size()-1] = constPart[i];
		}
		
		for (int i=linPart.size(); i<2*linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size(); j++)
				inputConstrLongMat[i][1+nParam+j] = -paramPart[i-linPart.size()][j];
			inputConstrLongMat[i][1+2*nParam] = scaleIm[i-linPart.size()]* ( kCurr[i-linPart.size()]+1 );
			for (int j=0; j<nInd; j++)
				inputConstrLongMat[i][2+2*nParam+nInd+j] = -linPart[i-linPart.size()][j];
			inputConstrLongMat[i][inputConstrLongMat[0].size()-1] = -scaleIm[i-linPart.size()]-constPart[i-linPart.size()];
		}
		
		for (int i=0; i<nInd; i++)
			inputConstrLongMat[i+2*linPart.size()][2+2*nParam+nInd+i] = 1;
		
		for (int i=0; i<nInd; i++) {
			inputConstrLongMat[i+2*linPart.size()+nInd][1+2*nParam] = (long) scale[i];
			inputConstrLongMat[i+2*linPart.size()+nInd][2+2*nParam+nInd+i] = -1;
			inputConstrLongMat[i+2*linPart.size()+nInd][inputConstrLongMat[0].size()-1] = -1;
		}
		
		inputConstrLongMat[2*linPart.size()+2*nInd][1+2*nParam] = 1;
		inputConstrLongMat[2*linPart.size()+2*nInd][inputConstrLongMat[0].size()-1] = -minBlSizeParam;
		
		if (areParamDiv) {
			for (int i=0; i<nParam; i++) {
				inputConstrLongMat[2*linPart.size()+2*nInd+i][0] = 1;
				inputConstrLongMat[2*linPart.size()+2*nInd+i][1+nParam+i] = 1;
			}
		}
		
		inputConstrLongMat = wrapperMatrixPolyhedron(inputConstrLongMat, 2*nInd);
		
		/* DEBUG
		cout << " * inputConstrLongMat:" << endl;
		for (int i=0; i<inputConstrLongMat.size(); i++) {
			for (int j=0; j<inputConstrLongMat[0].size(); j++)
				cout << inputConstrLongMat[i][j] << " ";
			cout << endl;
		}
		cout << endl;
		//*/
		
		vector<vector<long> > relationConstrLongMat(2*linPart.size());
		for (int l=0; l<2*linPart.size(); l++) {
			vector<long> tempVect(2+2*nParam+2*nInd);
			relationConstrLongMat[l] = tempVect;
		}
		
		for (int i=0; i<linPart.size(); i++) {
			for (int j=0; j<nParam; j++) {
				long temp = (long) (paramPart[i][j]/scaleIm[i]);
				if (temp*scaleIm[i] != paramPart[i][j]) {
					cerr << "The resulting affine function has Z-polyhedral constraints (param | i = " << i << " | j = " << j << " )" << endl;
					exit(-1);
				}
				relationConstrLongMat[i][j] = temp;
			}
			for (int j=0; j<nInd; j++) {
				long temp = (long) (linPart[i][j] * scale[j] / scaleIm[i]);
				if (temp*scaleIm[i] != linPart[i][j] * scale[j]) {
					cerr << "The resulting affine function has Z-polyhedral constraints (linear | i = " << i << " | j = " << j << " )" << endl;
					exit(-1);
				}
				relationConstrLongMat[i][1+2*nParam+j] = temp;
			}
			relationConstrLongMat[i][relationConstrLongMat[0].size()-1] = kCurr[i];
		}
		for (int i=linPart.size(); i<2*linPart.size(); i++) {
			for (int j=0; j<paramPart[0].size();j++)
				relationConstrLongMat[i][nParam+j] = paramPart[i-linPart.size()][j];
			relationConstrLongMat[i][2*nParam] = -scaleIm[i-linPart.size()]*kCurr[i-linPart.size()];
			for (int j=0; j<nInd; j++)
				relationConstrLongMat[i][1+2*nParam+nInd+j] = linPart[i-linPart.size()][j];
			relationConstrLongMat[i][relationConstrLongMat[0].size()-1] = constPart[i-linPart.size()];
		}
		
		vector<vector<long> > nrelationConstrLongMat = wrapperMatrixFunction(relationConstrLongMat, 2*nInd);
		
		/* DEBUG
		cout << " * relationConstrLongMat:" << endl;
		for (int i=0; i<relationConstrLongMat.size(); i++) {
			for (int j=0; j<relationConstrLongMat[0].size(); j++)
				cout << (relationConstrLongMat[i][j] << " ";
			cout << endl;
		}
		cout << endl;
		//*/
		
		result.insert ( pair<vector<vector<long> >, vector<vector<long> > >(inputConstrLongMat, nrelationConstrLongMat) );
		
		// We increase the multi-dimensional iterator, starting from the first dimension and propagating the overflows
		kCurr[0]++;
		for (int i=0; i<linPart.size()-1; i++)
			if (kCurr[i]>kmax[i]) {
				kCurr[i] = kmin[i];
				kCurr[i+1]++;
			}
	} // End of multi-dimensional loop
	
	return result;
}


/* ---------------------------------------------------------------------------------------------------------- */

// Wrapper to output the matrix of a polyhedron
//		- correct the 0/1 column (switch 0 and 1 to be conform to polylib format)
//		- switch the parameter and index columns
vector<vector<long> > wrapperMatrixPolyhedron(vector<vector<long> > matPoly, int nInd) {
	
	/* DEBUG
	for (int i=0; i<matPoly.size(); i++) {
		cout << "[ ";
		for (int j=0; j<matPoly[0].size(); j++) {
			cout << matPoly[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	//*/
	
	vector<vector<long> > nMatPoly(matPoly.size(), vector<long>(matPoly[0].size()));
	int nParam = matPoly[0].size()-2-nInd;
	
	for (int i=0; i<matPoly.size(); i++) {
		nMatPoly[i][0] = 1-matPoly[i][0];		// 0/1
		for (int j=0; j<nParam; j++)
			nMatPoly[i][j+1+nInd] = matPoly[i][1+j];
		for (int j=0; j<nInd; j++)
			nMatPoly[i][j+1] = matPoly[i][j+1+nParam];
		nMatPoly[i][nMatPoly[0].size()-1] = matPoly[i][matPoly[0].size()-1];
	}
	
	/* DEBUG
	for (int i=0; i<nMatPoly.size(); i++) {
		cout << "[ ";
		for (int j=0; j<nMatPoly[0].size(); j++) {
			cout << nMatPoly[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	//*/
	
	return nMatPoly;
}

vector<vector<long> > wrapperMatrixFunction(vector<vector<long> > matFunc, int nInd) {
	/* DEBUG
	cout << nInd << endl;
	for (int i=0; i<matFunc.size(); i++) {
		cout << "[ ";
		for (int j=0; j<matFunc[0].size(); j++) {
			cout << matFunc[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	//*/
	
	
	vector<vector<long> > nmatFunc(matFunc.size(), vector<long>(matFunc[0].size()));
	int nParam = matFunc[0].size()-1-nInd;
	
	for (int i=0; i<matFunc.size(); i++) {
		for (int j=0; j<nParam; j++)
			nmatFunc[i][j+nInd] = matFunc[i][j];
		
		for (int j=0; j<nInd; j++)
			nmatFunc[i][j] = matFunc[i][j+nParam];
		nmatFunc[i][nmatFunc[0].size()-1] = matFunc[i][matFunc[0].size()-1];
	}
	
	/* DEBUG
	for (int i=0; i<nmatFunc.size(); i++) {
		cout << "[ ";
		for (int j=0; j<nmatFunc[0].size(); j++) {
			cout << nmatFunc[i][j] << " ";
		}
		cout << "]" << endl;
	}
	cout << endl;
	//*/
	
	
	return nmatFunc;
}




