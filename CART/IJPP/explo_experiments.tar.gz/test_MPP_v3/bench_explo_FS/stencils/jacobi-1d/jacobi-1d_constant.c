void kernel_jacobi_1d()
{
  int t, i;

  int TSTEPS = 64;
  int N = 512;

  double* A;
  double* B;

  //A is N
  //B is N

#pragma begin_scop

  for (t = 0; t < TSTEPS; t++)
    {
      for (i = 1; i < N - 1; i++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[t][2*t+i]
#pragma schedule[__T][__T][t][2*t+i][0]
	B[i] = 0.33333 * (A[i-1] + A[i] + A[i + 1]);
      for (i = 1; i < N - 1; i++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[t][2*t+i+1]
#pragma schedule[__T][__T][t][2*t+i+1][1]
	A[i] = 0.33333 * (B[i-1] + B[i] + B[i + 1]);
    }

#pragma end_scop

}
