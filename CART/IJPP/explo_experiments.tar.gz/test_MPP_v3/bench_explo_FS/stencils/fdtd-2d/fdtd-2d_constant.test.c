#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "fdtd-2d_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 4) {
    printf("Expecting 3 arguments, not %i.\n", (argc-1));
    printf("Expecting NX, NY, TMAX\n");
    exit(0);
  }

  int NX = extract_int_arg(argv, 1);
  int NY = extract_int_arg(argv, 2);
  int TMAX = extract_int_arg(argv, 3);

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_1D_ARRAY_DECL(_fict_,double,TMAX, TMAX);
  POLYBENCH_2D_ARRAY_DECL(ex,double,NX,NY, NX,NY);
  POLYBENCH_2D_ARRAY_DECL(ey,double,NX,NY, NX,NY);
  POLYBENCH_2D_ARRAY_DECL(hz,double,NX,NY, NX,NY);
  
  
  init1_1(TMAX,&elem1_1, POLYBENCH_ARRAY(_fict_));
  init2_3(NX,NY, NX,&elem_polyb_2_1_stencil_1, POLYBENCH_ARRAY(ex));
  init2_3(NX,NY, NY,&elem_polyb_2_1_stencil_2, POLYBENCH_ARRAY(ey));
  init2_3(NX,NY, NX,&elem_polyb_2_1_stencil_3, POLYBENCH_ARRAY(hz));

  

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(NX, NY, TMAX, POLYBENCH_ARRAY(_fict_), POLYBENCH_ARRAY(ex),
        POLYBENCH_ARRAY(ey), POLYBENCH_ARRAY(hz));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(NX, NY,  POLYBENCH_ARRAY(hz)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(_fict_);
  POLYBENCH_FREE_ARRAY(ex);
  POLYBENCH_FREE_ARRAY(ey);
  POLYBENCH_FREE_ARRAY(hz);


  return 0;
}
