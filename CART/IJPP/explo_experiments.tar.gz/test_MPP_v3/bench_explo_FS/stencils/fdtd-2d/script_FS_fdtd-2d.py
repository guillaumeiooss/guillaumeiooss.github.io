
# === Generation of the FS tiled programs (using "mppcodegen") ===

# Usage of the python script:
#	python3.6 gen_tied_prog.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"

import subprocess
import re, sys
import os.path

# Problem definition (to be changed across kernels)
kernel_name = "fdtd-2d"
prog_sizes = ["1000", "1200", "500"]
kernel_arguments = [
	"int NX",
	"int NY",
	"int TMAX",
  	"double POLYBENCH_1D(_fict_, TMAX, TMAX)",
  	"double POLYBENCH_2D(ex, NX,NY, NX,NY)",
  	"double POLYBENCH_2D(ey, NX,NY, NX,NY)",
  	"double POLYBENCH_2D(hz, NX,NY, NX,NY)"
  ]

utilities_folder_path = "../../utilities"
# linear-algebra : 3 "../"
# others: 2 "../"

vectorization_report_enable = False

dim_tile_size = 3

# Launch script!
exec(open(utilities_folder_path + "/script_common_gen_tiled.py").read())
