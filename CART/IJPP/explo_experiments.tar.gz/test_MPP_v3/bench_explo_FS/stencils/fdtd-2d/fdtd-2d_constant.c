void kernel_fdtd_2d()
{
  int t, i, j;

  int TMAX = 64;
  int NX = 64;
  int NY = 64;

  double** ex;
  double** ey;
  double** hz;
  double* _fict_;

  //ex is NXxNY
  //ey is NXxNY
  //hz is NXxNY
  //_fict_ is TMAX

#pragma begin_scop

  for(t = 0; t < TMAX; t++)
    {
      for (j = 0; j < NY; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][t+j][t]
#pragma schedule[__T][__T][__T][t][t][t+j]
	ey[0][j] = _fict_[t];
      for (i = 1; i < NX; i++)
	for (j = 0; j < NY; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][t+j][t+i]
#pragma schedule[__T][__T][__T][t][t+i][t+j]
	  ey[i][j] = ey[i][j] - 0.5*(hz[i][j]-hz[i-1][j]);
      for (i = 0; i < NX; i++)
	for (j = 1; j < NY; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][t+j][t+i]
#pragma schedule[__T][__T][__T][t][t+i][t+j]
	  ex[i][j] = ex[i][j] - 0.5*(hz[i][j]-hz[i][j-1]);
      for (i = 0; i < NX - 1; i++)
	for (j = 0; j < NY - 1; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][t+j+1][t+i+1]
#pragma schedule[__T][__T][__T][t][t+i+1][t+j+1]
	  hz[i][j] = hz[i][j] - 0.7*  (ex[i][j+1] - ex[i][j] +
				       ey[i+1][j] - ey[i][j]);
    }

#pragma end_scop
}
