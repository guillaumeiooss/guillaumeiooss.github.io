void kernel_seidel_2d()
{
  int t, i, j;

  int TSTEPS = 32;
  int N = 256;

  double** A;

  //A is NxN
			
#pragma begin_scop
  for (t = 0; t <= TSTEPS - 1; t++)
    for (i = 1; i<= N - 2; i++)
      for (j = 1; j <= N - 2; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][t+i][2*t+i+j]
#pragma schedule[__T][__T][__T][t][t+i][2*t+i+j]
	A[i][j] = (A[i-1][j-1] + A[i-1][j] + A[i-1][j+1]
		   + A[i][j-1] + A[i][j] + A[i][j+1]
		   + A[i+1][j-1] + A[i+1][j] + A[i+1][j+1])/9.0;
#pragma end_scop

}

