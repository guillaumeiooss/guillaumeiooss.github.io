void kernel_jacobi_2d()
{
  int t, i, j;

  int TSTEPS = 32;
  int N = 256;

  double** A;
  double** B;

  //A is NxN
  //B is NxN

#pragma begin_scop

  for (t = 0; t < TSTEPS; t++)
    {
      for (i = 1; i < N - 1; i++)
	for (j = 1; j < N - 1; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][2*t+i][2*t+j]
#pragma schedule[__T][__T][__T][t][0][i][j]
	  B[i][j] = 0.2*(A[i][j] + A[i][j-1] + A[i][1+j] + A[1+i][j] + A[i-1][j]);
      for (i = 1; i < N - 1; i++)
	for (j = 1; j < N - 1; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[t][2*t+i+1][2*t+j+1]
#pragma schedule[__T][__T][__T][t][1][i][j]
	  A[i][j] = 0.2*(B[i][j] + B[i][j-1] + B[i][1+j] + B[1+i][j] + B[i-1][j]);
    }
#pragma end_scop

}

