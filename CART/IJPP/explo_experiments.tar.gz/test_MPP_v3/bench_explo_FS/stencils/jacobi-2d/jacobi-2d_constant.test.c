#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "jacobi-2d_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 3) {
    printf("Expecting 2 arguments, not %i.\n", (argc-1));
    printf("Expecting N, TSTEPS\n");
    exit(0);
  }

  int N = extract_int_arg(argv, 1);
  int TSTEPS = extract_int_arg(argv, 2);
 
  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(A,double,N,N,N,N);
  POLYBENCH_2D_ARRAY_DECL(B,double,N,N,N,N);
  
  init2_3(N,N, N, &elem_polyb_2_1_stencil_4, POLYBENCH_ARRAY(A));
  init2_3(N,N, N, &elem_polyb_2_1_stencil_5, POLYBENCH_ARRAY(B));

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(N, TSTEPS, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(N, N,  POLYBENCH_ARRAY(B)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);


  return 0;
}
