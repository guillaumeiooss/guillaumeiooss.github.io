#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "heat-3d-perfect_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 3) {
    printf("Expecting 2 arguments, not %i.\n", (argc-1));
    printf("Expecting N, TSTEPS\n");
    exit(0);
  }

  int N = extract_int_arg(argv, 1);
  int TSTEPS = extract_int_arg(argv, 2);
  
  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_4D_ARRAY_DECL(A,double,TSTEPS+1,N+1,N+1,N+1, TSTEPS+1,N+1,N+1,N+1);
  
  init4_5(TSTEPS+1,N+1,N+1,N+1, N, &elem_polyb_4_1, POLYBENCH_ARRAY(A));

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(N, TSTEPS, POLYBENCH_ARRAY(A));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print4(TSTEPS+1,N+1,N+1,N+1,  POLYBENCH_ARRAY(A)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);

  return 0;
}
