void kernel_heat_3d()
{
  int t, i, j, k;

  int TSTEPS = 32;
  int N = 64;

  //FLOAT
  double**** A;

  //A is TSTEPSxNxNxN

#pragma begin_scop
    for (t = 1; t <= TSTEPS; t++) {
        for (i = 1; i < N-1; i++) {
            for (j = 1; j < N-1; j++) {
                for (k = 1; k < N-1; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16][16]
#pragma tile_hyperplans[t][t+i][t+j][t+k]
#pragma schedule[__T][__T][__T][__T][t][2*t+i][2*t+j][2*t+k][t][2*t+i][2*t+j][2*t+k]
                    A[t][i][j][k] =   0.125 * (A[t-1][i+1][j][k] - 2.0 * A[t-1][i][j][k] + A[t-1][i-1][j][k])
                                 + 0.125 * (A[t-1][i][j+1][k] - 2.0 * A[t-1][i][j][k] + A[t-1][i][j-1][k])
                                 + 0.125 * (A[t-1][i][j][k+1] - 2.0 * A[t-1][i][j][k] + A[t-1][i][j][k-1])
                                 + A[t-1][i][j][k];
                }
            }
        }
    }
#pragma end_scop

}
