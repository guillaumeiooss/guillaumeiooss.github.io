//float if_(float,float,float,float);
int if_(int,int,int,int);

void kernel_floyd_warshall()
{
  int N = 256;

  //FLOAT
  double** path;

  //path is NxN

  int i, j, k;

#pragma begin_scop
  for (k = 0; k < N; k++)
    {
      for(i = 0; i < N; i++)
	for (j = 0; j < N; j++)
	  //if(path[i][j] >= path[i][k] + path[k][j])
#pragma tile_group[0]
#pragma tile_size[1][16][16]
#pragma tile_hyperplans[k][i][j]
#pragma schedule[__T][k][__T][__T][i][j]
	  path[i][j] = path[i][j] + path[i][k] + path[k][j] + path[i][k] + path[k][j];
      //path[i][j] = if_(path[i][j],path[i][k],path[k][j],path[i][k] + path[k][j]);
    }
#pragma end_scop

}
