void kernel_lu()
{
  int i, j, k;

  int N = 512;

  double** A;

#pragma begin_scop
  for (i = 0; i < N; i++) {
    for (j = 0; j <i; j++) {
       for (k = 0; k < j; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k]
          A[i][j] = A[i][j] - A[i][k] * A[k][j];
       }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[__T][__T][__T][i][j][j]
       A[i][j] = A[i][j] / A[j][j];
    }
   for (j = i; j < N; j++) {
       for (k = 0; k < i; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k]
          A[i][j] = A[i][j] - A[i][k] * A[k][j];
       }
    }
  }
#pragma end_scop
}
