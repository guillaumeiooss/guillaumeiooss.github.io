float sqrt(float);

void kernel_gramschmidt()
{
  int i, j, k;

  double* nrm;

  int N = 256;
  int M = 256-0;

  double** A;
  double** R;
  double** Q;

  //A is MxN
  //R is NxN
  //Q is MxN

#pragma begin_scop
  for (k = 0; k < N; k++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k+0][0][0]
#pragma schedule[__T][k][1][__T][1][__T][1][0][1][0]
      nrm[k] = 0.00+0;
      for (i = 0; i < M; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][i][0]
#pragma schedule[__T][k][2][__T][1][__T][2][i][1][0]
        nrm[k] = nrm[k] + A[i][k] * A[i][k];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][0][0]
#pragma schedule[__T][k][3][__T][1][__T][3][0][1][0]
      R[k][k] = nrm[k];
      //R[k][k] = sqrt(nrm[k]);
      for (i = 0; i < M; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][i][0]
#pragma schedule[__T][k][4][__T][1][__T][4][i][1][0]
        Q[i][k] = A[i][k] / R[k][k];
      for (j = k + 1; j < N; j++)
	{
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][j][0]
#pragma schedule[__T][k][0][__T][1][__T][0][j][1][0]
	  R[k][j] = 0.0;
	  for (i = 0; i < M; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][j][i]
#pragma schedule[__T][k][5][__T][0][__T][5][j][0][i]
	    R[k][j] = R[k][j] + Q[i][k] * A[i][j];
	  for (i = 0; i < M; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[k][j][i]
#pragma schedule[__T][k][5][__T][1][__T][5][j][1][i]
	    A[i][j] = A[i][j] - Q[i][k] * R[k][j];
	}
    }
#pragma end_scop

}
