float sqrt(float);

void kernel_cholesky()
{
  int i, j, k;

  int N = 128;
  double** A;

#pragma begin_scop
  for (i = 0; i < N; i++) {
     //j<i
     for (j = 0; j < i; j++) {
        for (k = 0; k < j; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k]
           A[i][j] = A[i][j] - A[i][k] * A[j][k];
        }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[__T][__T][__T][i][j][j]
        A[i][j] = A[i][j] / A[j][j];
     }
     // i==j case
     for (k = 0; k < i; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][k][i]
#pragma schedule[__T][__T][__T][i][k][i]
        A[i][i] = A[i][i] - A[i][k] * A[i][k];
     }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][i][i]
#pragma schedule[__T][__T][__T][i][i][i]
     A[i][i] = A[i][i];
     //A[i][i] = sqrt(A[i][i]);
     //FLOAT
  }
#pragma end_scop

}
