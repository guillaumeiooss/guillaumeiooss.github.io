void kernel_trisolv()
{
  int N = 512;
  int i, j;
  double** L;
  double* x;
  double* b;

#pragma begin_scop
  for (i = 0; i < N; i++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][__T][i][0][0][0]
      x[i] = b[i];
      for (j = 0; j <i; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][__T][i][j][1][0]
        x[i] = x[i] - L[i][j] * x[j];
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][i]
#pragma schedule[__T][__T][i][i][0][1]
      x[i] = x[i] / L[i][i];
    }
#pragma end_scop

}
