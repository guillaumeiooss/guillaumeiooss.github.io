#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "ludcmp_link.tiled.c"

int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 2) {
    printf("Expecting 1 argument, not %i.\n", (argc-1));
    printf("Expecting N\n");
    exit(0);
  }

  int N = extract_int_arg(argv, 1);
  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(A,double,N,N, N,N);
  POLYBENCH_1D_ARRAY_DECL(b,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(x,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(y,double,N,N);
  
  double w = 0.0;
  init2_3(N,N, N, &elem_polyb_2_1_cholesky, POLYBENCH_ARRAY(A));
  init1_2(N, N, &elem_polyb_1_1AA, POLYBENCH_ARRAY(b));
  init1_1(N, &elem_polyb_1_2, POLYBENCH_ARRAY(x));
  init1_1(N, &elem_polyb_1_2, POLYBENCH_ARRAY(y));
  
  
  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(N, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(b), POLYBENCH_ARRAY(x), POLYBENCH_ARRAY(y), w);

   /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print1(N,  POLYBENCH_ARRAY(x)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(b);
  POLYBENCH_FREE_ARRAY(x);
  POLYBENCH_FREE_ARRAY(y);


  return 0;
}
