
void kernel()
{
  int N = 1024;

  int i, j, k;
  
  double** A;
  double* b;
  double* x;
  double* y;
  
  double w;

#pragma begin_scop
  for (i = 0; i < N; i++) {
    for (j = 0; j <i; j++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[0][__T][__T][0][__T][i][j][0][0]
       w = A[i][j];
       for (k = 0; k < j; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[0][__T][__T][0][__T][i][j][1][k]
          w = w - A[i][k] * A[k][j];
       }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[0][__T][__T][0][__T][i][j][2][0]
        A[i][j] = w / A[j][j];
    }
   for (j = i; j < N; j++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[0][__T][__T][1][__T][i][j][0][0]
       w = A[i][j];
       for (k = 0; k < i; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[0][__T][__T][1][__T][i][j][1][k]
          w = w - A[i][k] * A[k][j];
       }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][j]
#pragma schedule[0][__T][__T][1][__T][i][j][2][0]
       A[i][j] = w;
    }
  }

  for (i = 0; i < N; i++) {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][i]
#pragma schedule[1][__T][__T][i][0][0][0][0][0]
     w = b[i];
     for (j = 0; j < i; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[1][__T][__T][i][1][j][0][0][0]
        w = w - A[i][j] * y[j];
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][i]
#pragma schedule[1][__T][__T][i][2][0][0][0][0]
     y[i] = w;
  }

   for (i = 0; i <N; i++) {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][i]
#pragma schedule[2][__T][__T][i][0][0][0][0][0]
     w = y[N-1-i];
     for (j = N-i; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[2][__T][__T][i][1][j][0][0][0]
        w = w - A[N-1-i][j] * x[j];
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][i]
#pragma schedule[2][__T][__T][i][2][0][0][0][0]
     x[N-1-i] = w / A[N-1-i][N-1-i];
  }


#pragma end_scop

}
