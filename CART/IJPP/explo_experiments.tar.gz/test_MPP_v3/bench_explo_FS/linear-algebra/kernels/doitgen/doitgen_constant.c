void kernel_doitgen()
{
  int r, q, p, s;

  int NP = 64;
  int NQ = 64;
  int NR = 64;

  double*** A;
  double** C4;
  double*** sum;

  //A is NRxNQxNP
  //C4 is NPxNP
  //sum is NP

#pragma begin_scop
  for (r = 0; r < NR; r++)
    for (q = 0; q < NQ; q++)  {
      for (p = 0; p < NP; p++)  {
#pragma tile_group[0]
#pragma tile_size[16][16][16][16]
#pragma tile_hyperplans[r][q][p][0]
#pragma schedule[__T][__T][0][__T][__T][r][q][0][p][0]
	sum[r][q][p] = 0.0;
	for (s = 0; s < NP; s++)
#pragma tile_group[0]
#pragma tile_size[16][16][16][16]
#pragma tile_hyperplans[r][q][p][s]
#pragma schedule[__T][__T][1][__T][__T][r][q][1][p][s]
	  sum[r][q][p] = sum[r][q][p] + A[r][q][s] * C4[s][p];
      }
      for (p = 0; p < NP; p++)
#pragma tile_group[0]
#pragma tile_size[16][16][16][16]
#pragma tile_hyperplans[r][q][p][0]
#pragma schedule[__T][__T][2][__T][__T][r][q][2][p][0]
	A[r][q][p] = sum[r][q][p];
    }
#pragma end_scop

}
