#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "doitgen_link.tiled.c"

int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 4) {
    printf("Expecting 3 arguments, not %i.\n", (argc-1));
    printf("Expecting NP, NQ, NR\n");
    exit(0);
  }

  int NP = extract_int_arg(argv, 1);
  int NQ = extract_int_arg(argv, 2);
  int NR = extract_int_arg(argv, 3);

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_3D_ARRAY_DECL(A,double,NR,NQ,NP, NR,NQ,NP);
  POLYBENCH_2D_ARRAY_DECL(C4,double,NP,NP, NP,NP);
  POLYBENCH_3D_ARRAY_DECL(sum,double,NR,NQ,NP, NR,NQ,NP);
  
  init3_4(NR,NQ,NP, NP, &elem_polyb_3_2, POLYBENCH_ARRAY(A));
  init2_3(NP,NP, NP, &elem_polyb_2_1_4, POLYBENCH_ARRAY(C4));
  init3_3(NR,NQ,NP,&elem_polyb_3_1, POLYBENCH_ARRAY(sum)); // TODO: memory allocation issue? (1D in polybench, not 3D)

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(NP, NQ, NR, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(C4), POLYBENCH_ARRAY(sum));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print3(NR, NQ, NP,  POLYBENCH_ARRAY(A)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(C4);
  POLYBENCH_FREE_ARRAY(sum);

  return 0;
}
