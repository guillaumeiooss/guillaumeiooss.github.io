void kernel_mvt()
{
  int i, j;

  int N = 256;

  double* x1;
  double* x2;
  double* y_1;
  double* y_2;
  double** A;

  //x1 is N
  //x2 is N
  //y_1 is N
  //y_2 is N
  //A is NxN

#pragma begin_scop
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][__T][i][j]
      x1[i] = x1[i] + A[i][j] * y_1[j];
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][__T][i][j]
      x2[i] = x2[i] + A[j][i] * y_2[j];
#pragma end_scop
}

