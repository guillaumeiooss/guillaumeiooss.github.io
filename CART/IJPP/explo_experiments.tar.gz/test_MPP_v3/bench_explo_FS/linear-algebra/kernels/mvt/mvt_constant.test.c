#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "mvt_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 2) {
    printf("Expecting 1 arguments, not %i.\n", (argc-1));
    printf("Expecting N\n");
    exit(0);
  }

  int N = extract_int_arg(argv, 1);
  
  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_1D_ARRAY_DECL(x1,double, N, N);
  POLYBENCH_1D_ARRAY_DECL(x2,double, N, N);
  POLYBENCH_1D_ARRAY_DECL(y_1,double, N, N);
  POLYBENCH_1D_ARRAY_DECL(y_2,double, N, N);
  POLYBENCH_2D_ARRAY_DECL(A,double,N,N, N,N); 
  
  init1_2(N, N, &elem_polyb_1_3, POLYBENCH_ARRAY(x1));
  init1_2(N, N, &elem_polyb_1_3B, POLYBENCH_ARRAY(x2));
  init1_2(N, N, &elem_polyb_1_3C, POLYBENCH_ARRAY(y_1));
  init1_2(N, N, &elem_polyb_1_3D, POLYBENCH_ARRAY(y_2));
  init2_3(N,N, N, &elem_polyb_2_1_4, POLYBENCH_ARRAY(A));

   /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(N, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(x1), POLYBENCH_ARRAY(x2),
        POLYBENCH_ARRAY(y_1), POLYBENCH_ARRAY(y_2));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print1(N, POLYBENCH_ARRAY(x2)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(x1);
  POLYBENCH_FREE_ARRAY(x2);
  POLYBENCH_FREE_ARRAY(y_1);
  POLYBENCH_FREE_ARRAY(y_2);

  return 0;
}
