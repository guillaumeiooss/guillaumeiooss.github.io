void kernel_3mm()
{
  int i, j, k;

  int NI = 128;
  int NJ = 128;
  int NK = 128;
  int NL = 128;
  int NM = 128;

  double** E;
  double** A;
  double** B;
  double** F;
  double** C;
  double** D;
  double** G;

  //E is NIxNJ
  //A is NIxNK
  //B is NKxNJ
  //F is NJxNL
  //C is NJxNM
  //D is NMxNL
  //G is NIxNL

#pragma begin_scop
  /* E := A*B */
  for (i = 0; i < NI; i++)
    for (j = 0; j < NJ; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][__T][2][1][__T][j][2][1][0][i]
	E[i][j] = 0.0;
	for (k = 0; k < NK; ++k)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][k]
#pragma schedule[__T][__T][3][0][__T][j][3][0][k][i]
	  E[i][j] = E[i][j] + A[i][k] * B[k][j];
      }
  /* F := C*D */
  for (i = 0; i < NJ; i++)
    for (j = 0; j < NL; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][0][0][__T][i][0][0][0][j]
	F[i][j] = 0.0;
	for (k = 0; k < NM; ++k)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][1][0][__T][i][1][0][k][j]
	  F[i][j] = F[i][j] + C[i][k] * D[k][j];
      }
  /* G := E*F */
  for (i = 0; i < NI; i++)
    for (j = 0; j < NL; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][__T][0][0][__T][j][0][0][0][i]
	G[i][j] = 0.0;
	for (k = 0; k < NJ; ++k)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j+k][i+j+k][k]
#pragma schedule[__T][__T][3][1][__T][j+k][3][1][k][i+j+k]
	  G[i][j] = G[i][j] + E[i][k] * F[k][j];
      }
#pragma end_scop

}
