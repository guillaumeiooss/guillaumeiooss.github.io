void kernel_bicg()
{
  int i, j;

  int M = 256;
  int N = 256;

  double** A;
  double* s;
  double* q;
  double* p;
  double* r;

  //A is NxM
  //s is M
  //q is N
  //p is M
  //r is N

#pragma begin_scop

  for (i = 0; i < M; i++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][__T][i][0][2]
    s[i] = 0;
  for (i = 0; i < N; i++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][__T][i][0][0]
      q[i] = 0.0;
      for (j = 0; j < M; j++)
	{
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[j][i]
#pragma schedule[__T][__T][j][i][3]
	  s[j] = s[j] + r[i] * A[i][j];
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][__T][i][j][1]
	  q[i] = q[i] + A[i][j] * p[j];
	}
    }

#pragma end_scop

}
