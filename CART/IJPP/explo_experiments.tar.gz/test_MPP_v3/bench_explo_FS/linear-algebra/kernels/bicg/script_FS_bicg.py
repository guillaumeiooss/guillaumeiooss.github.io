
# === Generation of the FS tiled programs (using "mppcodegen") ===

# Usage of the python script:
#	python3.6 gen_tied_prog.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"

import subprocess
import re, sys
import os.path

# Problem definition (to be changed across kernels)
kernel_name = "bicg"
prog_sizes = ["9500", "10500"]
kernel_arguments = [
	"int M",
	"int N",
  	"double POLYBENCH_1D(p, M, M)",
  	"double POLYBENCH_1D(r, N, N)",
  	"double POLYBENCH_2D(A, N,M, N,M)",
  	"double POLYBENCH_1D(s, M, M)",
  	"double POLYBENCH_1D(q, N, N)",
  ]

utilities_folder_path = "../../../utilities"
# linear-algebra : 3 "../"
# others: 2 "../"

vectorization_report_enable = False

dim_tile_size = 2

# Launch script!
exec(open(utilities_folder_path + "/script_common_gen_tiled.py").read())
