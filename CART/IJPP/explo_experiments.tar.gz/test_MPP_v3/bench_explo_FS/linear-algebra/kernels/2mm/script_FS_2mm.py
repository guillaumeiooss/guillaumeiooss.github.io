
# === Generation of the FS tiled programs (using "mppcodegen") ===

# Usage of the python script:
#	python3.6 gen_tied_prog.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"

import subprocess
import re, sys
import os.path

# Problem definition (to be changed across kernels)
kernel_name = "2mm"
prog_sizes = ["800", "900", "1100", "1200"]
kernel_arguments = [
	"int NI",
	"int NJ",
	"int NK",
	"int NL",
  	"double POLYBENCH_2D(A, NI,NK, NI,NK)",
  	"double POLYBENCH_2D(B, NK,NJ, NK,NJ)",
  	"double POLYBENCH_2D(C, NJ,NL, NJ,NL)",
  	"double POLYBENCH_2D(D, NI,NL, NI,NL)",
  	"double POLYBENCH_2D(tmp, NI,NJ, NI,NJ)",
  	"double alpha",
  	"double beta"
  ]


utilities_folder_path = "../../../utilities"
# linear-algebra : 3 "../"
# others: 2 "../"

vectorization_report_enable = False

dim_tile_size = 3

# Launch script!
exec(open(utilities_folder_path + "/script_common_gen_tiled.py").read())
