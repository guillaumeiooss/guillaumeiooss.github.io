void kernel_2mm()
{
  int i, j, k;

  int NI = 128;
  int NJ = 128;
  int NK = 128;
  int NL = 128;

  double alpha;
  double beta;
  double** tmp;
  double** A;
  double** B;
  double** C;
  double** D;

  //tmp is NIxNJ
  //A is NIxNK
  //B is NKxNJ
  //C is NJxNL
  //D is NIxNL

#pragma begin_scop
  /* D := alpha*A*B*C + beta*D */
  for (i = 0; i < NI; i++)
    for (j = 0; j < NJ; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][0][1][__T][i][0][1][0][j]
	tmp[i][j] = 0.0;
	for (k = 0; k < NK; ++k)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][1][0][__T][i][1][0][k][j]
	  tmp[i][j] = tmp[i][j] + alpha * A[i][k] * B[k][j];
      }
  for (i = 0; i < NI; i++)
    for (j = 0; j < NL; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][0][0][__T][i][0][0][0][j]
	D[i][j] = D[i][j] * beta;
	for (k = 0; k < NJ; ++k)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j+k][k]
#pragma schedule[__T][__T][1][1][__T][i][1][1][k][j+k]
	  D[i][j] = D[i][j] + tmp[i][k] * C[k][j];
      }
#pragma end_scop

}
