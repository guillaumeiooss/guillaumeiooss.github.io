void kernel_atax()
{
  int i, j;

  int N = 256;
  int M = 256;

  double** A;
  double* x;
  double* y;
  double* tmp;

  //A is MxN
  //x is N
  //y is N
  //tmp is M

#pragma begin_scop
  for (i = 0; i < N; i++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][2][__T][2][0][i]
    y[i] = 0;
  for (i = 0; i < M; i++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][0][__T][0][0][i]
      tmp[i] = 0.0;
      for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][1][__T][1][j][i]
	tmp[i] = tmp[i] + A[i][j] * x[j];
      for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i+j][j]
#pragma schedule[__T][3][__T][3][j][i+j]
	y[j] = y[j] + A[i][j] * tmp[i];
    }
#pragma end_scop

}
