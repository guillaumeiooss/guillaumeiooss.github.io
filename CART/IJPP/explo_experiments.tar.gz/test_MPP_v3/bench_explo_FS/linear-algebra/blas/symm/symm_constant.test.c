#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "symm_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}


int main(int argc, char** argv) {
  //Check number of args
  if (argc != 3) {
    printf("Expecting 2 arguments, not %i.\n", (argc-1));
    printf("Expecting M, N\n");
    exit(0);
  }

  int M = extract_int_arg(argv, 1);
  int N = extract_int_arg(argv, 2);


  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(A,double,M,M, M,M);
  POLYBENCH_2D_ARRAY_DECL(B,double,M,N, M,N);
  POLYBENCH_2D_ARRAY_DECL(C,double,M,N, M,N);
  POLYBENCH_2D_ARRAY_DECL(temp2,double,M,N, M,N);
  
  double alpha = 1.5;
  double beta = 1.2;
  init2_3(M,M, M, &elem_polyb_2_1_8, POLYBENCH_ARRAY(A));
  init2_4(M,N, N, M, &elem_polyb_2_2_1, POLYBENCH_ARRAY(B));
  init2_3(M,N, M, &elem_polyb_2_1_7, POLYBENCH_ARRAY(C));
  
  init2_2(M,N,&elem_polyb_2_1_6, POLYBENCH_ARRAY(temp2));

  
   /* Start timer. */
  polybench_start_instruments;
  
  
  //Call the main computation
  tiled_kernel(M, N, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B), POLYBENCH_ARRAY(C),
        POLYBENCH_ARRAY(temp2), alpha, beta);

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(M, N, POLYBENCH_ARRAY(C)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);
  POLYBENCH_FREE_ARRAY(C);
  POLYBENCH_FREE_ARRAY(temp2);

  return 0;
}
