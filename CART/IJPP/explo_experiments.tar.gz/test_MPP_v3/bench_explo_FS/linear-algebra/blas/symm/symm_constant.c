void kernel_symm()
{
  int i, j, k;
  double** temp2;

  int M = 512;
  int N = 512;

  double alpha;
  double beta;
  double** C;
  double** A;
  double** B;

//BLAS PARAMS
//SIDE = 'L'
//UPLO = 'L'
// =>  Form  C := alpha*A*B + beta*C
// A is MxM
// B is MxN
// C is MxN
//note that due to Fortran array layout, the code below more closely resembles upper triangular case in BLAS
#pragma begin_scop
   for (i = 0; i < M; i++)
      for (j = 0; j < N; j++ )
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][__T][i][j][0][1][0]
        temp2[i][j] = 0;
        for (k = 0; k < i; k++) {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k][0][0]
           C[k][j] = C[k][j] + alpha*B[i][j] * A[i][k];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k][2][0]
           temp2[i][j] = temp2[i][j] + B[k][j] * A[i][k];
        }
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][i]
#pragma schedule[__T][__T][__T][i][j][i][1][1]
        C[i][j] = beta * C[i][j] + alpha*B[i][j] * A[i][i] + alpha * temp2[i][j];
     }
#pragma end_scop

}
