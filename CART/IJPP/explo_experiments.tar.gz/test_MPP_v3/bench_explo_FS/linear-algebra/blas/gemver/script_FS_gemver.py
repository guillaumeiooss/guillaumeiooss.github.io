
# === Generation of the FS tiled programs (using "mppcodegen") ===

# Usage of the python script:
#	python3.6 gen_tied_prog.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"

import subprocess
import re, sys
import os.path

# Problem definition (to be changed across kernels)
kernel_name = "gemver"
prog_sizes = ["8000"]
kernel_arguments = [
	"int N",
  	"double POLYBENCH_1D(u1,N,N)",
  	"double POLYBENCH_1D(u2,N,N)",
  	"double POLYBENCH_1D(v1,N,N)",
  	"double POLYBENCH_1D(v2,N,N)",
  	"double POLYBENCH_1D(x,N,N)",
  	"double POLYBENCH_1D(w,N,N)",
  	"double POLYBENCH_1D(y,N,N)",
  	"double POLYBENCH_1D(z,N,N)",
  	"double POLYBENCH_2D(A,N,N, N,N)",
  	"double alpha",
  	"double beta"
  ]

utilities_folder_path = "../../../utilities"
# linear-algebra : 3 "../"
# others: 2 "../"

vectorization_report_enable = False

dim_tile_size = 2

# Launch script!
exec(open(utilities_folder_path + "/script_common_gen_tiled.py").read())
