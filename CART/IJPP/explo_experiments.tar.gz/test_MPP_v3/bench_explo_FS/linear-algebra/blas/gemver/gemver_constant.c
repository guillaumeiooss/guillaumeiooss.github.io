void kernel_gemver()
{
  int i, j;

  int N = 256;

  double alpha;
  double beta;
  double** A;
  double* u1;
  double* v1;
  double* u2;
  double* v2;
  double* w;
  double* x;
  double* y;
  double* z;

#pragma begin_scop

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[j][i]
#pragma schedule[__T][0][__T][j][0][i][0]
      A[i][j] = A[i][j] + u1[i] * v1[j] + u2[i] * v2[j];

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][0][__T][i][0][j][1]
      x[i] = x[i] + beta * A[j][i] * y[j];

  for (i = 0; i < N; i++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][1][__T][i][1][0][0]
    x[i] = x[i] + z[i];

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[j][i]
#pragma schedule[__T][2][__T][j][2][i][0]
      w[i] = w[i] +  alpha * A[i][j] * x[j];

#pragma end_scop
}
