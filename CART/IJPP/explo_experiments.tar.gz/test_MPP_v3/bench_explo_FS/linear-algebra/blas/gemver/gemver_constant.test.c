#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "gemver_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 2) {
    printf("Expecting 1 arguments, not %i.\n", (argc-1));
    printf("Expecting N\n");
    exit(0);
  }

  int N = extract_int_arg(argv, 1);
 

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_1D_ARRAY_DECL(u1,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(u2,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(v1,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(v2,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(x,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(w,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(y,double,N,N);
  POLYBENCH_1D_ARRAY_DECL(z,double,N,N);
  
  POLYBENCH_2D_ARRAY_DECL(A,double,N,N, N, N);
  
  
  double alpha = 1.5;
  double beta = 1.2;
  init1_1(N, &elem1_1, POLYBENCH_ARRAY(u1));
  init1_2(N, N, &elem_polyb_1_1A, POLYBENCH_ARRAY(u2));
  init1_2(N, N, &elem_polyb_1_1B, POLYBENCH_ARRAY(v1));
  init1_2(N, N, &elem_polyb_1_1C, POLYBENCH_ARRAY(v2));
  
  init1_1(N, &elem_polyb_1_2, POLYBENCH_ARRAY(x));
  init1_1(N, &elem_polyb_1_2, POLYBENCH_ARRAY(w));
  init1_2(N, N, &elem_polyb_1_1D, POLYBENCH_ARRAY(y));
  init1_2(N, N, &elem_polyb_1_1E, POLYBENCH_ARRAY(z));
  
  init2_3(N,N, N, &elem_polyb_2_1_4, POLYBENCH_ARRAY(A));

  
  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(N, POLYBENCH_ARRAY(u1), POLYBENCH_ARRAY(u2),
        POLYBENCH_ARRAY(v1), POLYBENCH_ARRAY(v2),
        POLYBENCH_ARRAY(x), POLYBENCH_ARRAY(w), POLYBENCH_ARRAY(y), POLYBENCH_ARRAY(z),
        POLYBENCH_ARRAY(A), alpha, beta);

  
  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print1(N, POLYBENCH_ARRAY(w)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(u1);
  POLYBENCH_FREE_ARRAY(u2);
  POLYBENCH_FREE_ARRAY(v1);
  POLYBENCH_FREE_ARRAY(v2);
  POLYBENCH_FREE_ARRAY(x);
  POLYBENCH_FREE_ARRAY(w);
  POLYBENCH_FREE_ARRAY(y);
  POLYBENCH_FREE_ARRAY(z);
  POLYBENCH_FREE_ARRAY(A);

  return 0;
}
