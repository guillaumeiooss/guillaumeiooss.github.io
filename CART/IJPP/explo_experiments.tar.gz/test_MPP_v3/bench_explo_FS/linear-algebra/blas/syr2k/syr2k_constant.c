void kernel_syr2k()
{
  int i, j, k;

  int M = 256;
  int N = 256;

  double alpha;
  double beta;
  double** C;
  double** A;
  double** B;

//BLAS PARAMS
//UPLO  = 'L'
//TRANS = 'N'
//A is NxM
//B is NxM
//C is NxN
#pragma begin_scop
  for (i = 0; i < N; i++) {
    for (j = 0; j <= i; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][__T][i][j][0][0]
     C[i][j] = C[i][j] * beta;
    for (k = 0; k < M; k++)
      for (j = 0; j <= i; j++)
	{
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][j][k][1]
	  C[i][j] = C[i][j] + A[j][k]*alpha*B[i][k] + B[j][k]*alpha*A[i][k];
	}
  }
#pragma end_scop

}
 
