void kernel_gesummv()
{
  int i, j;

  int N = 256;

  double alpha;
  double beta;
  double** A;
  double** B;
  double* tmp;
  double* x;
  double* y;

#pragma begin_scop

  for (i = 0; i < N; i++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][2][__T][2][0][i]
      tmp[i] = 0.0;
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][0][__T][0][0][i]
      y[i] = 0.0;
      for (j = 0; j < N; j++)
	{
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][3][__T][3][j][i]
	  tmp[i] = A[i][j] * x[j] + tmp[i];
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][j]
#pragma schedule[__T][1][__T][1][j][i]
	  y[i] = B[i][j] * x[j] + y[i];
	}
#pragma tile_group[0]
#pragma tile_size[16][16]
#pragma tile_hyperplans[i][0]
#pragma schedule[__T][4][__T][4][0][i]
      y[i] = alpha * tmp[i] + beta * y[i];
    }

#pragma end_scop
}
