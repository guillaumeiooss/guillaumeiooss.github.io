void kernel_trmm()
{
  int M = 256;
  int N = 256;

  int i, j, k;

  double alpha;
  double** A;
  double** B;

//BLAS parameters
//SIDE   = 'L'
//UPLO   = 'L'
//TRANSA = 'T'
//DIAG   = 'U'
// => Form  B := alpha*A**T*B.
// A is MxM
// B is MxN
#pragma begin_scop
  for (i = 0; i < M; i++)
     for (j = 0; j < N; j++) {
        for (k = i+1; k < M; k++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][k]
#pragma schedule[__T][__T][0][__T][j][i][0][k]
           B[i][j] = B[i][j] + A[k][i] * B[k][j];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][__T][1][__T][j][i][1][0]
        B[i][j] = alpha * B[i][j];
     }
#pragma end_scop

}
