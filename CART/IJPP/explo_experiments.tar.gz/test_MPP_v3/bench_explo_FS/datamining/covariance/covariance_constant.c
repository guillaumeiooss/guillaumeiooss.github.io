void kernel_covariance()
{
  int i, j, k;

  int N = 256;
  int M = 256;

  double** data;
  double** cov;
  double* mean;

  //data is NxM
  //cov is MxM
  //mean is M
#pragma begin_scop
  for (j = 0; j < M; j++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[__T][1][__T][__T][j][1][0][0][1]
      mean[j] = 0.0;
      for (i = 0; i < N; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][2][__T][__T][j][2][i][0][1]
        mean[j] = mean[j] + data[i][j];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[__T][3][__T][__T][j][3][0][0][1]
      mean[j] = mean[j] / N;
    }

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][4][__T][__T][j][4][i][0][1]
      data[i][j] = data[i][j] - mean[j];

  for (i = 0; i < M; i++)
    for (j = i; j < M; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][0][__T][__T][i][0][0][1][j]
        cov[i][j] = 0.0;
        for (k = 0; k < N; k++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][k]
#pragma schedule[__T][5][__T][__T][j][5][i][k][1]
	  cov[i][j] = cov[i][j] + data[k][i] * data[k][j];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][6][__T][__T][j][6][i][0][0]
        cov[i][j] = cov[i][j] / (N - 1.0);
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[__T][6][__T][__T][j][6][i][0][1]
        cov[j][i] = cov[i][j];
      }
#pragma end_scop

}
