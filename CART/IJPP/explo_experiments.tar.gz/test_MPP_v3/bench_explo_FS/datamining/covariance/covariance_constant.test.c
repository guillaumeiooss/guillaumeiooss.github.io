#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "covariance_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 3) {
    printf("Expecting 2 arguments, not %i.\n", (argc-1));
    printf("Expecting M, N\n");
    exit(0);
  }

  int M = extract_int_arg(argv, 1);
  int N = extract_int_arg(argv, 2);

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(data,double,N,M, N,M);
  POLYBENCH_1D_ARRAY_DECL(mean,double,M,M);
  POLYBENCH_2D_ARRAY_DECL(cov,double,M,M, M,M);
  
  init2_3(N,M, M, &elem_polyb_2_1_17, POLYBENCH_ARRAY(data));
  init1_1(M,&elem_polyb_1_2, POLYBENCH_ARRAY(mean));
  init2_2(M,M,&elem_polyb_2_1_6, POLYBENCH_ARRAY(cov));

  
  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(M, N, POLYBENCH_ARRAY(data), POLYBENCH_ARRAY(mean), POLYBENCH_ARRAY(cov));

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(M,M, POLYBENCH_ARRAY(cov)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(data);
  POLYBENCH_FREE_ARRAY(mean);
  POLYBENCH_FREE_ARRAY(cov);

  return 0;
}
