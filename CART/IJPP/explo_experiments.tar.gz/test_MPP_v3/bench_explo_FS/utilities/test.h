#ifndef __TEST_H
#define __TEST_H

#include "polybench.h"

//
//Array constructors
//
void init1_1(int nb_lines, double (*element)(int), double POLYBENCH_1D(result, nb_lines, nb_lines));
void init1_2(int nb_lines, int param, double (*element)(int, int), double POLYBENCH_1D(result, nb_lines, nb_lines));

void init2_2(int nb_lines, int nb_cols, double (*element)(int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols));
void init2_3(int nb_lines, int nb_cols, int param, double (*element)(int,int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols));
void init2_4(int nb_lines, int nb_cols, int param1, int param2, double (*element)(int,int,int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols));

void init3_3(int n1, int n2, int n3, double (*element)(int,int,int),
    double POLYBENCH_3D(result, n1, n2, n3, n1, n2, n3));
void init3_4(int n1, int n2, int n3, int param, double (*element)(int,int,int,int),
    double POLYBENCH_3D(result, n1, n2, n3, n1, n2, n3));

void init4_4(int n1, int n2, int n3, int n4, double (*element)(int,int,int,int),
    double POLYBENCH_4D(result, n1, n2, n3, n4, n1, n2, n3, n4));
void init4_5(int n1, int n2, int n3, int n4, int param, double (*element)(int,int,int,int,int),
    double POLYBENCH_4D(result, n1, n2, n3, n4, n1, n2, n3, n4));


double elem1_1(int i); //i
double elem1_2(int i); //2*i
double elem2_1(int i, int j); //i+j
double elem2_2(int i, int j); //2*i+j
double elem2_3(int i, int j); //i+2*j
double elem2_4(int i, int j); //i+j+1
double elem2_inv(int i, int j); //if i+1>=j: i+j+1 else: 0
double elem2_L(int i, int j); //if i>=j: i+j+1 else: 0
double elem3_0(int i, int j, int k); //-1
double elem3_1(int i, int j, int k); //i+j+k
double elem3_2(int i, int j, int k); //2*i+j-k
double elem4_1(int i, int j, int k, int l); //i+j+k+l
double elem4_2(int i, int j, int k, int l); //2*i+j-k+l
double elem4_3(int i, int j, int k, int l); //2*j+k-l = elem3_2 for all i


// Polybench tests
double elem_polyb_1_1A(int i, int n); // ((i+1)/n)/2.0
double elem_polyb_1_1AA(int i, int n); //((i+1)/n)/2.0 + 4.0
double elem_polyb_1_1B(int i, int n); // ((i+1)/n)/4.0
double elem_polyb_1_1C(int i, int n); // ((i+1)/n)/6.0
double elem_polyb_1_1D(int i, int n); // ((i+1)/n)/8.0
double elem_polyb_1_1E(int i, int n); // ((i+1)/n)/9.0
double elem_polyb_1_2(int i);         // 0.0
double elem_polyb_1_3(int i, int n);  // (i % n) / n
double elem_polyb_1_3B(int i, int n); // ((i+1) % n) / n
double elem_polyb_1_3C(int i, int n); // ((i+3) % n) / n
double elem_polyb_1_3D(int i, int n); // ((i+4) % n) / n
double elem_polyb_1_4(int i, int n);  // 1 + (i / n)
double elem_polyb_1_5(int i);         // -999
double elem_polyb_1_6(int i, int n);         // (i+2) / n
double elem_polyb_1_7(int i, int n);         // (i+3) / n


double elem_polyb_2_1_1(int i, int j, int n);  // ((i*j+1) % n) / n
double elem_polyb_2_1_2(int i, int j, int n);  // (i*(j+1) % n) / n
double elem_polyb_2_1_3(int i, int j, int n);  // (i*(j+2) % n) / n
double elem_polyb_2_1_4(int i, int j, int n);  // (i*j % n) / n
double elem_polyb_2_1_5(int i, int j, int n);  // ((i*j+2) % n) / n
double elem_polyb_2_1_6(int i, int j); 		   // 0.0
double elem_polyb_2_1_7(int i, int j, int n);  // ((i+j) % 100) / n
double elem_polyb_2_1_8(int i, int j, int n);  // Complicated disjuction (triangl mat) for symm
double elem_polyb_2_1_9(int i, int j, int n);  //( (i+j) % n) / n
double elem_polyb_2_1_10(int i, int j, int n); // ( (n+(i-j)) % n) / n
double elem_polyb_2_1_11(int i, int j, int n);  // ((i*(j+3)+1) % n) / n
double elem_polyb_2_1_12A(int i, int j, int n); // ((i*j+1) % n) / (5*n)
double elem_polyb_2_1_12B(int i, int j, int n); // ((i*(j+1)+2) % n) / (5*n)
double elem_polyb_2_1_12C(int i, int j, int n); // ((i*(j+3)) % n) / (5*n)
double elem_polyb_2_1_12D(int i, int j, int n); // ((i*(j+2)+2) % n) / (5*n)
double elem_polyb_2_1_cholesky(int i, int j, int n); // Complicated disjuction for cholesky
double elem_polyb_2_1_13(int i, int j, int n);  // ((((i*j) % n) / n)*100) + 10
double elem_polyb_2_1_14(int i, int j, int n); // (i+n-j+1)*2/ n
double elem_polyb_2_1_15(int i, int j, int n); // (i*j)/ n + i
double elem_polyb_2_1_16(int i, int j);        // Id matrix
double elem_polyb_2_1_17(int i, int j, int n); // (i*j)/ n
double elem_polyb_2_1_flwar(int i, int j); // Floyd-warshall input / complicated

double elem_polyb_2_1_stencil_1(int i, int j, int n); // (i*(j+1))/ n
double elem_polyb_2_1_stencil_2(int i, int j, int n); // (i*(j+2))/ n
double elem_polyb_2_1_stencil_3(int i, int j, int n); // (i*(j+3))/ n
double elem_polyb_2_1_stencil_4(int i, int j, int n); // (i*(j+2) + 2)/ n
double elem_polyb_2_1_stencil_5(int i, int j, int n); // (i*(j+3) + 3)/ n
double elem_polyb_2_j1d_1(int i, int j, int n); // (i+2) / n
double elem_polyb_2_j1d_2(int i, int j, int n); // (i+3) / n


double elem_polyb_2_2_1(int i, int j, int n, int m); // ((n+i-j) % 100) / m
double elem_polyb_2_2_2(int i, int j, int n, int m); // ((i*j+3) % n) / m
double elem_polyb_2_2_3(int i, int j, int n, int m); // ((i+j) % n) / (5*m)

double elem_polyb_3_1(int i, int j, int k);          // 0.0
double elem_polyb_3_2(int i, int j, int k, int n);   // ((i*j + k)%n) / n

double elem_polyb_4_1(int dumm, int i, int j, int k, int n); // (i+j + n - k) * 10 / n

//
// Array pretty-printers
//
void print1(int nb_lines, double POLYBENCH_1D(A, nb_lines, nb_lines));
void print2(int nb_lines, int nb_cols, double POLYBENCH_2D(A, nb_lines, nb_cols, nb_lines, nb_cols));
void print3(int n1, int n2, int n3, double POLYBENCH_3D(A, n1, n2, n3, n1, n2, n3));
void print4(int n1, int n2, int n3, int n4, double POLYBENCH_4D(A, n1, n2, n3, n4, n1, n2, n3, n4));

//
// Array checkers
//
int is_equal1(double* a, double* b, int nb_lines);
int is_equal2(double** A, double** B, int nb_lines, int nb_cols);
int is_equal3(double*** A, double*** B, int n1, int n2, int n3);
int is_equal4(double**** A, double**** B, int n1, int n2, int n3, int n4);

#endif
