
# === Variables from specialized script:
#kernel_name
#prog_sizes
#kernel_arguments
#utilities_folder_path
#vectorization_report_enable
#dim_tile_size

# For CSU machines:
# setenv LD_LIBRARY_PATH /s/chopin/k/grad/giooss/lib/mppcodegen:/s/chopin/k/grad/giooss/lib/barvinok/bin

import glob


debug = False # True

# ===========================================================================
# ===========================================================================
# ===========================================================================

# File Naming conventions (fixed-sized tiling)

# Original "16^n" script
source_name = kernel_name + "_constant.c"

# Script with the right tile sizes
def get_source_script_name(tilesizes):
	script_name = kernel_name + "_FS"
	for ts in tilesizes:
		script_name = script_name + "_" + str(ts)
	script_name = script_name + ".c"
	return script_name

# File produced by MPPCodegen
def get_mppcodegen_tile_prog_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	tile_name = tile_name + ".tiled.cc"
	return tile_name

# Adapted file from MPPCodegen : tiled version
def get_tile_prog_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	tile_name = tile_name + ".tiled.c"
	return tile_name

# Test file link to tiled programm
def get_prog_link_test_name():
	return kernel_name + "_link.tiled.c"

# Main C code
def get_prog_test_name():
	return kernel_name + "_constant.test.c"

# Produced binary name
def get_bin_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	bin_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	bin_name = bin_name + "_bin"
	return bin_name


# ===========================================================================
# === Paths to binaries ===
exec(open(utilities_folder_path + "/exec_path.py").read())


# === Command lines ===
# ICC option -xhost = get the best vectorisation available in that architecture
def get_compilation_command(tilesizes):
	bin_name = get_bin_name(tilesizes)
	source_test_name = get_prog_test_name()

	icc_option_optim = ["-O3"]

	vect_report_option = [ # "-qoptreport-phase=vec,loop",
		"-qopt-report=2"]
	vect_optim = ["-xhost"]
	polybench_option = ["-DPOLYBENCH_TIME"]
	other_option = ["-lm",
		("-I" + utilities_folder_path),
		(utilities_folder_path + "/polybench.c"),
		("-o" + bin_name)]

	compilation_command = [icc_path] + icc_option_optim + polybench_option
	compilation_command += [source_test_name]
	if (vectorization_report_enable):
		compilation_command += vect_report_option
	compilation_command += vect_optim
	compilation_command += other_option
		
	return compilation_command
# Working command line to compile gemm with timing inside the original Polybench lib:
# 	gcc gemm.c -O3 -I../../../utilities/ ../../../utilities/polybench.c -DPOLYBENCH_TIME -o gemm

def get_execution_command(tilesizes):
	bin_name = get_bin_name(tilesizes)
	execution_command = ["./" + bin_name] + prog_sizes
	return execution_command

# ===========================================================================

# Substitutions:
#	tile_size[16][16][16][16] => tile_size[tl0][tl1][tl2][tl3]
#	tile_size[16][16][16]     => tile_size[tl0][tl1][tl2]
#	tile_size[16][16]         => tile_size[tl0][tl1]
#	tile_size[16]             => tile_size[tl0]
re_til_dim4 = re.compile(r"tile_size\[16\]\[16\]\[16\]\[16\]$")
re_til_dim3 = re.compile(r"tile_size\[16\]\[16\]\[16\]$")
re_til_dim2_fw = re.compile(r"tile_size\[1\]\[16\]\[16\]$")
re_til_dim2 = re.compile(r"tile_size\[16\]\[16\]$")
re_til_dim1 = re.compile(r"tile_size\[16\]$")
dummy_repl_expr = "xxxxxxxxxxxxxxxxxxxxxxx"

def create_script_prog(tilesizes):
	if (len(tilesizes)>5):
		raise ValueError("Did not plan for more than 4 tile sizes")
	repl_til_dim4 = dummy_repl_expr
	if (len(tilesizes)>=4):
		repl_til_dim4 = "tile_size[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "][" + str(tilesizes[2]) + "][" + str(tilesizes[3]) + "]"
	repl_til_dim3 = dummy_repl_expr
	if (len(tilesizes)>=3):
		repl_til_dim3 = "tile_size[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "][" + str(tilesizes[2]) + "]"
	repl_til_dim2 = dummy_repl_expr
	if (len(tilesizes)>=2):
		repl_til_dim2 = "tile_size[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "]"
	repl_til_dim2_fw = dummy_repl_expr
	if (len(tilesizes)>=2):
		repl_til_dim2_fw = "tile_size[1][" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "]"
	repl_til_dim1 = dummy_repl_expr
	if (len(tilesizes)>=1):
		repl_til_dim1 = "tile_size[" + str(tilesizes[0]) + "]"

	script_content = ""
	with open(source_name) as f:
		for line in f:
			nline = re_til_dim4.sub(repl_til_dim4, line)
			nline = re_til_dim3.sub(repl_til_dim3, nline)
			nline = re_til_dim2_fw.sub(repl_til_dim2_fw, nline)
			nline = re_til_dim2.sub(repl_til_dim2, nline)
			nline = re_til_dim1.sub(repl_til_dim1, nline)
			script_content += nline

	script_name = get_source_script_name(tilesizes)
	fout = open(script_name, "w")
	fout.write(script_content)
	fout.close()

# ===========================================================================

# Might need: "" export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/derich/lib/mpp-codegen "" before
# Require rose_edg_macros_and_functions_required_for_gnu.h in the same folder
def mppgen_command(script_name):
	return [mppcodegen_path] + [script_name]

re_last_line_mppcodegen = re.compile(r"Iscc codegen...")
def create_tiled_code(tilesizes):
	source_script = get_source_script_name(tilesizes)
	command = mppgen_command(source_script)
	
	
	if debug:
	        print("command_mppcodegen = " + str(command))
	
	out_mppcodegen = subprocess.check_output(command).decode("utf-8")

	# DEBUG
	if debug:
	        print(out_mppcodegen)

	# Check that the last line of out_mppcodegen starts with "Iscc codegen..."
	# If it does not, we assume a failure
	lout = out_mppcodegen.splitlines()
	last_line = lout[len(lout)-1]
	if (not (last_line.startswith("Iscc codegen..."))):
		ValueError("Last line of the mppcodegen output does not match : " + last_line)
	return


# Adaptation of the tiled code:
#	=> Code after "void tiled_kernel() {" must remain (main part of the loop)
#	=> Remove #include <math.h> #include <iostream> #include <stdio.h> (first line is "using namespace std;")
#	=> After the "#define floord(n,d) ...":
#		=> remove all variable declarations + use kernel_arguments to fill tiled_kernel args
def adapt_tiled_code(tilesizes):
	tiled_code_filename = get_mppcodegen_tile_prog_name(tilesizes)

	result = ""
	numline = 0
	kernel_reached = False
	with open(tiled_code_filename) as f:
		for line in f:
			numline += 1

			# Remove the 4 first lines:
			# 	#include <math.h> #include <iostream> #include <stdio.h> + using namespace std;
			if (numline==4):		# Check
				check = line.startswith("using namespace std;")
				if (not check):
					ValueError("Fourth line of the produced tiled code does not match the expected")
			if (numline<=4):
				continue
			
			# End of the file (once the kernel is reached) => No brainer
			if kernel_reached:
				result+=line
				continue

			# void tiled_kernel line => last line before the end of the file
			check_tiled_kernel = line.startswith("void tiled_kernel()")
			if (check_tiled_kernel):
				kernel_reached = True
				result += "void tiled_kernel("
				isFirst = True
				for karg in kernel_arguments:
					if isFirst:
						result += karg
						isFirst = False
					else:
						result += ", " + karg
				result += ") {\n"
				continue

			# Variables declarations should already be inside the kernel_arguments
			if (line.startswith("int")):
				continue
			if (line.startswith("double")):
				continue

			# By default, keep the line (macro / comment / ...)
			result += line

	# DEBUG
	if debug:
	        print(result)

	# Overwrite the tiled code
	tiled_code_filename = get_tile_prog_name(tilesizes)
	fout = open(tiled_code_filename, "w")
	fout.write(result)
	fout.close()


# TODO: jacobi-1d, seidel 2d et heat3d  => Christophe a du faire une modif manuelle a ce niveau
#		(ifs defectueux)
#		====>>> ADAPTER LE SCRIPT


# Clean-up of the intermediate tiled code
def clean_interm_tiled_code(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	os.remove(tile_name + ".iscc")
	os.remove(tile_name + ".tiled.cc")

# ===========================================================================

# Linking with test code
def mod_link_code(tilesizes):
	linkfile_name = get_prog_link_test_name()
	tiledfile_name = get_tile_prog_name(tilesizes)

	fout = open(linkfile_name, "w")
	fout.write("#include \"" + tiledfile_name + "\"")
	fout.close()
	return

# Compiling everything
def compile_kernel(tilesizes):
	command = get_compilation_command(tilesizes)
	#print(command)
	out = subprocess.check_output(command).decode("utf-8")
	return

# Running everything
num_exec = 6
def run_kernel_repet(tilesizes):
	command = get_execution_command(tilesizes)

	lexec_time = []
	for i in range(0, num_exec):
		str_exec_time = subprocess.check_output(command).decode("utf-8")
		exec_time = float(str_exec_time)
		lexec_time = [exec_time] + lexec_time

	# Remove both extremal and take the average
	lexec_time.sort()
	
	# DEBUG
	if debug:
	        print("lexec_time = " + str(lexec_time))

	average = 0.0
	for i in range(1, (num_exec-1)):
		average = average + lexec_time[i]
	average = average / float(num_exec-2)

	# LOG
	print(str(tilesizes) + "  => " + str(average))

	return average

	

# ===========================================================================

# === Test the kernels for a given tile sizes ===
def test_tilesizes(tilesizes):
	# Create the script program (ex: gemm_FS_32_32_32.c)
	create_script_prog(tilesizes)
	
	# Create the tiled code (ex: gemm_FS_32_32_32_.tiled.c)
	create_tiled_code(tilesizes)
	adapt_tiled_code(tilesizes)
	clean_interm_tiled_code(tilesizes)
	
	# Link that code with the test (modify gemm_link.tiled.c)
	mod_link_code(tilesizes)

	# Compile the kernel
	compile_kernel(tilesizes)
	
	# Execute!
	res = run_kernel_repet(tilesizes)
	return res

# ===========================================================================

# === Exploration tools ===

# === BASIC METHODS

# Shape: full rectangle
def get_rectangular_range(min_ts, max_ts, jump_ts):
	assert(len(min_ts)==len(max_ts))
	assert(len(min_ts)==len(jump_ts))
	assert(len(max_ts)<=4)
	l = len(min_ts)

	# Get the list of ts to be explored
	list_ts = []
	current_ts = min_ts[:]
	while (current_ts[l-1]<=max_ts[l-1]):
		list_ts += [current_ts[:]]
		current_ts[0] += jump_ts[0]

		# Carries
		if ((current_ts[0]>max_ts[0]) and (l>=2)):
			current_ts[0] = min_ts[0]
			current_ts[1] += jump_ts[1]
			if ((current_ts[1] > max_ts[1]) and (l>=3)):
				current_ts[1] = min_ts[1]
				current_ts[2] += jump_ts[2]
				if ((current_ts[2] > max_ts[2]) and (l>=4)):
					current_ts[2] = min_ts[2]
					current_ts[3] += jump_ts[3]

	#print("l = " +str(l))
	#print("list_ts = " + str(list_ts))
	return list_ts

# Shape: cross
def get_cross_range(current_ts, r):
	l = len(current_ts)
	list_ts = [current_ts]
	for i in range(0, l):
		for k in range(1, (r+1)):
			new_ts_min = current_ts[:]
			new_ts_min[i] = max(2, new_ts_min[i]-k)
			list_ts += [new_ts_min]
		for k in range(1, (r+1)):
			new_ts_max = current_ts[:]
			new_ts_max[i] = new_ts_max[i]+k
			list_ts+=[new_ts_max]
	return list_ts

# Shape: 3^n rectangle centered on center
def get_cross3stride_range(center, stride):
	l = len(center)
	min_ts = []
	max_ts = []
	for i in range(0,l):
		temp = center[i] - stride[i]
		if (temp < 2):
			raise ValueError("Cross3stride: min_ts at dim " + str(i) + " is below 2.")
		min_ts += [temp]
	for i in range(0,l):
		max_ts += [center[i] + stride[i]]
	return get_rectangular_range(min_ts, max_ts, stride)


# Scan and try all ts from a list
def scan_list_ts(list_ts):
	lexec_time = []
	for ts in list_ts:
		exec_time = test_tilesizes(ts)
		lexec_time = lexec_time + [(ts, exec_time)]
	return lexec_time

# Analyse result of a scan
def get_min_exec_time(lexec_time):
	# Explore and get the min
	(best_ts, best_exec_time) = lexec_time[0]
	for (ts, exec_time) in lexec_time:
		if (exec_time < best_exec_time):
			best_ts = ts
			best_exec_time = exec_time
	return [best_ts, best_exec_time]


# === COMPOSITE METHODS

# Scan the configurations over a rectangule [min_ts, max_ts]. Both are included
def full_rectangle_explo_with_jump(min_ts, max_ts, jump_ts):
	list_ts = get_rectangular_range(min_ts, max_ts, jump_ts)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

def full_rectangle_explo(min_ts, max_ts):
	jump_ts = []
	for i in min_ts:
		jump_ts += [1]
	return full_rectangle_explo_with_jump(min_ts, max_ts, jump_ts)


# Check the canonic directions for improvement
def cross_explo(current_ts, r):
	list_ts = get_cross_range(current_ts, r)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

def cross3stride_explo(center, stride):
	list_ts = get_cross3stride_range(center, stride)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]


# ===========================================================================

# Usage:
#	python3.6 script.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"
def main():
	# Help
	if (len(sys.argv)==1):
		print("Usage: python3.6 script.py [tiling exploration options]")
		print("List of tiling exploration options:")
		print("\t* single [list of ts]")
		print("\t* rectangle [mints] [maxts]")
		print("\t* cross [centralts] d")
		print("\t* rectstride [mints] [maxts] [strides]")
		print("\t* cross3stride [centralts] [strides]")
		print("\t* clean")
		return

	# Which option is taken?
	option_chosen = sys.argv[1]
	if (option_chosen=="single"):
		ts = []
		for arg in sys.argv[2:]:
			ts += [int(arg)]
		
		assert(len(ts)==dim_tile_size)
		
		exec_time = test_tilesizes(ts)
		# Note: Pretty-printer already inside "test_tilesizes()"
		return
	elif (option_chosen=="rectangle"):
		min_ts = []
		max_ts = []

		l_ts = int((len(sys.argv) - 2) / 2)
		assert(2*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			min_ts += [int(sys.argv[i])]
		for i in range((2+l_ts), len(sys.argv)):
			max_ts += [int(sys.argv[i])]

		assert((len (min_ts))==(len (max_ts)))
		assert(len(min_ts)==dim_tile_size)

		[best_ts,best_exec_time] = full_rectangle_explo(min_ts, max_ts)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="cross"):
		ts = []
		for arg in sys.argv[2:(len(sys.argv)-1)]:
			ts += [int(arg)]
		assert(len(ts)==dim_tile_size)
		d = int(sys.argv[len(sys.argv)-1])
		[best_ts,best_exec_time] = cross_explo(ts, d)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="rectstride"):
		min_ts = []
		max_ts = []
		stride = []
		l_ts = int((len(sys.argv) - 2) / 3)
		assert(3*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			min_ts += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			max_ts += [int(sys.argv[i])]
		for i in range((2+2*l_ts), len(sys.argv)):
			stride += [int(sys.argv[i])]

		assert((len (min_ts))==(len (max_ts)))
		assert((len (min_ts))==(len (stride)))
		assert(len(min_ts)==dim_tile_size)

		[best_ts,best_exec_time] = full_rectangle_explo_with_jump(min_ts, max_ts, stride)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="cross3stride"):
		center = []
		stride = []
		l_ts = int((len(sys.argv) - 2) / 2)
		assert(2*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			center += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			stride += [int(sys.argv[i])]

		assert((len(center))==(len (stride)))
		assert(len(center)==dim_tile_size)

		[best_ts,best_exec_time] = cross3stride_explo(center, stride)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")
	elif (option_chosen=="clean"):
        	fileList = glob.glob(kernel_name + "_FS_*")
        	for filePath in fileList:
                	os.remove(filePath)
	else:
		raise ValueError("Option " + option_chosen + " was not recognized.")

	return

# Let's go !
main()
