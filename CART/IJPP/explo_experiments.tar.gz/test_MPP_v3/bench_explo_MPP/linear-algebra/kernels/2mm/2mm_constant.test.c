#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "2mm_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 6) {
    printf("Expecting 5 arguments, not %i.\n", (argc-1));
    printf("Expecting NI, NJ, NK, NL, b\n");
    exit(0);
  }

  int NI = extract_int_arg(argv, 1);
  int NJ = extract_int_arg(argv, 2);
  int NK = extract_int_arg(argv, 3);
  int NL = extract_int_arg(argv, 4);
  int block_size = extract_int_arg(argv, 5);

  int outer_NI = NI / block_size;
  int inner_NI = NI % block_size;
  int outer_NJ = NJ / block_size;
  int inner_NJ = NJ % block_size;
  int outer_NK = NK / block_size;
  int inner_NK = NK % block_size;
  int outer_NL = NL / block_size;
  int inner_NL = NL % block_size;

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(A,double,NI,NK, NI, NK);
  POLYBENCH_2D_ARRAY_DECL(B,double,NK,NJ, NK, NJ);
  POLYBENCH_2D_ARRAY_DECL(C,double,NJ,NL, NJ, NL);
  POLYBENCH_2D_ARRAY_DECL(D,double,NI,NL, NI, NL);
  POLYBENCH_2D_ARRAY_DECL(tmp,double,NI,NJ, NI, NJ);
  
  
  
  double alpha = 1.5;
  double beta = 1.2;
  init2_3(NI,NK, NI, &elem_polyb_2_1_1, POLYBENCH_ARRAY(A));
  init2_3(NK,NJ, NJ, &elem_polyb_2_1_2, POLYBENCH_ARRAY(B));
  init2_3(NJ,NL, NL, &elem_polyb_2_1_11, POLYBENCH_ARRAY(C));
  init2_3(NI,NL, NK, &elem_polyb_2_1_3, POLYBENCH_ARRAY(D));
  init2_2(NI,NJ,&elem_polyb_2_1_6, POLYBENCH_ARRAY(tmp));  // Overwritten => no init needed in theory

   /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(NI, NJ, NK, NL,
    outer_NI, inner_NI, outer_NJ, inner_NJ, outer_NK, inner_NK, outer_NL, inner_NL,
    POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B), POLYBENCH_ARRAY(C), POLYBENCH_ARRAY(D),
    POLYBENCH_ARRAY(tmp), alpha, beta, block_size);


   /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(NI, NL, POLYBENCH_ARRAY(D)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);
  POLYBENCH_FREE_ARRAY(C);
  POLYBENCH_FREE_ARRAY(D);
  POLYBENCH_FREE_ARRAY(tmp);

  return 0;
}
