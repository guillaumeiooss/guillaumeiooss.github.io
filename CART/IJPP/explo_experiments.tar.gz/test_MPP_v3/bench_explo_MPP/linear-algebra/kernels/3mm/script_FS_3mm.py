
# === Generation of the FS tiled programs (using "mppcodegen") ===

# Usage of the python script:
#	python3.6 gen_tied_prog.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"

import subprocess
import re, sys
import os.path

# Problem definition (to be changed across kernels)
kernel_name = "3mm"
prog_sizes = ["800", "900", "1000", "1100", "1200"]
kernel_arguments = [
  	"int NI",
  	"int NJ",
  	"int NK",
  	"int NL",
  	"int NM",
    "int outer_NI", "int inner_NI",
    "int outer_NJ", "int inner_NJ",
    "int outer_NK", "int inner_NK",
    "int outer_NL", "int inner_NL",
    "int outer_NM", "int inner_NM",
  	"double POLYBENCH_2D(A, NI,NK, NI,NK)",
  	"double POLYBENCH_2D(B, NK,NJ, NK,NJ)",
  	"double POLYBENCH_2D(C, NJ,NM, NJ,NM)",
  	"double POLYBENCH_2D(D, NM,NL, NM,NL)",
  	"double POLYBENCH_2D(E, NI,NJ, NI,NJ)",
  	"double POLYBENCH_2D(F, NJ,NL, NJ,NL)",
  	"double POLYBENCH_2D(G, NI,NL, NI,NL)",
    "int block_size"
  ]


utilities_folder_path = "../../../utilities"
# linear-algebra : 3 "../"
# others: 2 "../"

vectorization_report_enable = False

dim_tile_size = 3

# Launch script!
exec(open(utilities_folder_path + "/script_common_gen_tiled.py").read())
