#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "bicg_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 4) {
    printf("Expecting 3 arguments, not %i.\n", (argc-1));
    printf("Expecting M, N, b\n");
    exit(0);
  }

  int M = extract_int_arg(argv, 1);
  int N = extract_int_arg(argv, 2);
  int block_size = extract_int_arg(argv, 3);
 
  int outer_M = M / block_size;
  int inner_M = M % block_size;
  int outer_N = N / block_size;
  int inner_N = N % block_size;

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_1D_ARRAY_DECL(p,double,M,M);
  POLYBENCH_1D_ARRAY_DECL(r,double,N,N);
  POLYBENCH_2D_ARRAY_DECL(A,double,N,M, N,M);
  POLYBENCH_1D_ARRAY_DECL(s,double,M,M);
  POLYBENCH_1D_ARRAY_DECL(q,double,N,N);  
  
  
  init1_2(M, M, &elem_polyb_1_3, POLYBENCH_ARRAY(p));
  init1_2(N, N, &elem_polyb_1_3, POLYBENCH_ARRAY(r));
  init2_3(N,M, N, &elem_polyb_2_1_2, POLYBENCH_ARRAY(A));
  init1_1(M,&elem_polyb_1_2, POLYBENCH_ARRAY(s));
  init1_1(N,&elem_polyb_1_2, POLYBENCH_ARRAY(q));

  
  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(M, N, outer_M, inner_M, outer_N, inner_N,
        POLYBENCH_ARRAY(p), POLYBENCH_ARRAY(r), POLYBENCH_ARRAY(A),
        POLYBENCH_ARRAY(s), POLYBENCH_ARRAY(q), block_size);

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print1(N, POLYBENCH_ARRAY(q)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(p);
  POLYBENCH_FREE_ARRAY(r);
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(s);
  POLYBENCH_FREE_ARRAY(q);


  return 0;
}
