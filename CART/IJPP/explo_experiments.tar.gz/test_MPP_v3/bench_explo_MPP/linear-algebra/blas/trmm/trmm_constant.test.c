#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "trmm_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 4) {
    printf("Expecting 3 arguments, not %i.\n", (argc-1));
    printf("Expecting M, N, b\n");
    exit(0);
  }

  int M = extract_int_arg(argv, 1);
  int N = extract_int_arg(argv, 2);
  int block_size = extract_int_arg(argv, 3);


  int outer_M = M / block_size;
  int inner_M = M % block_size;
  int outer_N = N / block_size;
  int inner_N = N % block_size;


  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(A,double,M,N, M, N);
  POLYBENCH_2D_ARRAY_DECL(B,double,M,N, M, N);
  
  double alpha = 1.5;
  init2_3(M,N, M, &elem_polyb_2_1_9, POLYBENCH_ARRAY(A));
  init2_3(M,N, N, &elem_polyb_2_1_10, POLYBENCH_ARRAY(B));

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(M, N, outer_M, inner_M, outer_N, inner_N,
    POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B), alpha, block_size);

   /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(M, N, POLYBENCH_ARRAY(B)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);
  
  return 0;
}
