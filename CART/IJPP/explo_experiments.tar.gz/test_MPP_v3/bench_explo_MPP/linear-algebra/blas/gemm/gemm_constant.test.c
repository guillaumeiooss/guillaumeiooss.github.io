#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "gemm_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}

int main(int argc, char** argv) {
  //Check number of args
  if (argc != 5) {
    printf("Expecting 4 arguments, not %i.\n", (argc-1));
    printf("Expecting NI, NJ, NK, b\n");
    exit(0);
  }

  int NI = extract_int_arg(argv, 1);
  int NJ = extract_int_arg(argv, 2);
  int NK = extract_int_arg(argv, 3);
  int block_size = extract_int_arg(argv, 4);
 
  int outer_NI = NI / block_size;
  int inner_NI = NI % block_size;
  int outer_NJ = NJ / block_size;
  int inner_NJ = NJ % block_size;
  int outer_NK = NK / block_size;
  int inner_NK = NK % block_size;

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(C,double,NI,NJ,NI,NJ);
  POLYBENCH_2D_ARRAY_DECL(A,double,NI,NK,NI,NJ);
  POLYBENCH_2D_ARRAY_DECL(B,double,NK,NJ,NK,NJ);

  double alpha = 1.5;
  double beta = 1.2;
  init2_3(NI,NJ, NI, &elem_polyb_2_1_1, POLYBENCH_ARRAY(C));
  init2_3(NI,NK, NK, &elem_polyb_2_1_2, POLYBENCH_ARRAY(A));
  init2_3(NK,NJ, NJ, &elem_polyb_2_1_3, POLYBENCH_ARRAY(B));


  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(NI, NJ, NK,
    outer_NI, inner_NI, outer_NJ, inner_NJ, outer_NK, inner_NK,
    POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B), POLYBENCH_ARRAY(C),
    alpha, beta, block_size);

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(NI, NJ,  POLYBENCH_ARRAY(C)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(C);
  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(B);


  return 0;
}
