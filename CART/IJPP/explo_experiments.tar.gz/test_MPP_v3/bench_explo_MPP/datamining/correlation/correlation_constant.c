double sqrt(double);
double if_(double,double,double,double);

int main()
{

  int i, j, k;  

  int N = 256;
  int M = 256;

  double** data;
  double** corr;
  double* mean;
  double* stddev;

  //data is NxM
  //corr is MxM
  //mean is M
  //stddev is M

#pragma begin_scop

  for (j = 0; j < M; j++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][2][__T][__T][j][2][0][0][1][1][1]
      mean[j] = 0;
      for (i = 0; i < N; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[0][__T][3][__T][__T][j][3][i][0][1][1][1]
	mean[j] = mean[j] + data[i][j];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][4][__T][__T][j][4][0][0][1][1][1]
      mean[j] = mean[j]/N;
    }

   for (j = 0; j < M; j++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][2][__T][__T][j][2][0][0][1][1][1]
      stddev[j] = 0;
      for (i = 0; i < N; i++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[0][__T][5][__T][__T][j][5][i][0][1][1][0]
        stddev[j] = stddev[j] + (data[i][j] - mean[j]) * (data[i][j] - mean[j]);
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][6][__T][__T][j][6][0][0][0][0][0]
      stddev[j] = stddev[j]/N;
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][6][__T][__T][j][6][0][0][0][1][0]
      stddev[j] = stddev[j];
      //stddev[j] = sqrt(stddev[j]);
      /* The following in an inelegant but usual way to handle
         near-zero std. dev. values, which below would cause a zero-
         divide. */
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][0][0]
#pragma schedule[0][__T][6][__T][__T][j][6][0][0][1][0][0]
      stddev[j] = stddev[j];
      //stddev[j] = if_(stddev[j],eps,1.0,stddev[j]);
      /* WARNING!!!
      if(stddev[j] <= eps)
	stddev[j] = 1.0;
      */
    }

  /* Center and reduce the column vectors. */
  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[0][__T][5][__T][__T][j][5][i][0][1][1][1]
        data[i][j] = data[i][j] - mean[j];
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[0][__T][7][__T][__T][j][7][i][0][0][0][0]
        data[i][j] = data[i][j] / (N * stddev[j]);
        //data[i][j] = data[i][j] / (sqrt(N) * stddev[j]);
      }

  /* Calculate the m * m correlation matrix. */
  for (i = 0; i < M-1; i++)
    {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][0][0]
#pragma schedule[0][__T][2][__T][__T][i][2][0][0][0][0][0]
      corr[i][i] = 1;
      for (j = i+1; j < M; j++)
        {
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[0][__T][1][__T][__T][i][1][j][0][0][0][0]
          corr[i][j] = 0;
          for (k = 0; k < N; k++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][k]
#pragma schedule[0][__T][8][__T][__T][j][8][i][k][0][0][0]
            corr[i][j] = corr[i][j] + (data[k][i] * data[k][j]);
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[j][i][0]
#pragma schedule[0][__T][9][__T][__T][j][9][i][0][0][0][0]
          corr[j][i] = corr[i][j];
        }
    }
#pragma schedule[1]
  corr[M-1][M-1] = 1;
#pragma end_scop

  return 0;
}

