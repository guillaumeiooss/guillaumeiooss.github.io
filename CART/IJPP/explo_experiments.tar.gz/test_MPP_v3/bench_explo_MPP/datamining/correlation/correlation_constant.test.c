#include "test.c"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#include "correlation_link.tiled.c"


int extract_int_arg(char** argv, int num) {
  char* val = argv[num];
  int res = atoi(val);
  return res;
}



int main(int argc, char** argv) {
  //Check number of args
  if (argc != 4) {
    printf("Expecting 3 arguments, not %i.\n", (argc-1));
    printf("Expecting M, N, b\n");
    exit(0);
  }

  int M = extract_int_arg(argv, 1);
  int N = extract_int_arg(argv, 2);
  int block_size = extract_int_arg(argv, 3);

  int outer_M = M / block_size;
  int inner_M = M % block_size;
  int outer_N = N / block_size;
  int inner_N = N % block_size;

  //
  // Tiled kernel
  //

  //Init inputs
  POLYBENCH_2D_ARRAY_DECL(data, double, N,M, N,M);
  POLYBENCH_1D_ARRAY_DECL(mean, double, M, M);
  POLYBENCH_1D_ARRAY_DECL(stddev, double, M, M);
  POLYBENCH_2D_ARRAY_DECL(corr, double, M,M, M,M);
  
  //double eps = 0.1;
  init2_3(N, M, M, &elem_polyb_2_1_15, POLYBENCH_ARRAY(data));
  init1_1(M,&elem_polyb_1_2, POLYBENCH_ARRAY(mean));
  init1_1(M,&elem_polyb_1_2, POLYBENCH_ARRAY(stddev));
  init2_2(M,M,&elem_polyb_2_1_16, POLYBENCH_ARRAY(corr));

  /* Start timer. */
  polybench_start_instruments;
  
  //Call the main computation
  tiled_kernel(M, N, outer_M, inner_M, outer_N, inner_N,
    POLYBENCH_ARRAY(data), POLYBENCH_ARRAY(mean), POLYBENCH_ARRAY(stddev), POLYBENCH_ARRAY(corr), //eps,
    block_size);

  /* Stop and print timer. */
  polybench_stop_instruments;
  polybench_print_instruments;

  /* Prevent dead-code elimination. All live-out data must be printed
     by the function call in argument. */
  polybench_prevent_dce(print2(M, M,  POLYBENCH_ARRAY(corr)));

  /* Be clean. */
  POLYBENCH_FREE_ARRAY(data);
  POLYBENCH_FREE_ARRAY(mean);
  POLYBENCH_FREE_ARRAY(stddev);
  POLYBENCH_FREE_ARRAY(corr);

  return 0;
}

