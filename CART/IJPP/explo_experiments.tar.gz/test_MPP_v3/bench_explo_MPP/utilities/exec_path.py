

mppcodegen_path = "/home/derich/lib/mpp-codegen/mppcodegen"
# My computer: /home/derich/lib/mpp-codegen/mppcodegen
# CSU machine: /s/chopin/k/grad/giooss/lib/mppcodegen/mppcodegen

icc_path = "/home/derich/intel/bin/icc"
# My computer: /home/derich/intel/bin/icc
# CSU machine: /s/parsons/l/sys/intel_2019/compilers_and_libraries_2019/linux/bin/intel64/icc

gcc_path = "gcc"

