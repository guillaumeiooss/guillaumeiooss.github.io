
# === Variables from specialized script:
#kernel_name
#prog_sizes
#kernel_arguments
#utilities_folder_path
#vectorization_report_enable
#dim_tile_size

# MPP VERSION !!!

# For CSU machines:
# setenv LD_LIBRARY_PATH /s/chopin/k/grad/giooss/lib/mppcodegen:/s/chopin/k/grad/giooss/lib/barvinok/bin

import glob

# Add vectorisation pragma "manually" to the generated tiled code
vect_pragma = False

# Does it avoid to recompile the code when the binary is already there?
memoisation = True

# Limit the ratio of the generated code (to avoid generating/compiling code which is too convoluted)
limit_ratio = 10
max_time = 10000.0

# Timeout of the whole compilation + execution thing (in seconds) / set at 5 mins by default
timeout_dur = 300

# icc option to force optimisation of all functions (even if they are big)
override_limits = False

# Print-out intermediate information about what the script is doing
debug = False # True
use_icc = False
debug_gdb_binprog = False # Activate "-g" option for gdb debug of bin prog

# === Paths to binaries ===
exec(open(utilities_folder_path + "/exec_path.py").read())

# ===========================================================================
# ===========================================================================
# ===========================================================================

# File Naming conventions (fixed-sized tiling)

# Original "16^n" script
source_name = kernel_name + "_constant.c"

# Script with the right tile sizes
def get_source_script_name(tilesizes):
	script_name = kernel_name + "_MPP"
	for ts in tilesizes:
		script_name = script_name + "_" + str(ts)
	script_name = script_name + ".c"
	return script_name

# File produced by MPPCodegen
def get_mppcodegen_tile_prog_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	tile_name = tile_name + ".tiled.cc"
	return tile_name

# Adapted file from MPPCodegen : tiled version
def get_tile_prog_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	tile_name = tile_name + ".tiled.c"
	return tile_name

# Test file link to tiled programm
def get_prog_link_test_name():
	return kernel_name + "_link.tiled.c"

# Main C code
def get_prog_test_name():
	return kernel_name + "_constant.test.c"

# Produced binary name
def get_bin_name(tilesizes):
	src_script = get_source_script_name(tilesizes)
	bin_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	bin_name = bin_name + "_bin"
	return bin_name


# ===========================================================================

# === Command lines ===

# Might need: "" export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/derich/lib/mpp-codegen "" before
# Require rose_edg_macros_and_functions_required_for_gnu.h in the same folder

# MPPgen usage: mppcodegen [options] program.c
#  -min-block-size minimum_value     set block_size lower bound
#  -aligned-parameters               assume parameters to be multiple of block_size
#  -positive-parameters              assume non-negative parameters
def mppgen_command(script_name):
	min_val_block_size = 3
	options_mppcodegen = ["-positive-parameters", "-min-block-size " + str(min_val_block_size)]
	#options_mppcodegen += ["-aligned-parameters"]
	return [mppcodegen_path] + options_mppcodegen + [script_name]


# ICC option -xhost = get the best vectorisation available in that architecture
def get_compilation_command(tilesizes):
	bin_name = get_bin_name(tilesizes)
	source_test_name = get_prog_test_name()

	icc_option_optim = ["-O3"]

	debug_gdb_option = []
	if debug_gdb_binprog:
		debug_gdb_option += ["-g"]

	vect_report_option = [ # "-qoptreport-phase=vec,loop",
		"-qopt-report=2"]
	if use_icc:
		vect_optim = ["-xhost"]
		
		# Force optimisation of everything, even if it might take time
		if override_limits:
			vect_optim += ["-qoverride-limits"]
	else:
		vect_optim = []
	polybench_option = ["-DPOLYBENCH_TIME"]
	other_option = ["-lm",
		("-I" + utilities_folder_path),
		(utilities_folder_path + "/polybench.c"),
		("-o" + bin_name)]

	compilation_command = []
	if use_icc:
		compilation_command += [icc_path]
	else:
		compilation_command += [gcc_path]
	compilation_command += icc_option_optim + debug_gdb_option + polybench_option
	compilation_command += [source_test_name]
	if (vectorization_report_enable):
		compilation_command += vect_report_option
	compilation_command += vect_optim
	compilation_command += other_option
		
	return compilation_command
# Working command line to compile gemm with timing inside the original Polybench lib:
# 	gcc gemm.c -O3 -I../../../utilities/ ../../../utilities/polybench.c -DPOLYBENCH_TIME -o gemm

def get_execution_command(tileratio, tilesize_val):
	bin_name = get_bin_name(tileratio)
	execution_command = ["./" + bin_name] + prog_sizes + [str(tilesize_val)]
	return execution_command

# ===========================================================================

# Substitutions:
#	tile_size[16][16][16][16] => tile_size[tl0][tl1][tl2][tl3]
#	tile_size[16][16][16]     => tile_size[tl0][tl1][tl2]
#	tile_size[16][16]         => tile_size[tl0][tl1]
#	tile_size[16]             => tile_size[tl0]
re_til_dim4 = re.compile(r"tile_size\[16\]\[16\]\[16\]\[16\]$")
re_til_dim3 = re.compile(r"tile_size\[16\]\[16\]\[16\]$")
re_til_dim2_fw = re.compile(r"tile_size\[1\]\[16\]\[16\]$")
re_til_dim2 = re.compile(r"tile_size\[16\]\[16\]$")
re_til_dim1 = re.compile(r"tile_size\[16\]$")
dummy_repl_expr = "xxxxxxxxxxxxxxxxxxxxxxx"

def create_script_prog(tilesizes):
	if (len(tilesizes)>5):
		raise ValueError("Did not plan for more than 4 tile sizes")

	repl_til_dim4 = dummy_repl_expr
	if (len(tilesizes)>=4):
		repl_til_dim4 = "tile_ratio[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "][" + str(tilesizes[2]) + "][" + str(tilesizes[3]) + "]"
	repl_til_dim3 = dummy_repl_expr
	if (len(tilesizes)>=3):
		repl_til_dim3 = "tile_ratio[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "][" + str(tilesizes[2]) + "]"
	repl_til_dim2 = dummy_repl_expr
	if (len(tilesizes)>=2):
		repl_til_dim2 = "tile_ratio[" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "]"
	repl_til_dim2_fw = dummy_repl_expr
	if (len(tilesizes)>=2):
		repl_til_dim2_fw = "tile_ratio[1][" + str(tilesizes[0]) + "][" + str(tilesizes[1]) + "]"
	repl_til_dim1 = dummy_repl_expr
	if (len(tilesizes)>=1):
		repl_til_dim1 = "tile_ratio[" + str(tilesizes[0]) + "]"

	script_content = ""
	with open(source_name) as f:
		for line in f:
			nline = re_til_dim4.sub(repl_til_dim4, line)
			nline = re_til_dim3.sub(repl_til_dim3, nline)
			nline = re_til_dim2_fw.sub(repl_til_dim2_fw, nline)
			nline = re_til_dim2.sub(repl_til_dim2, nline)
			nline = re_til_dim1.sub(repl_til_dim1, nline)
			script_content += nline

	script_name = get_source_script_name(tilesizes)
	fout = open(script_name, "w")
	fout.write(script_content)
	fout.close()

# ===========================================================================
def exist_tiled_code(tileratio):
	binname = get_tile_prog_name(tileratio)
	binpath = "./" + binname
	return os.path.isfile(binpath)

re_last_line_mppcodegen = re.compile(r"Iscc codegen...")
def create_tiled_code(tilesizes):
	source_script = get_source_script_name(tilesizes)
	command = mppgen_command(source_script)
	
	
	if debug:
	        print("command_mppcodegen = " + str(command))
	
	try:
		p = subprocess.Popen(command, stdout=subprocess.PIPE)
		out_mppcodegen, _ = p.communicate(timeout=timeout_dur)
		out_mppcodegen = str(out_mppcodegen, "utf-8")

		# subprocess.check_output(command, timeout=timeout_dur).decode("utf-8")
		# DEBUG
		if debug:
			print(out_mppcodegen)

		# Check that the last line of out_mppcodegen starts with "Iscc codegen..."
		# If it does not, we assume a failure
		lout = out_mppcodegen.splitlines()
		last_line = lout[len(lout)-1]
		if (not (last_line.startswith("Iscc codegen..."))):
			ValueError("Last line of the mppcodegen output does not match : " + last_line)
		return False
	except subprocess.TimeoutExpired as te:		# Timeout happened
		p.kill()

		# Also kills iscc, that might continue running
		# Command line: "ps x | grep iscc", then grep the process id (first integer) and kill it (kill -9 <pid>)
		plist_proc = subprocess.Popen(["ps", "x"], stdout=subprocess.PIPE)
		pgrep = subprocess.Popen(["grep", "iscc"], stdin=plist_proc.stdout, stdout=subprocess.PIPE)
		plist_proc.stdout.close()
		out_grep, _ = pgrep.communicate()
		str_grep = str(out_grep, "utf-8")

		# DEBUG
		#print("str_grep = " + str_grep)

		# Get the pid of iscc | careful not to get the grep
		re_get_pid = re.compile(r"(\ )*(?P<pid>[0-9]*)")	# If pid has less than 5 nums, space at beginning
		re_grep = re.compile(r"grep")

		lpid_iscc = []
		for line in str_grep.splitlines():
			if (re_grep.search(line)):		# If this is the grep subprocess, ignore it
				continue
			match_pid = re_get_pid.match(line)
			lpid_iscc += [match_pid.group("pid")]

		# DEBUG
		#print("lpid_iscc = " + str(lpid_iscc))

		# In case of doubt, terminate all iscc scripts
		for k in range(0, len(lpid_iscc)):
			pid_iscc = lpid_iscc[k]
			subprocess.run(["kill", "-9", str(pid_iscc)])

		if (len(lpid_iscc)>1):
			print("WARNING! More than 1 iscc subprocess was found and killed!")

		return True



# Adaptation of the tiled code:
#	=> Code after "void tiled_kernel() {" must remain (main part of the loop)
#	=> Remove #include <math.h> #include <iostream> #include <stdio.h> (first line is "using namespace std;")
#	=> After the "#define floord(n,d) ...":
#		=> remove all variable declarations + use kernel_arguments to fill tiled_kernel args
def adapt_tiled_code(tilesizes):
	tiled_code_filename = get_mppcodegen_tile_prog_name(tilesizes)

	result = ""
	numline = 0
	kernel_reached = False
	with open(tiled_code_filename) as f:
		for line in f:
			numline += 1

			# Remove the 4 first lines:
			# 	#include <math.h> #include <iostream> #include <stdio.h> + using namespace std;
			if (numline==4):		# Check
				check = line.startswith("using namespace std;")
				if (not check):
					ValueError("Fourth line of the produced tiled code does not match the expected")
			if (numline<=4):
				continue
			
			# End of the file (once the kernel is reached) => No brainer
			if kernel_reached:
				result+=line
				continue

			# void tiled_kernel line => last line before the end of the file
			check_tiled_kernel = line.startswith("void tiled_kernel()")
			if (check_tiled_kernel):
				kernel_reached = True
				result += "void tiled_kernel("
				isFirst = True
				for karg in kernel_arguments:
					if isFirst:
						result += karg
						isFirst = False
					else:
						result += ", " + karg
				result += ") {\n"
				continue

			# Variables declarations should already be inside the kernel_arguments
			if (line.startswith("int")):
				continue
			if (line.startswith("double")):
				continue

			# By default, keep the line (macro / comment / ...)
			result += line

	# DEBUG
	if debug:
		print(result)

	# Adding vectorization pragma to innermost loop
	if vect_pragma:
		new_result = ""

		# Prev_line should not be written just yet
		prev_line = ""
		is_prev_line_for = False
		for line in result.splitlines(keepends=True):
			# Criterion : if current line is starting with "S..." and previous line by "for"
			#	then add before this previous line a "#pragma ivdep"

			if (is_prev_line_for):
				if line.strip().startswith("S"):
					new_result += "#pragma ivdep\n"

			if (line.strip().startswith("for")):
				is_prev_line_for = True
			else:
				is_prev_line_for = False

			new_result += prev_line
			prev_line = line

		# Finishing to commit everything to new_result & update result
		new_result += prev_line
		result = new_result


	# Overwrite the tiled code
	tiled_code_filename = get_tile_prog_name(tilesizes)
	fout = open(tiled_code_filename, "w")
	fout.write(result)
	fout.close()


# TODO: jacobi-1d, seidel 2d et heat3d  => Christophe a du faire une modif manuelle a ce niveau
#		(ifs defectueux / kernel panic si pas carré?)
#		====>>> ADAPTER LE SCRIPT ?
# ==> Pas de défaut après inspection => Abandon, mais ouvre l'oeil


# Clean-up of the intermediate tiled code
def clean_interm_tiled_code(tilesizes):
	src_script = get_source_script_name(tilesizes)
	tile_name = src_script[0:(len(src_script)-2)] # For the .cc extension
	os.remove(tile_name + ".iscc")
	os.remove(tile_name + ".tiled.cc")

# ===========================================================================

# Linking with test code
def mod_link_code(tilesizes):
	linkfile_name = get_prog_link_test_name()
	tiledfile_name = get_tile_prog_name(tilesizes)

	fout = open(linkfile_name, "w")
	fout.write("#include \"" + tiledfile_name + "\"")
	fout.close()
	return

# Compiling everything
def compile_kernel(tilesizes):
	command = get_compilation_command(tilesizes)
	#print(command)
	try:
		#out = subprocess.check_output(command, timeout=timeout_dur).decode("utf-8")
		p = subprocess.Popen(command, stdout=subprocess.PIPE)
		_ = p.communicate(timeout=timeout_dur)
		return False
	except subprocess.TimeoutExpired as te:
		return True

# Running everything
num_exec = 6
def run_kernel_repet(tilesizes, tileratio, tilesize_val):
	command = get_execution_command(tileratio, tilesize_val)

	if debug:
		print("exec_command = " + str(command))

	lexec_time = []
	for i in range(0, num_exec):
		str_exec_time = subprocess.check_output(command).decode("utf-8")
		exec_time = float(str_exec_time)
		lexec_time = [exec_time] + lexec_time

	# Remove both extremal and take the average
	lexec_time.sort()
	
	# DEBUG
	if debug:
	        print("lexec_time = " + str(lexec_time))

	average = 0.0
	for i in range(1, (num_exec-1)):
		average = average + lexec_time[i]
	average = average / float(num_exec-2)

	# LOG
	print(str(tilesizes) + "( ratio = " + str(tileratio) +
		" | bl = " + str(tilesize_val) + " ) => " + str(average))

	return average

	

# ===========================================================================

def gcd(a, b):
	if (a<b):
		return gcd(b,a)
	if ((a<=0) or (b<0)):
		raise ValueError("gcd had negative values")
	if (b==0):
		return a
	r = a % b
	return gcd(b, r)

def gcd_vector(vect):
	temp = vect[0]
	for i in range(1, len(vect)):
		temp = gcd(temp, vect[i])
	return temp

def extract_ratio(tilesizes):
	g = gcd_vector(tilesizes)
	tile_ratio = []
	for i in range(0, len(tilesizes)):
		tile_ratio += [ int(tilesizes[i]/g) ]
	return (tile_ratio, g)


# For memoisation (to avoid recompiling a code already produced)
def exist_binary(tileratio):
	binname = get_bin_name(tileratio)
	binpath = "./" + binname
	return os.path.isfile(binpath)

# Set of ratio that times out
s_ratio_timeout_codegen = set()

# === Test the kernels for a given tile sizes ===
def test_tilesizes(tilesizes):

	# Extract the tile ratios
	(tile_ratio, tilesize_val) = extract_ratio(tilesizes)
	tile_ratio = tuple(tile_ratio)

	max_ratio = 1
	for i in range(0,len(tile_ratio)):
		max_ratio = max(max_ratio, tile_ratio[i])
	if (max_ratio > limit_ratio):
		# We refuse to run that test in particular
		dummy_res = max_time
		# LOG
		print(str(tilesizes) + "( ratio = " + str(tile_ratio) +
			" | bl = " + str(tilesize_val) + " ) => RATIO TOO BIG")
		return dummy_res

	# Ratio already timeout
	if (tile_ratio in s_ratio_timeout_codegen):
		dummy_res = max_time
		# LOG
		print(str(tilesizes) + "( ratio = " + str(tile_ratio) +
			" | bl = " + str(tilesize_val) + " ) => MPPCODEGEN TIMEOUT")
		return dummy_res


	if ((not memoisation) or (not exist_binary(tile_ratio))):
		# Create the script program (ex: gemm_FS_32_32_32.c)
		create_script_prog(tile_ratio)
		
		# Create the tiled code (ex: gemm_FS_32_32_32_.tiled.c)
		istimeout = create_tiled_code(tile_ratio)
		if (istimeout):
			# We refuse to run that test in particular
			s_ratio_timeout_codegen.add(tile_ratio)

			dummy_res = max_time
			# LOG
			print(str(tilesizes) + "( ratio = " + str(tile_ratio) +
				" | bl = " + str(tilesize_val) + " ) => MPPCODEGEN TIMEOUT")
			return dummy_res
		adapt_tiled_code(tile_ratio)
		clean_interm_tiled_code(tile_ratio)
		
		# Link that code with the test (modify gemm_link.tiled.c)
		mod_link_code(tile_ratio)

		# Compile the kernel
		istimeout = compile_kernel(tile_ratio)
		if (istimeout):
			# We refuse to run that test in particular
			dummy_res = max_time
			# LOG
			print(str(tilesizes) + "( ratio = " + str(tile_ratio) +
				" | bl = " + str(tilesize_val) + " ) => COMPILATION TILED CODE TIMEOUT")
			return dummy_res

	# Execute!
	if (not exist_binary(tile_ratio)):
		# We refuse to run that test in particular
		dummy_res = max_time
		# LOG
		print(str(tilesizes) + "( ratio = " + str(tile_ratio) +
			" | bl = " + str(tilesize_val) + " ) => BINARY CODE NOT PRODUCED")
		return dummy_res
	res = run_kernel_repet(tilesizes, tile_ratio, tilesize_val)
	return res

# ===========================================================================

# === Exploration tools ===

# === BASIC METHODS

# Shape: full rectangle
def get_rectangular_range(min_ts, max_ts, jump_ts):
	assert(len(min_ts)==len(max_ts))
	assert(len(min_ts)==len(jump_ts))
	assert(len(max_ts)<=4)
	l = len(min_ts)

	# Get the list of ts to be explored
	list_ts = []
	current_ts = min_ts[:]
	while (current_ts[l-1]<=max_ts[l-1]):
		list_ts += [current_ts[:]]
		current_ts[0] += jump_ts[0]

		# Carries
		if ((current_ts[0]>max_ts[0]) and (l>=2)):
			current_ts[0] = min_ts[0]
			current_ts[1] += jump_ts[1]
			if ((current_ts[1] > max_ts[1]) and (l>=3)):
				current_ts[1] = min_ts[1]
				current_ts[2] += jump_ts[2]
				if ((current_ts[2] > max_ts[2]) and (l>=4)):
					current_ts[2] = min_ts[2]
					current_ts[3] += jump_ts[3]

	#print("l = " +str(l))
	#print("list_ts = " + str(list_ts))
	return list_ts

# Shape: cross
def get_cross_range(current_ts, r):
	l = len(current_ts)
	list_ts = [current_ts]
	for i in range(0, l):
		for k in range(1, (r+1)):
			new_ts_min = current_ts[:]
			new_ts_min[i] = max(2, new_ts_min[i]-k)
			list_ts += [new_ts_min]
		for k in range(1, (r+1)):
			new_ts_max = current_ts[:]
			new_ts_max[i] = new_ts_max[i]+k
			list_ts+=[new_ts_max]
	return list_ts

# Shape: 3^n rectangle centered on center
def get_cross3stride_range(center, stride):
	l = len(center)
	min_ts = []
	max_ts = []
	for i in range(0,l):
		temp = center[i] - stride[i]
		if (temp < 2):
			raise ValueError("Cross3stride: min_ts at dim " + str(i) + " is below 2.")
		min_ts += [temp]
	for i in range(0,l):
		max_ts += [center[i] + stride[i]]
	return get_rectangular_range(min_ts, max_ts, stride)

# Shape: 3 points along the "ratios" axis
def get_explo_ratio_3_range(ratios, center, stride):
	(rat_center, ts_center) = extract_ratio(center)

	# Checks
	assert(len(ratios) == len(rat_center))
	for i in range(0, len(ratios)):
		assert(ratios[i] == rat_center[i])
	assert(ts_center > stride)		# If wrong, we are going into the negative number for min_ts => reduce the stride

	min_ts = []
	max_ts = []
	for i in range(0, len(center)):
		min_ts += [ (ts_center - stride) * ratios[i]]
		max_ts += [ (ts_center + stride) * ratios[i]]
	
	list_ts = [min_ts, center, max_ts]
	return list_ts

# Shape: small representative ratio inside a rectangle
def get_explo_ratio_rect(min_ts, max_ts, max_ratio):
	l_ts = len(min_ts)
	assert(len(max_ts)==l_ts)

	# dictionaire ratio -> [min / max]
	dict_ts = dict()
	iter_ts = min_ts[:]
	while (iter_ts[l_ts-1] <= max_ts[l_ts-1]):
		(rat_l, g) = extract_ratio(iter_ts)
		rat = tuple(rat_l)

		is_below_max_ratio = True
		for k in range(0, l_ts):
			if (rat[k]>max_ratio):
				is_below_max_ratio = False

		if is_below_max_ratio:
			if (rat in dict_ts):
				dict_ts[rat] = dict_ts[rat] + [g]
			else:
				dict_ts[rat] = [g]

		# Increment the iterator
		iter_ts[0] = iter_ts[0] + 1
		for k in range(0, (l_ts-1)):
			if (iter_ts[k] > max_ts[k]):
				iter_ts[k] = min_ts[k]
				iter_ts[k+1] = iter_ts[k+1] + 1

	# DEBUG
	#print(str(dict_ts))

	# Second pass: filter the results inside dict_ts to select
	# only extremal value + a middle
	dict_ts_filter = dict()
	for (dts, lgts) in iter(dict_ts.items()):
		lgts.sort()
		l_lgts = len(lgts)

		# Min
		ret_lgts = [lgts[0]]
		# Max
		if (l_lgts>=2):
			ret_lgts += [lgts[l_lgts-1]]
		# Middle
		if (l_lgts>=3):
			mid_lgts = int(l_lgts / 2)
			ret_lgts += [lgts[mid_lgts]]
		dict_ts_filter[dts] = ret_lgts

	# DEBUG
	#print("dict_ts_filter = " + str(dict_ts_filter))

	# Final pass: convert the dict_ts into list_ts
	list_ts = []
	for (dts, lgts) in iter(dict_ts_filter.items()):
		for gts in tuple(lgts):
			nts = []
			for k in range(0, l_ts):
				nts += [dts[k] * gts]
			list_ts += [nts]

	# DEBUG
	#print("list_ts = " + str(list_ts))
	#print("len(list_ts) = " + str(len(list_ts)))

	return list_ts


# Scan and try all ts from a list
def scan_list_ts(list_ts):
	lexec_time = []
	for ts in list_ts:
		exec_time = test_tilesizes(ts)
		lexec_time = lexec_time + [(ts, exec_time)]
	return lexec_time

# Analyse result of a scan
def get_min_exec_time(lexec_time):
	# Explore and get the min
	(best_ts, best_exec_time) = lexec_time[0]
	for (ts, exec_time) in lexec_time:
		if (exec_time < best_exec_time):
			best_ts = ts
			best_exec_time = exec_time
	return [best_ts, best_exec_time]


# === COMPOSITE METHODS

# Scan the configurations over a rectangule [min_ts, max_ts]. Both are included
def full_rectangle_explo_with_jump(min_ts, max_ts, jump_ts):
	list_ts = get_rectangular_range(min_ts, max_ts, jump_ts)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

def full_rectangle_explo(min_ts, max_ts):
	jump_ts = []
	for i in min_ts:
		jump_ts += [1]
	return full_rectangle_explo_with_jump(min_ts, max_ts, jump_ts)


# Check the canonic directions for improvement
def cross_explo(current_ts, r):
	list_ts = get_cross_range(current_ts, r)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

def cross3stride_explo(center, stride):
	list_ts = get_cross3stride_range(center, stride)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

# Explore along a tile_ratio
def explo_ratio_3(ratios, center, stride):
	list_ts = get_explo_ratio_3_range(ratios, center, stride)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]

# Explore on the small ratios inside the [min_ts, max_ts] rectangle
def explo_ratio_rect(min_ts, max_ts, max_ratio):
	list_ts = get_explo_ratio_rect(min_ts, max_ts, max_ratio)
	lexec_time = scan_list_ts(list_ts)
	[best_ts, best_exec_time] = get_min_exec_time(lexec_time)
	return [best_ts, best_exec_time]




# ===========================================================================

# Usage:
#	python3.6 script.py [tiling exploration options]
# List of tiling exploration options:
#		* "single [list of ts]"
#		* "rectangle [mints] [maxts]"
#		* "cross [centralts] d"
#		* "rectstride [mints] [maxts] [strides]"
#		* "cross3stride [centralts] [strides]"
#		* "explo_ratio [ratios] [center] [stride]"
#		* "explo_ratio_rect [mints] [maxts] [maxratio_value]"
#		* "clean"
def main():
	# Help
	if (len(sys.argv)==1):
		print("Usage: python3.6 script.py [tiling exploration options]")
		print("List of tiling exploration options:")
		print("\t* single [list of ts]")
		print("\t* rectangle [mints] [maxts]")
		print("\t* cross [centralts] d")
		print("\t* rectstride [mints] [maxts] [strides]")
		print("\t* cross3stride [centralts] [strides]")
		print("\t* explo_ratio [ratios] [center] [stride]")
		print("\t* explo_ratio_rect [mints] [maxts] [maxratio_value]")
		print("\t* clean")
		return

	# Which option is taken?
	option_chosen = sys.argv[1]
	if (option_chosen=="single"):
		ts = []
		for arg in sys.argv[2:]:
			ts += [int(arg)]
		
		assert(len(ts)==dim_tile_size)
		
		exec_time = test_tilesizes(ts)
		# Note: Pretty-printer already inside "test_tilesizes()"
		return
	elif (option_chosen=="rectangle"):
		min_ts = []
		max_ts = []

		l_ts = int((len(sys.argv) - 2) / 2)
		assert(2*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			min_ts += [int(sys.argv[i])]
		for i in range((2+l_ts), len(sys.argv)):
			max_ts += [int(sys.argv[i])]

		assert((len (min_ts))==(len (max_ts)))
		assert(len(min_ts)==dim_tile_size)

		[best_ts,best_exec_time] = full_rectangle_explo(min_ts, max_ts)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="cross"):
		ts = []
		for arg in sys.argv[2:(len(sys.argv)-1)]:
			ts += [int(arg)]
		assert(len(ts)==dim_tile_size)
		d = int(sys.argv[len(sys.argv)-1])
		[best_ts,best_exec_time] = cross_explo(ts, d)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="rectstride"):
		min_ts = []
		max_ts = []
		stride = []
		l_ts = int((len(sys.argv) - 2) / 3)
		assert(3*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			min_ts += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			max_ts += [int(sys.argv[i])]
		for i in range((2+2*l_ts), len(sys.argv)):
			stride += [int(sys.argv[i])]

		assert((len (min_ts))==(len (max_ts)))
		assert((len (min_ts))==(len (stride)))
		assert(len(min_ts)==dim_tile_size)

		[best_ts,best_exec_time] = full_rectangle_explo_with_jump(min_ts, max_ts, stride)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")

	elif (option_chosen=="cross3stride"):
		center = []
		stride = []
		l_ts = int((len(sys.argv) - 2) / 2)
		assert(2*l_ts + 2 == len(sys.argv))  # Same number of dims on the min and the max tilesizes

		for i in range(2, (2+l_ts)):
			center += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			stride += [int(sys.argv[i])]

		assert((len(center))==(len (stride)))
		assert(len(center)==dim_tile_size)

		[best_ts,best_exec_time] = cross3stride_explo(center, stride)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")
	elif (option_chosen=="clean"):
		fileList = glob.glob(kernel_name + "_MPP_*")
		for filePath in fileList:
			os.remove(filePath)
	elif (option_chosen=="explo_ratio"):
		ratio = []
		center = []
		l_ts = int((len(sys.argv) - 3) / 2)
		assert(2*l_ts + 3 == len(sys.argv))  # Same number of dims for ratio and center

		for i in range(2, (2+l_ts)):
			ratio += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			center += [int(sys.argv[i])]
		stride = int(sys.argv[2*l_ts+2])

		[best_ts, best_exec_time] = explo_ratio_3(ratio, center, stride)
		print("Best_ts is: " + str(best_ts) + "  ( exec_time = " + str(best_exec_time) + " )")
	elif (option_chosen=="explo_ratio_rect"):
		min_ts = []
		max_ts = []
		l_ts = int((len(sys.argv) - 3) / 2)
		assert(2*l_ts + 3 == len(sys.argv))  # Same number of dims for ratio and center

		for i in range(2, (2+l_ts)):
			min_ts += [int(sys.argv[i])]
		for i in range((2+l_ts), (2+2*l_ts)):
			max_ts += [int(sys.argv[i])]
		max_ratio = int(sys.argv[2*l_ts+2])

		[best_ts, best_exec_time] = explo_ratio_rect(min_ts, max_ts, max_ratio)
		(ratio, ts) = extract_ratio(best_ts)
		print("Best_ts is: " + str(best_ts) + "  (ratio = " + str(ratio) + " | exec_time = " + str(best_exec_time) + " )")
	else:
		raise ValueError("Option " + option_chosen + " was not recognized.")

	return

# Let's go !
main()
