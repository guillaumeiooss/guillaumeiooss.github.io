#include "test.h"

#include <malloc.h>
#include <stdio.h>

#define true 1
#define false 0

double elem1_1(int i) { return i; }
double elem1_2(int i) { return 2*i; }
double elem2_1(int i, int j) { return i+j; }
double elem2_2(int i, int j) { return 2*i+j; }
double elem2_3(int i, int j) { return i+2*j; }
double elem2_4(int i, int j) { return i+j+1; }
double elem2_inv(int i, int j) { if(i+1>=j) return i+j+1; else return 0; }
double elem2_L(int i, int j) { if(i>=j) return i+j+1; else return 0; }
double elem3_0(int i, int j, int k) { return -1; }
double elem3_1(int i, int j, int k) { return i+j+k; }
double elem3_2(int i, int j, int k) { return 2*i+j-k; }
double elem4_1(int i, int j, int k, int l) { return i+j+k+l; }
double elem4_2(int i, int j, int k, int l) { return 2*i+j-k+l; }
double elem4_3(int i, int j, int k, int l) { return 2*j+k-l; }


// Polybench initialisations
double elem_polyb_1_1A(int i, int n) { return (double) ((i+1)/ ((double) n))/2.0; }
double elem_polyb_1_1AA(int i, int n) { return (double) ((i+1)/ ((double) n))/2.0 + 4.0; }
double elem_polyb_1_1B(int i, int n) { return (double) ((i+1)/ ((double) n))/4.0; }
double elem_polyb_1_1C(int i, int n) { return (double) ((i+1)/ ((double) n))/6.0; }
double elem_polyb_1_1D(int i, int n) { return (double) ((i+1)/ ((double) n))/8.0; }
double elem_polyb_1_1E(int i, int n) { return (double) ((i+1)/ ((double) n))/9.0; }
double elem_polyb_1_2(int i) { return (double) 0.0; }
double elem_polyb_1_3(int i, int n) { return (double) (i % n) / n; }
double elem_polyb_1_3B(int i, int n) { return (double) ((i+1) % n) / n; }
double elem_polyb_1_3C(int i, int n) { return (double) ((i+3) % n) / n; }
double elem_polyb_1_3D(int i, int n) { return (double) ((i+4) % n) / n; }
double elem_polyb_1_4(int i, int n) { return (double) 1 + (i / ((double) n)); }
double elem_polyb_1_5(int i) { return (double) -999; }
double elem_polyb_1_6(int i, int n) { return ((double) i+2) / n; }
double elem_polyb_1_7(int i, int n) { return ((double) i+3) / n; }

double elem_polyb_2_1_1(int i, int j, int n) { return (double) ((i*j+1) % n) / n; }
double elem_polyb_2_1_2(int i, int j, int n) { return (double) (i*(j+1) % n) / n; }
double elem_polyb_2_1_3(int i, int j, int n) { return (double) (i*(j+2) % n) / n; }
double elem_polyb_2_1_4(int i, int j, int n) { return (double) (i*j % n) / n; }
double elem_polyb_2_1_5(int i, int j, int n) { return (double) ((i*j+2) % n) / n; }
double elem_polyb_2_1_6(int i, int j) { return (double) 0.0; }
double elem_polyb_2_1_7(int i, int j, int n) { return (double) ((i+j) % 100) / n; }
double elem_polyb_2_1_8(int i, int j, int n) {
	if (j<=i) { return (double) ((i+j) % 100) / n; } else {return (double) -999; }
}
double elem_polyb_2_1_9(int i, int j, int n) { return (double) ( (i+j) % n) / n; }
double elem_polyb_2_1_10(int i, int j, int n) { return (double) ( (n+(i-j)) % n) / n; }
double elem_polyb_2_1_11(int i, int j, int n) { return (double) ((i*(j+3)+1) % n) / n; }

double elem_polyb_2_1_12A(int i, int j, int n) { return (double) ((i*j+1) % n) / (5*n); }
double elem_polyb_2_1_12B(int i, int j, int n) { return (double) ((i*(j+1)+2) % n) / (5*n); }
double elem_polyb_2_1_12C(int i, int j, int n) { return (double) ((i*(j+3)) % n) / (5*n); }
double elem_polyb_2_1_12D(int i, int j, int n) { return (double) ((i*(j+2)+2) % n) / (5*n); }

double elem_polyb_2_1_cholesky(int i, int j, int n) {
	if (j<i) { return (double)(-j % n) / n + 1; } else
	if (j==i) { return (double) 1; } else {return (double) 0; }
}
double elem_polyb_2_1_13(int i, int j, int n) { return (double) ((double) (((i*j) % n) / n)*100) + 10; }
double elem_polyb_2_1_14(int i, int j, int n) { return (double) (i+n-j+1)*2/ n; }
double elem_polyb_2_1_15(int i, int j, int n) { return (double) (i*j)/ n + i; }
double elem_polyb_2_1_16(int i, int j) { if (i==j) {return (double) 1.0;} else {return (double) 0.0;} }
double elem_polyb_2_1_17(int i, int j, int n) { return ((double) (i*j))/ n; }
double elem_polyb_2_1_flwar(int i, int j) {
    double temp = i*j%7+1;
    if ((i+j)%13 == 0 || (i+j)%7==0 || (i+j)%11 == 0)
      return (double) 999;
    else
      return temp;
}

double elem_polyb_2_1_stencil_1(int i, int j, int n) { return ((double) i*(j+1))/ n; }
double elem_polyb_2_1_stencil_2(int i, int j, int n) { return ((double) i*(j+2))/ n; }
double elem_polyb_2_1_stencil_3(int i, int j, int n) { return ((double) i*(j+3))/ n; }
double elem_polyb_2_1_stencil_4(int i, int j, int n) { return ((double) i*(j+2) + 2)/ n; }
double elem_polyb_2_1_stencil_5(int i, int j, int n) { return ((double) i*(j+3) + 3)/ n; }
double elem_polyb_2_j1d_1(int i, int j, int n) { return ((double) i+2) / n; }
double elem_polyb_2_j1d_2(int i, int j, int n) { return ((double) i+3) / n; }

double elem_polyb_2_2_1(int i, int j, int n, int m) { return (double) ((n+i-j) % 100) / m; }
double elem_polyb_2_2_2(int i, int j, int n, int m) { return (double) ((i*j+3) % n) / m; }
double elem_polyb_2_2_3(int i, int j, int n, int m) { return (double) ((i+j) % n) / (5*m); }


double elem_polyb_3_1(int i, int j, int k) { return (double) 0.0; }
double elem_polyb_3_2(int i, int j, int k, int n) { return (double) ((i*j + k)%n) / n; }

double elem_polyb_4_1(int dumm, int i, int j, int k, int n) { return (double) (i+j + n - k) * 10 / n; }



void init1_1(int nb_lines, double (*element)(int), double POLYBENCH_1D(result, nb_lines, nb_lines))
{
  int i;

  //Init A
  for(i=0; i<nb_lines; i++)
    result[i] = (*element)(i);

  return;
}

void init1_2(int nb_lines, int param, double (*element)(int, int), double POLYBENCH_1D(result, nb_lines, nb_lines))
{
  int i;
  
  //Init A
  for(i=0; i<nb_lines; i++)
    result[i] = (*element)(i, param);

  return;
}

void init2_2(int nb_lines, int nb_cols, double (*element)(int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols))
{
  int i,j;

  //Init A
  for(i=0; i<nb_lines; i++)
    for(j=0; j<nb_cols; j++)
      result[i][j] = (*element)(i,j);

  return;
}

void init2_3(int nb_lines, int nb_cols, int param, double (*element)(int,int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols))
{
  int i,j;

  //Init A
  for(i=0; i<nb_lines; i++)
    for(j=0; j<nb_cols; j++)
      result[i][j] = (*element)(i,j, param);

  return;
}

void init2_4(int nb_lines, int nb_cols, int param1, int param2, double (*element)(int,int,int,int),
    double POLYBENCH_2D(result, nb_lines, nb_cols, nb_lines, nb_cols))
{
  int i,j;

  //Init A
  for(i=0; i<nb_lines; i++)
    for(j=0; j<nb_cols; j++)
      result[i][j] = (*element)(i,j, param1, param2);

  return;
}


void init3_3(int n1, int n2, int n3, double (*element)(int,int,int),
    double POLYBENCH_3D(result, n1, n2, n3, n1, n2, n3))
{
  int i,j,k;
  
  //Init A
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
  result[i][j][k] = (*element)(i,j,k);

  return;
}

void init3_4(int n1, int n2, int n3, int param, double (*element)(int,int,int,int),
    double POLYBENCH_3D(result, n1, n2, n3, n1, n2, n3))
{
  int i,j,k;

  //Init A
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
  result[i][j][k] = (*element)(i,j,k,param);

  return;
}


void init4_4(int n1, int n2, int n3, int n4, double (*element)(int,int,int,int),
    double POLYBENCH_4D(result, n1, n2, n3, n4, n1, n2, n3, n4))
{
  int i,j,k,l;
  
  //Init A
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
  for(l=0; l<n4; l++)
    result[i][j][k][l] = (*element)(i,j,k,l);

  return;
}

void init4_5(int n1, int n2, int n3, int n4, int param, double (*element)(int,int,int,int,int),
    double POLYBENCH_4D(result, n1, n2, n3, n4, n1, n2, n3, n4))
{
  int i,j,k,l;

  //Init A
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
  for(l=0; l<n4; l++)
    result[i][j][k][l] = (*element)(i,j,k,l, param);

  return;
}


void print1(int nb_lines, double POLYBENCH_1D(A, nb_lines, nb_lines))
{
  int i;
  for(i=0; i<nb_lines; i++)
    printf("%f\n",A[i]);
}

void print2(int nb_lines, int nb_cols, double POLYBENCH_2D(A, nb_lines, nb_cols, nb_lines, nb_cols))
{
  int i,j;
  for(i=0; i<nb_lines; i++)
    {
      for(j=0; j<nb_cols; j++)
	printf("%f ",A[i][j]);
      printf("\n");
    }
}

void print3(int n1, int n2, int n3, double POLYBENCH_3D(A, n1, n2, n3, n1, n2, n3))
{
  int i,j,k;
  for(i=0; i<n1; i++)
    {
      printf("i = %d\n",i);
      for(j=0; j<n2; j++)
	{
	  for(k=0; k<n3; k++)
	    printf("%f ",A[i][j][k]);
	  printf("\n");
	}
      printf("\n");
    }
}

void print4(int n1, int n2, int n3, int n4, double POLYBENCH_4D(A, n1, n2, n3, n4, n1, n2, n3, n4))
{
  int i,j,k,l;
  for(i=0; i<n1; i++) {
    printf("i = %d\n",i);
    for(j=0; j<n2; j++) {
      for(k=0; k<n3; k++) {
        for (l=0; l<n4; l++)
          printf("%f ",A[i][j][k][l]);
	printf("\n");
      }
      printf("\n");
    }
    printf("\n");
  }
}

int is_equal1(double* a, double* b, int nb_lines)
{
  int i;
  for(i=0; i<nb_lines; i++)
    if(a[i] != b[i])
      return false;
  return true;
}

int is_equal2(double** A, double** B, int nb_lines, int nb_cols)
{
  int i,j;
  for(i=0; i<nb_lines; i++)
    for(j=0; j<nb_cols; j++)
      if(A[i][j] != B[i][j])
	return false;
  return true;
}

int is_equal3(double*** A, double*** B, int n1, int n2, int n3)
{
  int i,j,k;
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
	if(A[i][j][k] != B[i][j][k])
	  return false;
  return true;
}

int is_equal4(double**** A, double**** B, int n1, int n2, int n3, int n4)
{
  int i,j,k,l;
  for(i=0; i<n1; i++)
    for(j=0; j<n2; j++)
      for(k=0; k<n3; k++)
	for(l=0; l<n4; l++)
	  if(A[i][j][k][l] != B[i][j][k][l])
	    return false;
  return true;
}

/* void main() */
/* { */
/*   int* a; */
/*   int** A; */
/*   int** B; */

/*   a = init1(3,&elem1_1); */
/*   print1(a,3); */

/*   A = init2(3,4,&elem2_1); */
/*   B = init2(3,4,&elem2_2); */
/*   print2(A,3,4); */
/*   if(is_equal2(A,B,3,4)) */
/*     printf("PASSED\n"); */
/*   else */
/*     printf("FAIL\n"); */
/*   //  print2(A,3,4); */
/* } */
