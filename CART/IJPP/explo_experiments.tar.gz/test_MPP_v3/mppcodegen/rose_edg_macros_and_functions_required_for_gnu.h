// #ifndef _ROSE_EDG_MACROS_AND_FUNCTIONS_REQUIRED_FOR_GNU_H
#define _ROSE_EDG_MACROS_AND_FUNCTIONS_REQUIRED_FOR_GNU_H	1

#define __STDC__ 1
#define __WCHAR_TYPE__ int
#define __WINT_TYPE__ unsigned int
#define __INTMAX_TYPE__ long int
#define __UINTMAX_TYPE__ long unsigned int
#define __GXX_WEAK__ 1
#define __DEPRECATED 1
#define __GXX_RTTI 1
#define __GXX_ABI_VERSION 1002
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 32767
#define __INT_MAX__ 2147483647
#define __LONG_MAX__ 9223372036854775807L
#define __LONG_LONG_MAX__ 9223372036854775807LL
#define __WCHAR_MAX__ 2147483647
#define __CHAR_BIT__ 8
#define __INTMAX_MAX__ 9223372036854775807L
#define __FLT_EVAL_METHOD__ 0
#define __DEC_EVAL_METHOD__ 2
#define __FLT_RADIX__ 2
#define __FLT_MANT_DIG__ 24
#define __FLT_DIG__ 6
#define __FLT_MIN_EXP__ (-125)
#define __FLT_MIN_10_EXP__ (-37)
#define __FLT_MAX_EXP__ 128
#define __FLT_MAX_10_EXP__ 38
#define __FLT_MAX__ 3.40282347e+38F
#define __FLT_MIN__ 1.17549435e-38F
#define __FLT_EPSILON__ 1.19209290e-7F
#define __FLT_DENORM_MIN__ 1.40129846e-45F
#define __FLT_HAS_DENORM__ 1
#define __FLT_HAS_INFINITY__ 1
#define __FLT_HAS_QUIET_NAN__ 1
#define __DBL_MANT_DIG__ 53
#define __DBL_DIG__ 15
#define __DBL_MIN_EXP__ (-1021)
#define __DBL_MIN_10_EXP__ (-307)
#define __DBL_MAX_EXP__ 1024
#define __DBL_MAX_10_EXP__ 308
#define __DBL_MAX__ 1.7976931348623157e+308
#define __DBL_MIN__ 2.2250738585072014e-308
#define __DBL_EPSILON__ 2.2204460492503131e-16
#define __DBL_DENORM_MIN__ 4.9406564584124654e-324
#define __DBL_HAS_DENORM__ 1
#define __DBL_HAS_INFINITY__ 1
#define __DBL_HAS_QUIET_NAN__ 1
#define __LDBL_MANT_DIG__ 64
#define __LDBL_DIG__ 18
#define __LDBL_MIN_EXP__ (-16381)
#define __LDBL_MIN_10_EXP__ (-4931)
#define __LDBL_MAX_EXP__ 16384
#define __LDBL_MAX_10_EXP__ 4932
#define __DECIMAL_DIG__ 21
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
#define __LDBL_HAS_DENORM__ 1
#define __LDBL_HAS_INFINITY__ 1
#define __LDBL_HAS_QUIET_NAN__ 1
#define __DEC32_MANT_DIG__ 7
#define __DEC32_MIN_EXP__ (-95)
#define __DEC32_MAX_EXP__ 96
#define __DEC32_MIN__ 1E-95DF
#define __DEC32_MAX__ 9.999999E96DF
#define __DEC32_EPSILON__ 1E-6DF
#define __DEC32_DEN__ 0.000001E-95DF
#define __DEC64_MANT_DIG__ 16
#define __DEC64_MIN_EXP__ (-383)
#define __DEC64_MAX_EXP__ 384
#define __DEC64_MIN__ 1E-383DD
#define __DEC64_MAX__ 9.999999999999999E384DD
#define __DEC64_EPSILON__ 1E-15DD
#define __DEC64_DEN__ 0.000000000000001E-383DD
#define __DEC128_MANT_DIG__ 34
#define __DEC128_MIN_EXP__ (-6143)
#define __DEC128_MAX_EXP__ 6144
#define __DEC128_MIN__ 1E-6143DL
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
#define __DEC128_EPSILON__ 1E-33DL
#define __DEC128_DEN__ 0.000000000000000000000000000000001E-6143DL
#define __REGISTER_PREFIX__ 
#define __USER_LABEL_PREFIX__ 
#define __GNUC_GNU_INLINE__ 1
#define _LP64 1
#define __LP64__ 1
#define __NO_INLINE__ 1
#define __FINITE_MATH_ONLY__ 0
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
#define __SIZEOF_INT__ 4
#define __SIZEOF_LONG__ 8
#define __SIZEOF_LONG_LONG__ 8
#define __SIZEOF_SHORT__ 2
#define __SIZEOF_FLOAT__ 4
#define __SIZEOF_DOUBLE__ 8
#define __SIZEOF_LONG_DOUBLE__ 16
#define __SIZEOF_SIZE_T__ 8
#define __SIZEOF_WCHAR_T__ 4
#define __SIZEOF_WINT_T__ 4
#define __SIZEOF_PTRDIFF_T__ 8
#define __SIZEOF_POINTER__ 8
#define __amd64 1
#define __amd64__ 1
#define __x86_64 1
#define __x86_64__ 1
#define __k8 1
#define __k8__ 1
#define __MMX__ 1
#define __SSE__ 1
#define __SSE2__ 1
#define __SSE_MATH__ 1
#define __SSE2_MATH__ 1
#define __gnu_linux__ 1
#define __linux 1
#define linux 1
#define __unix 1
#define unix 1
#define __ELF__ 1
#define __DECIMAL_BID_FORMAT__ 1
#define _GNU_SOURCE 1

// DQ (4/12/2005): Macros that were previously on the commandline to the EDG front-end
// (some are set by EDG in their GNU compatability mode, now turned on).
// #define __null 0
// #define __extension__ 
// #define __const const
// #define __attribute__(arg)
// #define __restrict 
// #define __inline
// #define _GLIBCXX_HAVE_STDINT_H
// #define _GLIBCXX_EXTERN_TEMPLATE 0
// #define __builtin_expect(x,y) (x)
#define __PRETTY_FUNCTION__ 0

#if 0
/* DQ (5/20/2006): Newer ROSE representation (values obtained from "cpp -E -dM /dev/null"  
   using g++ 3.3.2 on a 32 bit machine and might not be correct for all architectures) 
 */
#define __CHAR_BIT__ 8
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 127
#define __WCHAR_MAX__ 2147483647
#define __INT_MAX__ 2147483647
#define __LONG_MAX__ 2147483647
#define __LONG_LONG_MAX__ 2147483647
#define __FLT_RADIX__ 2
#define __FLT_MANT_DIG__ 24
#define __FLT_DIG__ 6
#define __FLT_EPSILON__ 1.19209290e-07F
#define __FLT_MIN__ 1.17549435e-38F
#define __FLT_MAX__ 3.40282347e+38F
#define __FLT_MIN_EXP__ (-125)
#define __FLT_MIN_10_EXP__ (-37)
#define __FLT_MAX_EXP__ 128
#define __FLT_MAX_10_EXP__ 38
#define __FLT_DENORM_MIN__ 1.40129846e-45F
#define __DBL_MANT_DIG__ 53
#define __DBL_DIG__ 15
#define __DBL_EPSILON__ 2.2204460492503131e-16
#define __DBL_MIN__ 2.2250738585072014e-308
#define __DBL_MAX__ 1.7976931348623157e+308
#define __DBL_MIN_EXP__ (-1021)
#define __DBL_MIN_10_EXP__ (-307)
#define __DBL_MAX_EXP__ 1024
#define __DBL_MAX_10_EXP__ 308
#define __DBL_DENORM_MIN__ 4.9406564584124654e-324
#define __LDBL_MANT_DIG__ 53
#define __LDBL_DIG__ 15 
#define __LDBL_EPSILON__ 2.2204460492503131e-16
#define __LDBL_MIN__ 2.2250738585072014e-308
#define __LDBL_MAX__ 1.7976931348623157e+308
#define __LDBL_MIN_EXP__ (-1021)
#define __LDBL_MIN_10_EXP__ (-307)
#define __LDBL_MAX_EXP__ 1024
#define __LDBL_MAX_10_EXP__ 308
#define __LDBL_DENORM_MIN__ 4.94065645841246544176568792868221e-324L 

#endif


#if 0
/* DQ (5/20/2006): Older ROSE representation */
#define __CHAR_BIT__ 7U
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 127
#define __INT_MAX__ 2147483647
#define __LONG_MAX__ 2147483647
#define __LONG_LONG_MAX__ 2147483647
#define __FLT_MANT_DIG__ 8U
#define __FLT_DIG__ 8U
#define __FLT_RADIX__ 8U
#define __FLT_MIN_EXP__ 8U
#define __FLT_MIN_10_EXP__ 8U
#define __FLT_MAX_EXP__    0U
#define __FLT_MAX_10_EXP__ 0U
#define __FLT_DENORM_MIN__ 0
#define __FLT_MIN__ 0
#define __FLT_MAX__ 0
#define __FLT_EPSILON__ 0
#define __DBL_MANT_DIG__ 0
#define __DBL_DIG__ 0
#define __DBL_MIN_EXP__ 0
#define __DBL_MIN_10_EXP__ 0
#define __DBL_MAX_10_EXP__ 0
#define __DBL_MAX_EXP__ 0
#define __DBL_DENORM_MIN__ 0
#define __DBL_MIN__ 0
#define __DBL_MAX__ 0
#define __DBL_EPSILON__ 0
#define __LDBL_MANT_DIG__ 0
#define __LDBL_DIG__ 0
#define __LDBL_MIN_EXP__ 0
#define __LDBL_MIN_10_EXP__ 0
#define __LDBL_MAX_EXP__ 0
#define __LDBL_MAX_10_EXP__ 0
#define __LDBL_DENORM_MIN__ 0
#define __LDBL_MIN__ 0
#define __LDBL_MAX__ 0
#define __LDBL_EPSILON__ 0
#endif

/* DQ (5/20/2006): These should be defined to be appropriate values 
   or defined as function prototypes as others are below 
 */
#define __builtin_huge_valf() 0
#define __builtin_nanf(string) 0
#define __builtin_huge_val() 0
#define __builtin_nan(string) 0
#define __builtin_huge_vall() 0
#define __builtin_nanl(string) 0

// DQ (8/27/2004):
// I don't think we can handle the code in this header file so 
// just ignore it for now (if we can get away with that).
#define _BITS_ATOMICITY_H	1

// DQ (6/12/2005): Permit this to be optionally commented out because it makes it hard to look at the AST merging graphs
// #define REDUCE_COMMON_DECLARATIONS_FOR_DEBUGGING_AST_MERGE
#ifndef REDUCE_COMMON_DECLARATIONS_FOR_DEBUGGING_AST_MERGE

// DQ (4/12/2005): Required to compile the gnu version 3.4.3 cmath header file. Defined
//                 as functions instead of macros to avoid constant propagation issues.
float       __builtin_acosf  (float __builtin__x);
long double __builtin_acosl  (long double __builtin__x);
float       __builtin_asinf  (float __builtin__x);
long double __builtin_asinl  (long double __builtin__x);
float       __builtin_atanf  (float __builtin__x);
long double __builtin_atanl  (long double __builtin__x);
float       __builtin_atan2f (float __builtin__x,float __builtin__y);
long double __builtin_atan2l (long double __builtin__x,long double __builtin__y);
float       __builtin_ceilf  (float __builtin__x);
long double __builtin_ceill  (long double __builtin__x);
float       __builtin_coshf  (float __builtin__x);
long double __builtin_coshl  (long double __builtin__x);
float       __builtin_floorf (float __builtin__x);
long double __builtin_floorl (long double __builtin__x);
float       __builtin_fmodf  (float __builtin__x,float __builtin__y);
long double __builtin_fmodl  (long double __builtin__x,long double __builtin__y);
float       __builtin_frexpf (float __builtin__x,int *__builtin__y);
long double __builtin_frexpl (long double __builtin__x,int *__builtin__y);
float       __builtin_ldexpf (float __builtin__x,float __builtin__y);
long double __builtin_ldexpl (long double __builtin__x,long double __builtin__y);
float       __builtin_log10f (float __builtin__x);
long double __builtin_log10l (long double __builtin__x);
float       __builtin_modff  (float __builtin__x,float *__builtin__y);
long double __builtin_modfl  (long double __builtin__x,long double *__builtin__y);
float       __builtin_powf   (float __builtin__x,float __builtin__y);
long double __builtin_powl   (long double __builtin__x,long double __builtin__y);
float       __builtin_sinhf  (float __builtin__x);
long double __builtin_sinhl  (long double __builtin__x);
float       __builtin_tanf   (float __builtin__x);
long double __builtin_tanl   (long double __builtin__x);
float       __builtin_tanhf  (float __builtin__x);
long double __builtin_tanhl  (long double __builtin__x);

// DQ (7/29/2005): declarations for builtin functions used by GNU, but 
// already defined in EDG (it seems that we can provide declarations for 
// them explicitly).  These should be marked as compiler generated in 
// the AST.
char *      __builtin_strchr (const char *__builtin__s, int __builtin__c);
char *      __builtin_strrchr(const char *__builtin__s, int __builtin__c);
char *      __builtin_strpbrk(const char *__builtin__s, const char *__builtin__accept);
char *      __builtin_strstr (const char *__builtin__haystack, const char *__builtin__needle);
float       __builtin_nansf  (const char *__builtin__x);
double      __builtin_nans   (const char *__builtin__x);
long double __builtin_nansl  (const char *__builtin__x);
double      __builtin_fabs   (double      __builtin__x);
float       __builtin_fabsf  (float       __builtin__x);
long double __builtin_fabsl  (long double __builtin__x);
float       __builtin_cosf   (float       __builtin__x);
long double __builtin_cosl   (long double __builtin__x);
// Redundent declarations reported by lint
// float       __builtin_fabsf  (float       __builtin__x);
// long double __builtin_fabsl  (long double __builtin__x);
float       __builtin_sinf   (float       __builtin__x);
long double __builtin_sinl   (long double __builtin__x);
float       __builtin_sqrtf  (float       __builtin__x);
long double __builtin_sqrtl  (long double __builtin__x);

// DQ (5/15/2006): Suggested by Christian Biesinger (working with Markus Schordan)
long double __builtin_powil  (long double __builtin__x, int __builtin__i);
double      __builtin_powi   (double __builtin__x, int __builtin__i);
float       __builtin_powif  (float __builtin__x, int __builtin__i);

// required elsewhere, but defined in atomicity.h 
// (which we turned off with by setting _BITS_ATOMICITY_H true)
typedef int _Atomic_word;

// used in locale_classes.h (and defined in g++/include/bits/atomicity.h)
void __atomic_add(_Atomic_word *__builtin__x,int __builtin__y);
int  __exchange_and_add(_Atomic_word *__builtin__x,int __builtin__y);

// required support for varargs
// void __builtin_va_start(__builtin_va_list &, void*);
#define __builtin_va_start va_start

// DQ 10/20/2005): Need to make 2nd argument a const void * type (I think)
// void va_start(__builtin_va_list __builtin__x, void* __builtin__y);
// void va_start(__builtin_va_list __builtin__x, const char *__builtin__y);
void va_start(__builtin_va_list __builtin__x, const void* __builtin__y);

// DQ (7/13/2005): This problem is not fixed and we don't need a declaration for the __builtin_va_list 
// typedef to eat!  Milin Kulkarni was very helpfulin pointing out the issue that allowed this problem 
// to be better understood an fixed in the EDG/Sage III translation.
// DQ (4/12/2005): This is a bizzar EDG bug which I have not figured out (except to verify that it is present).
// Bug: EDG will ignore this declaration following the declaration of 
//      either "void __builtin_va_start(__builtin_va_list &, void*);" or
//      "void va_start(__builtin_va_list &, void*);"
int _April_12_2005 = 0;

#endif

#if 0
/* DQ (6/27/2006): This is now handled by building a ROSE specific cdefs.h header file. */

/* We need to have __flexarr defined as [1] (done incorrectly in /usr/include/sys/cdefs.h) 
   Though since it is redefined in /usr/include/cdef.h this might not be enough!
 */
#ifndef __flexarr
/* #warning "__flexarr is NOT defined" */
   #define __flexarr [1]
#else
/* #warning "__flexarr WAS already defined (was defined as [] but now redefined as [1])" */
   #undef __flexarr
   #define __flexarr [1]
#endif
#endif

/* DQ (6/4/2005): Need to compile g++ 3.4 header files used in test201_11.C 
   It appears sufficent to specify these here instead of in ROSE/config/compiler-defs.m4
   (the command line to EDG) 
 */
#define __FLT_HAS_INFINITY__ 1
#define __DBL_HAS_INFINITY__ 1
#define __LDBL_HAS_INFINITY__ 1
#define __FLT_HAS_QUIET_NAN__ 1
#define __DBL_HAS_QUIET_NAN__ 1
#define __LDBL_HAS_QUIET_NAN__ 1

/* DQ (10/30/2005): Added to allow compilation of g++ 
complex header, but this is likely the wrong thing to do.
This allows us to compile C++ code that uses the complex header file
but it turns "__complex__ double x" into just "double x". All this
is because the "__complex__" keyword is not supported in EDG.  Not
too much of a problem except that it means that the member function:
    complex(_ComplexT __z) : _M_value(__z) { }
needs to be specified using the "explicit" keyword.   Note that
none of this is required in g++ or icc, just in our version of 
ROSE using the g++ header files (because __complex__ is not
defined in EDG and the only thing to map it to is "", I think).

The following solution does NOT work.  Replacing
    typedef __complex__ double _ComplexT;
with
    typedef complex<double> _ComplexT;
in the complex header file.

The following solution does work.  Replacing
    complex(_ComplexT __z) : _M_value(__z) { }
with
    explicit complex(_ComplexT __z) : _M_value(__z) { }
in the complex header file.  It is not a great solution
and it would have to be done in the configuration of ROSE
to the complex header file.  It would also fool any analysis
of the complex class into thinking that the internal type 
was just float or double for complex<float> or complex<double>.
 */
// Note that _Complex is a C99 type for complex and does not make 
// since in C++ (nor as a type modifier for a floating point type).
// #define __complex__ _Complex
#define __complex__
#define __real__ 
#define __imag__

#if 0
// DQ (2/16/2006): Define the std namespace so it has an explicit definition in ROSE
namespace std
{
}
#endif

/* endif for _ROSE_EDG_MACROS_AND_FUNCTIONS_REQUIRED_FOR_GNU_H */
/* endif */
