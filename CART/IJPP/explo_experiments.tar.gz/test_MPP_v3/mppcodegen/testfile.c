void kernel_gemm()
{
  /*
  efine NI 512
  efine NJ 512
  efine NK 512
  */
 
  int NI=512;
  int NJ=512;
  int NK=512;

  int i, j, k;

  double alpha;
  double beta;
  double** C;
  double** A;
  double** B;

//BLAS PARAMS
//TRANSA = 'N'
//TRANSB = 'N'
// => Form C := alpha*A*B + beta*C,
//A is NIxNK
//B is NKxNJ
//C is NIxNJ
#pragma begin_scop
  for (i = 0; i < NI; i++) {
    for (j = 0; j < NJ; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][0]
#pragma schedule[__T][__T][__T][i][0][0][j]
	C[i][j] = C[i][j] * beta;
    for (k = 0; k < NK; k++) {
       for (j = 0; j < NJ; j++)
#pragma tile_group[0]
#pragma tile_size[16][16][16]
#pragma tile_hyperplans[i][j][k]
#pragma schedule[__T][__T][__T][i][k][1][j]
	  C[i][j] = C[i][j] + alpha * A[i][k] * B[k][j];
    }
  }
#pragma end_scop

}

