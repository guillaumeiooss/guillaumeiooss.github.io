#include <math.h>
#include <iostream>
#include <stdio.h>
using namespace std;

#define min(x,y)  (x<y?x:y)
#define max(x,y)  (x<y?y:x)
#define ceild(n,d)  ceil(((double)(n))/((double)(d)))
#define floord(n,d) floor(((double)(n))/((double)(d)))

/*
  efine NI 512
  efine NJ 512
  efine NK 512
  */
int NI = 512;

double **A;
double **B;
double **C;
double alpha;
double beta;
int NJ = 512;
int NK = 512;
int i;
int j;
int k;

#define S0(i,j,tile_counter_0,tile_counter_1,tile_counter_2) { C[(i)][(j)]=C[(i)][(j)]*beta; }
#define S1(i,k,j,tile_counter_0,tile_counter_1,tile_counter_2) { C[(i)][(j)]=C[(i)][(j)]+((alpha*A[(i)][(k)])*B[(k)][(j)]); }

void tiled_kernel() {
for (int c0 = 0; c0 <= floord(NI - 1, 16); c0 += 1)
  for (int c1 = 0; c1 <= floord(NJ - 1, 16); c1 += 1) {
    for (int c2 = 0; c2 <= floord(NK - 1, 16); c2 += 1)
      for (int c3 = 16 * c0; c3 <= min(NI - 1, 16 * c0 + 15); c3 += 1) {
        if (c2 == 0)
          for (int c6 = 16 * c1; c6 <= min(NJ - 1, 16 * c1 + 15); c6 += 1)
            S0(c3, c6, c0, c1, 0);
        for (int c4 = 16 * c2; c4 <= min(NK - 1, 16 * c2 + 15); c4 += 1)
          for (int c6 = 16 * c1; c6 <= min(NJ - 1, 16 * c1 + 15); c6 += 1)
            S1(c3, c4, c6, c0, c1, c2);
      }
    if (NK <= 0)
      for (int c3 = 16 * c0; c3 <= min(NI - 1, 16 * c0 + 15); c3 += 1)
        for (int c6 = 16 * c1; c6 <= min(NJ - 1, 16 * c1 + 15); c6 += 1)
          S0(c3, c6, c0, c1, 0);
  }
}
