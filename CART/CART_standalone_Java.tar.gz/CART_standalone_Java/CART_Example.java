package CART_standalone;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * Example of usage of the CART transformation.
 * 
 * @author Guillaume Iooss
 */
public class CART_Example {
	
	@Test
	public void test_CARTDomain() {
		// kmin/max computation option => 0: all possible values of b | 1: b "big enough"
		CART.changekMinMaxOption(0);
		
		/* Example 1: { i,j | N-1-i-j>=0 } with tiles of size b*b
		long[][] polyScalar =  {{0, 1, -1, -1, -1}};
		List<Integer> scale = new ArrayList<Integer>();
		scale.add(1); scale.add(1);
		List<List<long[][]> > llBlDom = CART.getTiledDomain(polyScalar, 1, 2, scale);
		printoutDomain(llBlDom);
		
		// RESULT: union of 3 polyhedra:
		//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
		//( 1 | 1 0 | 0 | -1 -1 |  0  0 |  0 )
		//( 0 | 0 1 | 0 |  0  0 | -1 -1 | -1 )
		//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
		//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
		//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
		//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
		// and
		//( 1 | 1 0 | 0 | -1 -1 |  0  0 | -1 )
		//( 0 | 0 1 | 1 |  0  0 | -1 -1 | -1 )
		//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
		//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
		//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
		//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
		// and
		//( 0 | 1 0 | 0 | -1 -1 |  0  0 | -2 )
		//( 0 | 0 0 | 0 |  0  0 |  1  0 |  0 )
		//( 0 | 0 0 | 0 |  0  0 |  0  1 |  0 )
		//( 0 | 0 0 | 1 |  0  0 | -1  0 | -1 )
		//( 0 | 0 0 | 1 |  0  0 |  0 -1 | -1 )
		//	=> { i,j,alpha,beta | Nbl = alpha+beta && Nloc-1-ii-jj>=0 && 0<=ii,jj<b } U { i,j,alpha,beta | Nbl = alpha+beta+1 && Nloc+b-1-ii-jj>=0 && 0<=ii,jj<b }
		//			U { i,j,alpha,beta | Nbl >= alpha+beta+2 && 0<=ii,jj<b }
		//*/
		
		//* Example 2: {i,j | i-j>=0 && 2j-i>=0 && N-1-j>=0 } with tiles of size b*b
		long[][] polyScalar2 = {
				{0, 0,  1, -1,  0},
				{0, 0, -1,  2,  0},
				{0, 1,  0, -1, -1}};
		List<Integer> scale2 = new ArrayList<Integer>();
		scale2.add(1); scale2.add(1);
		printoutDomain(CART.getTiledDomain(polyScalar2, 1, 2, scale2));
		// RESULT: intersection between 3 unions of polyhedra (each union corresponding to a given constraint)
		// (we omit systematically the last 4 lines of constaints, which are 0<=i,j<b
		// * First union:
		//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
		//( 1 | 0 0 | 0 | 1 -1 | 0  0 | 0 )
		//( 0 | 0 0 | 0 | 0  0 | 1 -1 | 0 )
		// and
		//( 0 | 0 0 | 0 | 1 -1 |  0  0 |  0 )
		//  => {i,j,alpha,beta | alpha=beta && ii>=jj && 0<=ii,jj<b } U {i,j,alpha,beta | alpha>=beta+1 && 0<=ii,jj<b }
		//
		// * Second union:
		//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
		//( 1 | 0 0 |  0 | -1 2 |  0  0 |  0 )
		//( 0 | 0 0 | -1 |  0 0 | -1  2 |  0 )
		// and
		//( 1 | 0 0 |  0 | -1 2 |  0 0 | 1 )
		//( 0 | 0 0 | -1 |  0 0 | -1 2 | 0 )
		// and
		//( 0 | 0 0 | 0 | -1 2 | 0 0 | -1 )
		//  => {i,j,alpha,beta | 2.beta-alpha=0 && 2.jj-ii>=0 && 0<=ii,jj<b } U {i,j,alpha,beta | 2.beta-alpha=-1 && 2.jj-ii>=b && 0<=ii,jj<b }
		//				U {i,j,alpha,beta | 2.beta-alpha>=1 && 0<=ii,jj<b }
		//
		// * Third union:
		//(0/1 | Nbl Nloc | b | alpha beta | ii jj | cnst)
		//( 1 | 1 0 | 0 | 0 -1 |  0  0 |  0 )
		//( 0 | 0 1 | 0 | 0  0 |  0 -1 | -1 )
		// and
		//( 0 | 1 0 | 0 | 0 -1 |  0  0 | -1 )
		//  => {i,j,alpha,beta | Nbl=beta && Nloc>=jj+1 && 0<=ii,jj<b } U {i,j,alpha,beta | Nbl>=beta-1 && 0<=ii,jj<b }
		//*/
		
		return;
	}
	
	public static void printoutDomain(List<List<long[][]> > llDom) {
		
		System.out.println("Intersection between the " + llDom.size() + " following union(s) of polyhedra:");
		for (List<long[][] >lDom : llDom) {
			System.out.println("	[[[");
			for (long[][] poly : lDom) {
				for (int i=0; i<poly.length; i++) {
					System.out.print("		(");
					for(int j=0; j<poly[0].length; j++)
						System.out.print(" " + poly[i][j]);
					System.out.println(" )");
				}
				System.out.println();
			}
			System.out.println("]]]");
		}
		
		return;
	}
	
	/* -------------------------------------------------------------------- */
	
	@Test
	public void test_CARTFunction() {
		// kmin/max computation option => 0: all possible values of b | 1: b "big enough"
		CART.changekMinMaxOption(0);
		
		//* Example 1: (i,j -> i-1, j-1)  (Jacobi1D dependence)
		long[][] funcScalar =  {{1, 0, -1}, {0, 1, -1}};
		List<Integer> scale = new ArrayList<Integer>();
		scale.add(1); scale.add(1);
		List<Integer> scaleIm = new ArrayList<Integer>();
		scaleIm.add(1); scaleIm.add(1);
		printoutFunction(CART.getTiledFunction(funcScalar, 2, 0, scale, scaleIm));
		
		// RESULT: 4 branches:
		// Conds: (0/1 b alpha beta ii jj cst)
		// Funcs: (b alpha beta ii jj cst)
		//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta-1, ii-1, b+jj-1)		// Note: jj=0 
		//		=> IF {alpha,beta,ii,jj | 1<=ii<=b   &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha,beta, ii-1, jj-1)
		//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 && 1-b<=jj<=0 && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta-1, b+ii-1, b+jj-1)	// Note: ii=jj=0
		//		=> IF {alpha,beta,ii,jj | 1-b<=ii<=0 &&   1<=jj<=b && 0<=ii,jj<b} THEN (alpha,beta, ii,jj -> alpha-1,beta, b+ii-1, jj-1)		// Note: ii=0
		//*/
	}
	
	public static void printoutFunction(Map<long[][],long[][]> mFunc) {
		System.out.println(mFunc.size() + " branches:");
		for (long[][] cond : mFunc.keySet()) {
			System.out.println("IF");
			for (int i=0; i<cond.length; i++) {
				System.out.print("	(");
				for (int j=0; j<cond[0].length; j++)
					System.out.print(" " + cond[i][j]);
				System.out.println(" )");
			}
			System.out.println("	THEN");
			long[][] matFuncCond = mFunc.get(cond);
			for (int i=0; i<matFuncCond.length; i++) {
				System.out.print("		(");
				for (int j=0; j<matFuncCond[0].length; j++)
					System.out.print(" " + matFuncCond[i][j]);
				System.out.println(" )");
			}
			System.out.println();
		}
	}
	
} // CART_Example