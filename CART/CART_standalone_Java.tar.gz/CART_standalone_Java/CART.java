package CART_standalone;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Standalone Java version of the CART transformation.
 * 
 * @author Guillaume Iooss
 */
public class CART {
	
	// Option to select which mode of computation we take for kmin/kmax
	// 	* 0 = compute a kMin/kMax for every possible values of "b".
	// 	* 1 = compute a tighter kMin/kMax by assuming that "b" is "big enough".
	private static int _kMinMaxOption = 0;
	
	/**
	 * Function to change the mode of computation of kmin/kmax:
	 * 	* 0 = compute a kMin/kMax for every possible values of "b".
	 * 	* 1 = compute a tighter kMin/kMax by assuming that "b" is "big enough".
	 * 
	 * @param newOption
	 */
	public static void changekMinMaxOption(int newOption) {
		_kMinMaxOption = newOption;
	}
	
	
	/**
	 * Given a domain in PolyLib format ("polyScalar") D= { \vec{i} | ... }, transform this domain into D' = {\vec{\alpha}, \vec{ii} | ... }
	 * 			such that the indexes \vec{i} = b.D.\vec{\alpha} + \vec{ii} where:
	 * 				* D is a diagonal matrix of positive integer coefficient, given by "scale" (scale being of size "nInd")
	 * 				* b is the block size parameter
	 * 				* The number of indexes ("nInd") and parameters ("nParam") are specified
	 * 
	 * The type of the result is "List<List<long[][]>>", representing an intersection (outer "List") of a union (inner "List")
	 * 			of polyhedra ("long[][]") in PolyLib format (the matrix being described in the code).
	 * This result can be simplified into a union of polyhedra by using ISL simplification, for example.
	 * 
	 * @param polyScalar
	 * @param nParam
	 * @param nInd
	 * @param scale
	 * @return
	 */
	public static List<List<long[][]>> getTiledDomain(long[][] polyScalar, int nParam, int nInd, List<Integer> scale) {
		assert(polyScalar[0].length==nParam+nInd+2);
		assert(scale.size()==nInd);
		
		// Extracting the informations from polyScalar
		List<List<long[][]>> resDom = new ArrayList<List<long[][]>>();
		long[][] linPart = submatrixColumn(polyScalar, nParam+1, polyScalar[0].length-2);
		long[][] paramPart = submatrixColumn(polyScalar, 1, nParam);
		long[] constPart = new long[linPart.length];
		for (int i=0; i<polyScalar.length; i++)
			constPart[i] = polyScalar[i][polyScalar[0].length-1];
		
		// First of all, we need to get $k^{min}$ and $k^{max}$ for every constraints.
		//		We have k^{max} = ( \sum_i QD+_i ) + ( \sum_i Qp+_i ) + |_ ( q-card(QD+)-card(Qp+) )/b _|
		//		   and  k^{min} = ( \sum_i QD-_i ) + ( \sum_i Qp-_i ) + |_ ( q+card(QD-)+card(Qp-) )/b _|
		long[] kmax = new long[linPart.length];
		long[] kmin = new long[linPart.length];
		
		for (int i=0; i<linPart.length; i++) {
			long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
			long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
			
			for (int j=0; j<linPart[i].length; j++) {
				if (linPart[i][j]>0)
					tempkmax += scale.get(j) * linPart[i][j];
				else if (linPart[i][j]<0)
					tempkmin += scale.get(j) * linPart[i][j];
			}
			for (int j=0; j<paramPart[i].length; j++) {
				if (paramPart[i][j]>0)
					tempkmax += paramPart[i][j];
				else if (paramPart[i][j]<0)
					tempkmin += paramPart[i][j];
			}
			
			// kmax
			if (constPart[i]-tempkmax>=0) {
				if (_kMinMaxOption==0)
					kmax[i] = constPart[i];
				else
					kmax[i] = tempkmax;
			} else
				kmax[i] = tempkmax-1;
			
			// kmin
			if (constPart[i]-tempkmin>=0)
				kmin[i] = tempkmin;
			else {
				if (_kMinMaxOption==0)
					kmin[i] = constPart[i];
				else
					kmin[i] = tempkmin-1;
			}
		}
		
		/* DEBUG - kmin / kmax
		System.out.println("DEBUG: kmin - kmax");
		for (int i=0; i<linPart.length; i++)
			System.out.println("kmin[" + i + "] = " + kmin[i] + "  |  kmax[" + i + "] = " + kmax[i]);
		System.out.println();
		//*/
		
		for (int i=0; i<linPart.length; i++) {				// We consider the ith constraint (outer intersection)
			List<long[][]> domIthList = new ArrayList<long[][]>();
			
			for (long k=kmin[i]+1; k<=kmax[i]; k++) {		// We consider all the different cases arising with the constraint (inner union)
				// * Case k > kmin
				
				// In Polylib format, the matrix of constraint is:
				//
				// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
				//
				// [ 1    Qp_i,*    0      0    Q_i,*.D   0     k   ]
				// [ 0      0     Qp_i,*  -k        0     Q     q   ]
				// [ 0      0       0      0        0     Id    0   ]
				// [ 0      0       0     D.1       0    -Id   -1   ]
				//
				// First column: 0=inequality / 1 = equality
				// \rho = blocked parameters / pp = local parameters / b = block size parameter
				// \alpha = blocked index parameter / ii = local index parameter
				
				long[][] blockedConstr = new long[2+2*nInd][3+2*nParam+2*nInd];
				
				// (First line)
				blockedConstr[0][0] = 1;
				for (int j=0; j<nParam; j++) {
					blockedConstr[0][j+1] = paramPart[i][j];
				}
				for (int j=0; j<nInd; j++)
					blockedConstr[0][j+2+2*nParam] = linPart[i][j] * ((long) scale.get(j));
				blockedConstr[0][blockedConstr[0].length-1] = k;
				
				// (Second line)
				for (int j=0; j<nParam; j++)
					blockedConstr[1][j+1+nParam] = paramPart[i][j];
				blockedConstr[1][1+2*nParam] = -k;
				for (int j=0; j<nInd; j++)
					blockedConstr[1][2+2*nParam+nInd+j] = linPart[i][j];
				blockedConstr[1][blockedConstr[0].length-1] = constPart[i];
				
				// (Third lines)
				for (int j=0; j<nInd; j++)
					blockedConstr[2+j][2+2*nParam+nInd+j] = 1;
				
				// (Fourth lines)
				for (int j=0; j<nInd; j++) {
					blockedConstr[2+nInd+j][1+2*nParam] = ((long) scale.get(j));
					blockedConstr[2+nInd+j][2+2*nParam+nInd+j] = -1;
					blockedConstr[2+nInd+j][blockedConstr[0].length-1] = -1;
				}
				
				domIthList.add(blockedConstr);
			}
			
			// * Case k = kmin
			
			// In Polylib format, the matrix of constraint is:
			//
			// ( eq | \rho   |  pp  |  b  |  \alpha | ii | const)    <= Row to know which column corresponds to what...
			//
			// [ 0    Qp_i,*     0     0    Q_i,*.D   0    kmin ]
			// [ 0      0        0     0        0     Id    0   ]
			// [ 0      0        0    D.1       0    -Id   -1   ]
			//
			// First column: 0=inequality / 1 = equality
			// \rho = blocked parameters / pp = local parameters / b = block size parameter
			// \alpha = blocked index parameter / ii = local index parameter

			long[][] blockedConstr = new long[1+2*nInd][3+2*nParam+2*nInd];
			
			// (First line)
			for (int j=0; j<nParam; j++)
				blockedConstr[0][1+j] = paramPart[i][j];
			for (int j=0; j<nInd; j++)
				blockedConstr[0][2+2*nParam+j]= linPart[i][j] * ((long) scale.get(j));
			blockedConstr[0][blockedConstr[0].length-1] = kmin[i];
			
			// (Second lines)
			for (int j=0; j<nInd; j++)
				blockedConstr[1+j][2+2*nParam+nInd+j] = 1;
			
			// (Fourth lines)
			for (int j=0; j<nInd; j++) {
				blockedConstr[1+nInd+j][1+2*nParam] = ((long) scale.get(j));
				blockedConstr[1+nInd+j][2+2*nParam+nInd+j] = -1;
				blockedConstr[1+nInd+j][blockedConstr[0].length-1] = -1;
			}
			domIthList.add(blockedConstr);
			
			resDom.add(domIthList);
		}	// [end of the loop across all the different case of k]
		
		return resDom;
	}
	
	/**
	 * Given an affine function given in matrix format ("affScalar") f:(i -> ... ), transform it into
	 * 		a piecewise affine function \phi:(\vec{\alpha}, \vec{ii} -> ... , ... ) such that \vec{i} = b.D.\vec{\alpha} + \vec{ii} where:
	 * 				* D is a diagonal matrix of positive integer coefficient, given by "scale"
	 * 				* b is the block size parameter.
	 * 				* D' is a diagonal matrix of positive integer coefficient (for the image space of the function), given by "scaleIm"
	 * 
	 * The type of the result is "Map<long[][],long[][]>", representing a piecewise affine function, where the first entry corresponds to
	 * 		the Domain of one of the pieces (in Polylib format), and the second the affine function (in matrix format).
	 * 
	 * This function corresponds to the polyhedral case...
	 * 
	 * @param affScalar
	 * @param nInd
	 * @param nParam
	 * @param scale
	 * @param scaleIm
	 * @return
	 */
	public static Map<long[][],long[][]> getTiledFunction(long[][] affScalar, int nInd, int nParam, List<Integer> scale, List<Integer> scaleIm) {
		assert(affScalar[0].length==nInd+nParam+1);
		assert(scale.size()==nInd);
		assert(scaleIm.size()==affScalar.length);
		
		long[][] paramPart = submatrixColumn(affScalar, 0, nParam-1);
		long[][] linPart = submatrixColumn(affScalar, nParam, nParam+nInd-1);
		long[] constPart = new long[affScalar.length];
		for (int i=0; i<affScalar.length; i++)
			constPart[i] = affScalar[i][affScalar[0].length-1];
		
		// We compute kmin and kmax (in the same manner (and with the same limitation) than for the domains -cf comments in "getTiledDomain")
		long[] kmax = new long[linPart.length];
		long[] kmin = new long[linPart.length];
		
		for (int i=0; i<linPart.length; i++) {
			long tempkmin = 0;		// ( \sum_i QD-_i + \sum_i Q^p-_i )
			long tempkmax = 0;		// ( \sum_i QD+_i + \sum_i Q^p+_i )
			
			for (int j=0; j<linPart[i].length; j++) {
				if (linPart[i][j]>0)
					tempkmax += scale.get(j) * linPart[i][j];
				else if (linPart[i][j]<0)
					tempkmin += scale.get(j) * linPart[i][j];
			}
			for (int j=0; j<paramPart[i].length; j++) {
				if (paramPart[i][j]>0)
					tempkmax += paramPart[i][j];
				else if (paramPart[i][j]<0)
					tempkmin += paramPart[i][j];
			}
			
			// kmax
			if (constPart[i]-tempkmax>=0) {
				if (_kMinMaxOption==0)
					kmax[i] = constPart[i];
				else
					kmax[i] = tempkmax;
			} else
				kmax[i] = tempkmax-1;
			
			// kmin
			if (constPart[i]-tempkmin>=0)
				kmin[i] = tempkmin;
			else {
				if (_kMinMaxOption==0)
					kmin[i] = constPart[i];
				else
					kmin[i] = tempkmin-1;
			}
		}
		//* DEBUG - kmin / kmax
		for (int i=0; i<linPart.length; i++)
			System.out.println("kmin[" + i + "] = " + kmin[i] + "  |  kmax[" + i + "] = " + kmax[i]);
		System.out.println();
		//*/
		
		
		// Now, we build our new blocked affine functions: we have a part of piece-wise affine function per \vec{k},
		//		which is: \phi(\alpha,ii) = (Q.D.\alpha + Q_p.\rho + k  ,  Q.ii + q - b.k) when  b.k <= Q.ii+q < b.(k+1)
		// Thus, we iterate on the multi-dimensional vector k
		long[] kCurr = new long[linPart.length];		// Multi-dimensional iterator
		for (int i=0; i<linPart.length; i++)
			kCurr[i] = kmin[i];
		
		Map<long[][],long[][]> result = new HashMap<long[][], long[][]>();
		
		while (kCurr[linPart.length-1]<=kmax[linPart.length-1]) {
			
			// We build the piece-wise part corresponding to the vector "kCurr"
			// In Polylib format, the matrix of input constraints is:
			// 
			// ( eq | \rho  | pp |    b   | \alpha | ii |  const )    <= Row to know which column corresponds to what...
			// 
			// [ 0      0     Qp    -D'.k     0       Q      q     ]
			// [ 0      0    -Qp   D'.(k+1)   0      -Q   -D'.1-q  ]
			// [ 0      0      0      0       0      Id      0     ]
			// [ 0      0      0     D.1      0     -Id     -1     ]
			// 
			// First column: 0=inequality / 1 = equality
			// \rho = blocked parameters / pp = local parameters / b = block size parameter
			// \alpha = blocked index parameter / ii = local index parameter
			
			// And the matrix of relations is:
			// 
			// (     \rho    |   pp   |     b    |    \alpha    | ii | const)    <= Row to know which column corresponds to what...
			//
			// [  D'^{-1}.Qp     0          0       D'^{-1}Q.D    0      k  ]
			// [      0          Qp    -D'^{-1}k        0         Q      q  ]
			//
			
			long[][] inputConstrLongMat = new long[2*linPart.length+2*nInd][3+2*nParam+2*nInd];
			
			for (int i=0; i<linPart.length; i++) {
				for (int j=0; j<paramPart[0].length;j++)
					inputConstrLongMat[i][1+nParam+j] = paramPart[i][j];
				inputConstrLongMat[i][1+2*nParam] = -kCurr[i] * scaleIm.get(i);
				for (int j=0; j<nInd; j++)
					inputConstrLongMat[i][2+2*nParam+nInd+j] = linPart[i][j];
				inputConstrLongMat[i][inputConstrLongMat[0].length-1] = constPart[i];
			}
			for (int i=linPart.length; i<2*linPart.length; i++) {
				for (int j=0; j<paramPart[0].length; j++)
					inputConstrLongMat[i][1+nParam+j] = -paramPart[i-linPart.length][j];
				inputConstrLongMat[i][1+2*nParam] = scaleIm.get(i-linPart.length)* ( kCurr[i-linPart.length]+1 );
				for (int j=0; j<nInd; j++)
					inputConstrLongMat[i][2+2*nParam+nInd+j] = -linPart[i-linPart.length][j];
				inputConstrLongMat[i][inputConstrLongMat[0].length-1] = -scaleIm.get(i-linPart.length)-constPart[i-linPart.length];
			}
			for (int i=0; i<nInd; i++)
				inputConstrLongMat[i+2*linPart.length][2+2*nParam+nInd+i] = 1;
			for (int i=0; i<nInd; i++) {
				inputConstrLongMat[i+2*linPart.length+nInd][1+2*nParam] = (long) scale.get(i);
				inputConstrLongMat[i+2*linPart.length+nInd][2+2*nParam+nInd+i] = -1;
				inputConstrLongMat[i+2*linPart.length+nInd][inputConstrLongMat[0].length-1] = -1;
			}
			
			/* DEBUG
			System.out.println(" * inputConstrLongMat:");
			for (int i=0; i<inputConstrLongMat.length; i++) {
				for (int j=0; j<inputConstrLongMat[0].length; j++)
					System.out.print(inputConstrLongMat[i][j] + " ");
				System.out.println();
			}
			System.out.println();
			//*/
			
			long[][] relationConstrLongMat = new long[2*linPart.length][2+2*nParam+2*nInd];
			for (int i=0; i<linPart.length; i++) {
				for (int j=0; j<nParam; j++) {
					long temp = (long) (paramPart[i][j]/scaleIm.get(i));
					if (temp*scaleIm.get(i) != paramPart[i][j])
						throw new RuntimeException("The resulting affine function has Z-polyhedral constraints (param | i = " + i + " | j = " + j + " )");
					relationConstrLongMat[i][j] = temp;
				}
				for (int j=0; j<nInd; j++) {
					long temp = (long) (linPart[i][j] * scale.get(j) / scaleIm.get(i));
					if (temp*scaleIm.get(i) != linPart[i][j] * scale.get(j))
						throw new RuntimeException("The resulting affine function has Z-polyhedral constraints (linear | i = " + i + " | j = " + j + " )");
					relationConstrLongMat[i][1+2*nParam+j] = temp;
				}
				relationConstrLongMat[i][relationConstrLongMat[0].length-1] = kCurr[i];
			}
			for (int i=linPart.length; i<2*linPart.length; i++) {
				for (int j=0; j<paramPart[0].length;j++)
					relationConstrLongMat[i][nParam+j] = paramPart[i-linPart.length][j];
				relationConstrLongMat[i][2*nParam] = -scaleIm.get(i-linPart.length)*kCurr[i-linPart.length];
				for (int j=0; j<nInd; j++)
					relationConstrLongMat[i][1+2*nParam+nInd+j] = linPart[i-linPart.length][j];
				relationConstrLongMat[i][relationConstrLongMat[0].length-1] = constPart[i-linPart.length];
			}
			
			/* DEBUG
			System.out.println(" * relationConstrLongMat:");
			for (int i=0; i<relationConstrLongMat.length; i++) {
				for (int j=0; j<relationConstrLongMat[0].length; j++)
					System.out.print(relationConstrLongMat[i][j] + " ");
				System.out.println();
			}
			System.out.println();
			//*/
			
			result.put(inputConstrLongMat, relationConstrLongMat);
			
			// We increase the multi-dimensional iterator, starting from the first dimension and propagating the overflows
			kCurr[0]++;
			for (int i=0; i<linPart.length-1; i++)
				if (kCurr[i]>kmax[i]) {
					kCurr[i] = kmin[i];
					kCurr[i+1]++;
				}
		} // End of multi-dimensional loop
		
		return result;
	}
	
	/** Give back the submatrix of A, containing the columns i to j (both indexes included) (0<=i<=j<A[0].length).
	 * 
	 * @param A
	 * @param i
	 * @param j
	 * @return B, submatrix containing the column i to j of A
	 */
	public static long[][] submatrixColumn(long[][] A, int j1, int j2) {
		if (j1>j2)
			return new long[A.length][0];
		if (j1>=A[0].length || j2>=A[0].length)
			throw new RuntimeException("submatrixColumn: j1 or j2 out of bound");
		
		long[][] B = new long[A.length][j2-j1+1];
		for (int i=0; i<A.length; i++)
			for (int j=j1; j<=j2; j++)
				B[i][j-j1] = A[i][j];
		
		return B;
	}
	
} // CART
